#!/usr/bin/env node
// Tests for src/mcp-servers/caveman-shrink/compress.js — pure-Node prose compressor.
// Run: node tests/test_mcp_shrink.js

const fs = require('fs');
const path = require('path');
const assert = require('assert');

const ROOT = path.resolve(__dirname, '..');
const { compress, compressDescriptionsInPlace } = require(
  path.join(ROOT, 'src', 'mcp-servers', 'caveman-shrink', 'compress.js')
);
const { getSpawnOptions } = require(
  path.join(ROOT, 'src', 'mcp-servers', 'caveman-shrink', 'spawn-options.js')
);
const { createShutdown, DEFAULT_GRACE_MS } = require(
  path.join(ROOT, 'src', 'mcp-servers', 'caveman-shrink', 'shutdown.js')
);

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    failed++;
    console.error(`  ✗ ${name}\n    ${e.message}`);
  }
}

console.log('mcp-shrink compress tests\n');

test('mixed CJK technical descriptions retain articles, intent, case and whitespace (#575)', () => {
  for (const input of ['这是一个 a LLM 模型', '这个 the MCP server', 'the Agent 的状态', 'i will 检查这个 bug',
    '  日本語 the API  \n', '한글 the API', 'カタカナ please a MCP', '𠀀 the API', 'ㄅㄆ the API',
    'I will use `中文` with the MCP server.']) {
    const result = compress(input);
    assert.strictEqual(result.compressed, input);
    assert.strictEqual(result.before, result.after);
  }
});

test('drops articles', () => {
  const { compressed } = compress('The user is the owner of an account');
  assert.match(compressed, /User is owner of account/i);
  // No leftover lone "the" / "an" / "a"
  assert.doesNotMatch(compressed, /\bthe\b/i);
  assert.doesNotMatch(compressed, /\ban\b/i);
});

test('drops filler and pleasantries', () => {
  const { compressed } = compress('Sure, this just basically returns the value');
  assert.doesNotMatch(compressed, /sure/i);
  assert.doesNotMatch(compressed, /just/i);
  assert.doesNotMatch(compressed, /basically/i);
});

test('drops hedging and "I will" leaders', () => {
  const { compressed } = compress('I will perhaps connect to the database');
  assert.doesNotMatch(compressed, /perhaps/i);
  assert.doesNotMatch(compressed, /^I will/i);
  assert.match(compressed, /database/i);
});

test('preserves fenced code blocks verbatim', () => {
  const input = 'Run the example: ```\nthe just sure return 1;\n``` and also more text';
  const { compressed } = compress(input);
  // Inside the fence, "the just sure" must survive untouched.
  assert.match(compressed, /```\nthe just sure return 1;\n```/);
});

test('preserves inline code verbatim', () => {
  const input = 'Use `the just basically API` for fetching';
  const { compressed } = compress(input);
  assert.match(compressed, /`the just basically API`/);
});

test('preserves URLs verbatim', () => {
  const input = 'See the docs at https://example.com/the/just/api';
  const { compressed } = compress(input);
  assert.match(compressed, /https:\/\/example\.com\/the\/just\/api/);
});

test('preserves filesystem paths verbatim', () => {
  const input = 'Read just the file at /tmp/the/just/file.txt';
  const { compressed } = compress(input);
  assert.match(compressed, /\/tmp\/the\/just\/file\.txt/);
});

test('preserves identifiers in CONST_CASE / dotted form', () => {
  const input = 'Set the API_KEY_VALUE on the just config.api.endpoint()';
  const { compressed } = compress(input);
  assert.match(compressed, /API_KEY_VALUE/);
  assert.match(compressed, /config\.api\.endpoint\(\)/);
});

test('compresses a pleasantry/filler sitting inside an English parenthetical (#999)', () => {
  // A word directly followed by a space and "(...)" is prose, not a call:
  // real function-call syntax never has a space before the paren.
  const cases = [
    { in: 'This tool is useful (please read carefully) before continuing.', banned: /\bplease\b/i },
    { in: 'Please use the option (basically the default) to enable this.', banned: /\bbasically\b/i },
  ];
  for (const c of cases) {
    const { compressed } = compress(c.in);
    assert.doesNotMatch(compressed, c.banned, `parenthetical was over-protected: "${compressed}"`);
  }
  // Real function calls, which never have a space before "(", still protect.
  const { compressed } = compress('Run compress(text, opts) to process the payload.');
  assert.match(compressed, /compress\(text, opts\)/);
});

test('never eats a hyphen-joined component of a compound word', () => {
  // `\b` treats "-" as a word boundary, so a filler/hedge/pleasantry spelled as
  // part of a hyphenated compound used to match and get stripped, leaving a
  // dangling "-suffix": "just-in-time" → "-in-time". These are ordinary
  // technical terms and appear verbatim in MCP tool descriptions, which the
  // proxy rewrites in place via compressDescriptionsInPlace — so the corruption
  // ships straight into the model's tool list.
  const cases = [
    'Enable just-in-time compilation for the runtime',
    'Set the maybe-null flag on the field',
    'Use the sure-fire approach',
    'Returns a very-long-string value',
    'The actually-used config wins',
    'Pass the thanks-giving header',
    'A might-fail retry policy',
  ];
  for (const input of cases) {
    const compound = input.match(/[a-z]+(?:-[a-z]+)+/i)[0];
    const { compressed } = compress(input);
    // Case-insensitive: dropping a leading article can promote the compound to
    // sentence-initial, where the capitalization pass legitimately upcases it.
    assert.ok(
      compressed.toLowerCase().includes(compound.toLowerCase()),
      `compound "${compound}" was mangled: "${input}" → "${compressed}"`
    );
    assert.doesNotMatch(
      compressed,
      /(^|\s)-/,
      `left a dangling hyphen: "${input}" → "${compressed}"`
    );
  }
  // The same words standing alone are still dropped — the fix must not turn
  // the compressor off, only stop it from reaching inside a compound.
  const { compressed } = compress('This is just a maybe wrong value');
  assert.doesNotMatch(compressed, /\bjust\b/i);
  assert.doesNotMatch(compressed, /\bmaybe\b/i);
});

test('never eats "sure" out of the "make sure" / "be sure" / "not sure" collocations', () => {
  // `sure` is a pleasantry as a bare interjection ("Sure, this returns the
  // value"), but in these fixed collocations it is the complement of the verb,
  // so dropping it does not weaken the sentence — it changes what the sentence
  // says. "Make sure the file exists" is a check; "Make file exists" reads as a
  // create. Same class as the hyphenated-compound corruption above: a word that
  // is filler on its own is not filler inside a collocation. The proxy rewrites
  // MCP tool descriptions in place via compressDescriptionsInPlace, so the
  // mangled contract is what the model reads as the tool's behavior (#1073).
  const cases = [
    'Make sure the file exists.',
    'Make sure to call init before any other tool.',
    'Be sure to pass an absolute path.',
    'Not sure why this fails.',
    'Please make sure.',
    "I'm sure that works.",
    'Ensure you make sure of the ordering.',
    // CRLF: the interjection rule anchors on line starts, so a Windows-newline
    // description must not take a different branch from the LF one.
    'Step one.\r\nMake sure the file exists.',
    'MAKE SURE THE PATH IS ABSOLUTE.',
    'Surely, this works.',
  ];
  for (const input of cases) {
    const { compressed } = compress(input);
    assert.match(
      compressed,
      /sure/i,
      `dropped the verb complement "sure": "${input}" → "${compressed}"`
    );
  }
  // The bare interjection is still dropped — the fix must not turn the rule
  // off, only stop it from reaching inside a collocation.
  for (const input of [
    'Sure, this returns the value',
    'Sure! That is the default.',
    'Done. Sure, that works too.',
    'Done.\r\nSure, that works.',
    'Done.\nSure, that works.',
  ]) {
    const { compressed } = compress(input);
    assert.doesNotMatch(
      compressed,
      /sure/i,
      `kept a bare "sure" interjection: "${input}" → "${compressed}"`
    );
  }
});

test('compresses real MCP-style description', () => {
  const input = 'Get the current weather for a given location. ' +
    'Returns the temperature in Fahrenheit. ' +
    'Please make sure to provide the location as a city name.';
  const { compressed, before, after } = compress(input);
  assert.ok(after < before, `expected size reduction, got ${before}→${after}`);
  // ~30% reduction is the floor; descriptions like this should compress well.
  assert.ok((before - after) / before > 0.15, `wanted >15% savings, got ${(before - after) / before}`);
  // Substance preserved
  assert.match(compressed, /weather/i);
  assert.match(compressed, /Fahrenheit/i);
  assert.match(compressed, /city name/i);
});

test('handles empty / null input gracefully', () => {
  assert.deepStrictEqual(compress(''), { compressed: '', before: 0, after: 0 });
  const r = compress(null);
  assert.strictEqual(r.compressed, null);
});

test('compressDescriptionsInPlace walks nested tools/list response', () => {
  const payload = {
    result: {
      tools: [
        { name: 'get_weather', description: 'The function returns the current weather for a city.' },
        { name: 'send_email', description: 'Sends an email to a given recipient.' },
      ]
    }
  };
  compressDescriptionsInPlace(payload.result, ['description']);
  assert.ok(!payload.result.tools[0].description.match(/\bthe\b/i),
    `expected 'the' stripped, got: ${payload.result.tools[0].description}`);
  assert.match(payload.result.tools[0].description, /weather/i);
  assert.match(payload.result.tools[1].description, /email/i);
});

test('compressDescriptionsInPlace skips non-string description fields', () => {
  const obj = { description: { not: 'a string' }, name: 'x' };
  // Should not throw.
  compressDescriptionsInPlace(obj, ['description']);
  assert.deepStrictEqual(obj.description, { not: 'a string' });
});

// spawn-options: upstream MCP child process spawn flags. Windows .cmd shims
// are resolved separately; all platforms keep shell mode disabled.

test('win32 keeps shell off so upstream args are never interpolated', () => {
  const opts = getSpawnOptions('win32');
  assert.equal(opts.shell, undefined);
  assert.equal(opts.windowsHide, true);
  assert.deepEqual(opts.stdio, ['pipe', 'pipe', 'inherit']);
});

test('linux keeps shell off to avoid argv quoting surprises', () => {
  const opts = getSpawnOptions('linux');
  assert.equal(opts.shell, undefined);
  assert.deepEqual(opts.stdio, ['pipe', 'pipe', 'inherit']);
});

test('darwin keeps shell off', () => {
  const opts = getSpawnOptions('darwin');
  assert.equal(opts.shell, undefined);
});

test('defaults to current platform when no arg passed', () => {
  const opts = getSpawnOptions();
  assert.equal(opts.shell, undefined);
  assert.equal(opts.windowsHide, true);
  assert.deepEqual(opts.stdio, ['pipe', 'pipe', 'inherit']);
});

test('preserves enum values inside parens (nested sentinel restoration — #444)', () => {
  // Path pattern matches "STARTER/BUSINESS" first (sentinel 0).
  // Function-call pattern then matches "type ( 0 )" (sentinel 1).
  // Single-pass restore replaces " 1 " with "type ( 0 )" but leaves the
  // inner " 0 " unrestored — model sees "( 0 )" instead of the enum.
  const cases = [
    { in: 'plan type (STARTER/BUSINESS)',   needle: 'STARTER/BUSINESS' },
    { in: 'user role (ADMIN/MEMBER/GUEST)', needle: 'ADMIN/MEMBER/GUEST' },
    { in: 'user plan (Free/Pro/Business)',  needle: 'Free/Pro/Business' },
  ];
  for (const c of cases) {
    const { compressed } = compress(c.in);
    assert.ok(
      compressed.includes(c.needle),
      `nested sentinel leaked: expected "${c.needle}" in output, got "${compressed}"`
    );
    assert.doesNotMatch(
      compressed,
      / \d+ /,
      `unrestored sentinel " N " left in output: "${compressed}"`
    );
  }
});

// ── Packaging (#597) ────────────────────────────────────────────────────────
// npm publish ships only what "files" lists (plus package.json/README/LICENSE,
// which npm always includes). A local module required by a shipped entry point
// but missing from "files" makes the published package crash with
// MODULE_NOT_FOUND at startup — exactly what happened with spawn-options.js.
// This static check walks every relative require reachable from the package's
// entry points (bin + main) and fails if any resolved file is not listed.
// The package is flat, so "files" entries are exact filenames, not globs.

test('package.json "files" ships every module the entry points require (#597)', () => {
  const pkgDir = path.join(ROOT, 'src', 'mcp-servers', 'caveman-shrink');
  const pkg = JSON.parse(fs.readFileSync(path.join(pkgDir, 'package.json'), 'utf8'));
  const shipped = new Set((pkg.files || []).map(f => path.normalize(f)));

  const entries = [...Object.values(pkg.bin || {}), pkg.main]
    .filter(Boolean)
    .map(f => path.normalize(f));
  assert.ok(entries.length > 0, 'package has no entry points to check');

  const seen = new Set();
  const queue = [...entries];
  while (queue.length > 0) {
    const rel = queue.pop();
    if (seen.has(rel)) continue;
    seen.add(rel);
    assert.ok(
      shipped.has(rel),
      `"${rel}" is required by a shipped entry point but missing from package.json "files" — npm publish would ship a broken package`
    );
    const src = fs.readFileSync(path.join(pkgDir, rel), 'utf8');
    for (const m of src.matchAll(/require\(\s*['"](\.{1,2}\/[^'"]+)['"]\s*\)/g)) {
      let dep = path.normalize(path.join(path.dirname(rel), m[1]));
      if (!dep.endsWith('.js') && !dep.endsWith('.json')) dep += '.js';
      queue.push(dep);
    }
  }
});


// ── Teardown (shutdown.js) ──────────────────────────────────────────────────
// A stand-in for the spawned upstream. Node sets exitCode/signalCode on a
// ChildProcess once it has gone; before that both are null, which is what
// createShutdown reads to decide whether anything is still worth killing.
function fakeChild({ exitCode = null, signalCode = null, killed = false } = {}) {
  return {
    exitCode,
    signalCode,
    killed,
    signals: [],
    kill(sig) {
      this.signals.push(sig);
      this.killed = true;
      return true;
    },
  };
}

// Hand-driven clock: nothing here waits on a real timer, so the escalation
// tests stay synchronous and cannot flake under a loaded CI box.
function fakeTimers() {
  const pending = new Map();
  let next = 1;
  return {
    setTimeout(fn) { pending.set(next, fn); return next++; },
    clearTimeout(id) { pending.delete(id); },
    get armed() { return pending.size; },
    fire() {
      const fns = [...pending.values()];
      pending.clear();
      for (const fn of fns) fn();
    },
  };
}

test('forwards a termination signal to a live upstream', () => {
  const child = fakeChild();
  const shutdown = createShutdown({ child, timers: fakeTimers() });
  shutdown.forward('SIGTERM');
  assert.deepEqual(child.signals, ['SIGTERM']);
});

test('escalates to SIGKILL when the upstream ignores the signal', () => {
  // The whole point of the grace period: a server that traps SIGTERM and
  // declines to exit would otherwise keep the wrapper alive alongside it.
  const child = fakeChild();
  const timers = fakeTimers();
  const shutdown = createShutdown({ child, timers });
  shutdown.forward('SIGTERM');
  assert.equal(shutdown.pendingEscalation, true);
  timers.fire();
  assert.deepEqual(child.signals, ['SIGTERM', 'SIGKILL']);
});

test('does not escalate when the upstream exits inside the grace period', () => {
  const child = fakeChild();
  const timers = fakeTimers();
  const shutdown = createShutdown({ child, timers });
  shutdown.forward('SIGTERM');
  child.exitCode = 0;            // upstream honoured the signal
  timers.fire();
  assert.deepEqual(child.signals, ['SIGTERM'], 'SIGKILL sent to an already-exited child');
});

test('a second signal is a no-op, not a duplicate kill and a second timer', () => {
  // An impatient double Ctrl-C must not re-signal a child that is already
  // being torn down, nor leave a second escalation timer behind it.
  const child = fakeChild();
  const timers = fakeTimers();
  const shutdown = createShutdown({ child, timers });
  shutdown.forward('SIGINT');
  shutdown.forward('SIGINT');
  assert.deepEqual(child.signals, ['SIGINT'], 'second Ctrl-C re-signalled the child');
  assert.equal(timers.armed, 1, 'second Ctrl-C armed another timer');
});

test('leaves an already-exited upstream alone', () => {
  const child = fakeChild({ exitCode: 0 });
  const timers = fakeTimers();
  const shutdown = createShutdown({ child, timers });
  shutdown.forward('SIGTERM');
  assert.deepEqual(child.signals, []);
  assert.equal(timers.armed, 0);
});

test('close clears a pending escalation and detaches client input', () => {
  const child = fakeChild();
  const timers = fakeTimers();
  let detached = 0;
  const shutdown = createShutdown({ child, timers, detachInput: () => { detached++; } });
  shutdown.forward('SIGTERM');
  shutdown.onClose(0, null);
  assert.equal(shutdown.pendingEscalation, false);
  assert.equal(detached, 1);
  timers.fire();
  assert.deepEqual(child.signals, ['SIGTERM'], 'stale timer fired after close');
});

test('close reports the upstream exit code, or 128+signal when it was killed', () => {
  const mk = extra => createShutdown({ child: fakeChild(), timers: fakeTimers(), ...extra });
  assert.equal(mk().onClose(0, null), 0);
  assert.equal(mk().onClose(3, null), 3);
  assert.equal(mk().onClose(null, 'SIGTERM'), 143);
  assert.equal(mk().onClose(null, 'SIGINT'), 130);
  assert.equal(mk({ spawnFailed: () => true }).onClose(0, null), 1, 'spawn failure must not report success');
});

// The EOF half of the same sequence. A host shuts an MCP stdio server down by
// closing its stdin first; these cover what happens when the upstream does and
// does not act on that.
test('passes client EOF on to the upstream', () => {
  const child = fakeChild();
  let ended = 0;
  const shutdown = createShutdown({ child, timers: fakeTimers(), endUpstreamInput: () => { ended++; } });
  shutdown.closeInput();
  assert.equal(ended, 1);
  assert.deepEqual(child.signals, [], 'EOF must not signal the upstream on its own');
});

test('does not signal an upstream that exits on EOF', () => {
  // The normal path: a well-behaved server sees EOF and leaves. Nothing may be
  // signalled, or every clean shutdown would look like a kill.
  const child = fakeChild();
  const timers = fakeTimers();
  const shutdown = createShutdown({ child, timers });
  shutdown.closeInput();
  child.exitCode = 0;
  timers.fire();
  assert.deepEqual(child.signals, []);
});

test('escalates EOF through SIGTERM to SIGKILL when the upstream ignores both', () => {
  // Without this the wrapper waits on an upstream that is never going to
  // leave, and the host waits on the wrapper.
  const child = fakeChild();
  const timers = fakeTimers();
  const shutdown = createShutdown({ child, timers });
  shutdown.closeInput();
  assert.equal(shutdown.pendingEscalation, true, 'EOF armed no wait');
  timers.fire();
  assert.deepEqual(child.signals, ['SIGTERM'], 'EOF grace expiring did not send SIGTERM');
  timers.fire();
  assert.deepEqual(child.signals, ['SIGTERM', 'SIGKILL']);
});

test('EOF on an already-exited upstream arms nothing', () => {
  const child = fakeChild({ exitCode: 0 });
  const timers = fakeTimers();
  let ended = 0;
  const shutdown = createShutdown({ child, timers, endUpstreamInput: () => { ended++; } });
  shutdown.closeInput();
  assert.equal(ended, 1, 'the upstream stdin still gets closed');
  assert.equal(timers.armed, 0, 'armed a wait for a child that is already gone');
});

test('a repeated EOF does not arm a second wait', () => {
  const child = fakeChild();
  const timers = fakeTimers();
  const shutdown = createShutdown({ child, timers });
  shutdown.closeInput();
  shutdown.closeInput();
  assert.equal(timers.armed, 1);
});

test('close clears a pending EOF wait', () => {
  // Same stale-timer hazard as the signal path: the upstream is gone, so the
  // wait must not come back and signal whatever holds that pid next.
  const child = fakeChild();
  const timers = fakeTimers();
  const shutdown = createShutdown({ child, timers });
  shutdown.closeInput();
  shutdown.onClose(0, null);
  assert.equal(shutdown.pendingEscalation, false);
  timers.fire();
  assert.deepEqual(child.signals, [], 'stale EOF wait fired after close');
});

test('the default grace period is a real duration', () => {
  // Guards against a refactor that drops the default to 0 and turns every
  // teardown into an immediate SIGKILL.
  assert.ok(DEFAULT_GRACE_MS >= 1000, `grace period too short: ${DEFAULT_GRACE_MS}ms`);
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);

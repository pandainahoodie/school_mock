export const initialAssignments = [
	{
		id: "mathematics-quiz",
		title: "Mathematics Quiz",
		subject: "Mathematics",
		dueDate: "Sep 30, 2026",
		status: "Pending",
		description: "Complete the quiz covering this unit's core mathematics concepts and show your work for each problem.",
	},
	{
		id: "english-essay",
		title: "English Essay",
		subject: "English",
		dueDate: "Oct 2, 2026",
		status: "Submitted",
		description: "Write an essay analyzing the themes and character development in the class reading.",
	},
	{
		id: "science-worksheet",
		title: "Science Worksheet",
		subject: "Science",
		dueDate: "Oct 4, 2026",
		status: "Pending",
		description: "Answer the worksheet questions about the current science unit and its key observations.",
	},
	{
		id: "history-report",
		title: "History Report",
		subject: "History",
		dueDate: "Oct 7, 2026",
		status: "Graded",
		description: "Prepare a short report on a historical topic discussed in class, using supporting details.",
	},
]

export const studentSubjects = [
	{
		id: "mathematics",
		name: "Mathematics",
		teacher: "Ms. Kim",
		schedule: "Mon, Wed, Fri | 09:00",
		room: "Room 204",
		progress: 82,
		overview: "Build confidence with core concepts, problem-solving strategies, and clear mathematical reasoning.",
	},
	{
		id: "english",
		name: "English",
		teacher: "Mr. Lee",
		schedule: "Mon, Thu | 11:00",
		room: "Room 108",
		progress: 74,
		overview: "Develop reading, writing, and communication skills through literature and guided practice.",
	},
	{
		id: "science",
		name: "Science",
		teacher: "Ms. Choi",
		schedule: "Tue, Fri | 14:00",
		room: "Science Lab 2",
		progress: 68,
		overview: "Explore scientific ideas through observation, experiments, and evidence-based explanations.",
	},
	{
		id: "history",
		name: "History",
		teacher: "Mr. Park",
		schedule: "Tue, Thu | 10:00",
		room: "Room 301",
		progress: 91,
		overview: "Study important events and perspectives to understand how the past shapes the present.",
	},
	{
		id: "japanese",
		name: "Japanese",
		teacher: "Ms. Sato",
		schedule: "Wed | 13:00",
		room: "Room 212",
		progress: 57,
		overview: "Practice Japanese vocabulary, grammar, and conversation in everyday contexts.",
	},
	{
		id: "computer-science",
		name: "Computer Science",
		teacher: "Mr. Han",
		schedule: "Thu | 15:00",
		room: "Computer Lab 1",
		progress: 76,
		overview: "Learn programming fundamentals and computational thinking through practical exercises.",
	},
]

export const studentGrades = [
	{
		subjectId: "mathematics",
		subject: "Mathematics",
		teacher: "Ms. Kim",
		percentage: 92,
		letterGrade: "A-",
		assessments: [
			{ name: "Quiz 1", score: 18, total: 20 },
			{ name: "Assignment", score: 23, total: 25 },
			{ name: "Midterm Exam", score: 45, total: 50 },
		],
	},
	{
		subjectId: "english",
		subject: "English",
		teacher: "Mr. Lee",
		percentage: 88,
		letterGrade: "B+",
		assessments: [
			{ name: "Reading Quiz", score: 9, total: 10 },
			{ name: "Essay", score: 20, total: 25 },
			{ name: "Midterm Exam", score: 47, total: 50 },
		],
	},
	{
		subjectId: "science",
		subject: "Science",
		teacher: "Ms. Choi",
		percentage: 85,
		letterGrade: "B",
		assessments: [
			{ name: "Lab Report", score: 18, total: 20 },
			{ name: "Unit Quiz", score: 42, total: 50 },
			{ name: "Project", score: 80, total: 100 },
		],
	},
	{
		subjectId: "history",
		subject: "History",
		teacher: "Mr. Park",
		percentage: 90,
		letterGrade: "A-",
		assessments: [
			{ name: "Source Analysis", score: 18, total: 20 },
			{ name: "Timeline Assignment", score: 27, total: 30 },
			{ name: "Midterm Exam", score: 44, total: 50 },
		],
	},
	{
		subjectId: "japanese",
		subject: "Japanese",
		teacher: "Ms. Sato",
		percentage: 87,
		letterGrade: "B+",
		assessments: [
			{ name: "Vocabulary Quiz", score: 17, total: 20 },
			{ name: "Writing Exercise", score: 22, total: 25 },
			{ name: "Conversation Check", score: 44, total: 50 },
		],
	},
	{
		subjectId: "computer-science",
		subject: "Computer Science",
		teacher: "Mr. Han",
		percentage: 89,
		letterGrade: "B+",
		assessments: [
			{ name: "Code Quiz", score: 19, total: 20 },
			{ name: "Programming Task", score: 22, total: 25 },
			{ name: "Project Review", score: 42, total: 50 },
		],
	},
]

export const studentAttendanceRecords = [
	{ id: "attendance-1", date: "2026-09-29", subjectId: "mathematics", subject: "Mathematics", status: "Present", remarks: "" },
	{ id: "attendance-2", date: "2026-09-28", subjectId: "mathematics", subject: "Mathematics", status: "Late", remarks: "Arrived after the bell" },
	{ id: "attendance-3", date: "2026-09-25", subjectId: "mathematics", subject: "Mathematics", status: "Present", remarks: "" },
	{ id: "attendance-4", date: "2026-09-29", subjectId: "english", subject: "English", status: "Present", remarks: "" },
	{ id: "attendance-5", date: "2026-09-26", subjectId: "english", subject: "English", status: "Present", remarks: "" },
	{ id: "attendance-6", date: "2026-09-24", subjectId: "english", subject: "English", status: "Absent", remarks: "Excused absence" },
	{ id: "attendance-7", date: "2026-09-28", subjectId: "science", subject: "Science", status: "Present", remarks: "" },
	{ id: "attendance-8", date: "2026-09-25", subjectId: "science", subject: "Science", status: "Present", remarks: "" },
	{ id: "attendance-9", date: "2026-09-23", subjectId: "science", subject: "Science", status: "Present", remarks: "" },
	{ id: "attendance-10", date: "2026-09-29", subjectId: "history", subject: "History", status: "Late", remarks: "Bus delay" },
	{ id: "attendance-11", date: "2026-09-26", subjectId: "history", subject: "History", status: "Present", remarks: "" },
	{ id: "attendance-12", date: "2026-09-24", subjectId: "history", subject: "History", status: "Present", remarks: "" },
	{ id: "attendance-13", date: "2026-09-28", subjectId: "japanese", subject: "Japanese", status: "Present", remarks: "" },
	{ id: "attendance-14", date: "2026-09-25", subjectId: "japanese", subject: "Japanese", status: "Absent", remarks: "" },
	{ id: "attendance-15", date: "2026-09-22", subjectId: "japanese", subject: "Japanese", status: "Present", remarks: "" },
	{ id: "attendance-16", date: "2026-09-29", subjectId: "computer-science", subject: "Computer Science", status: "Present", remarks: "" },
	{ id: "attendance-17", date: "2026-09-26", subjectId: "computer-science", subject: "Computer Science", status: "Present", remarks: "" },
	{ id: "attendance-18", date: "2026-09-23", subjectId: "computer-science", subject: "Computer Science", status: "Late", remarks: "" },
]

export const studentLearningProgress = [
	{ subjectId: "mathematics", subject: "Mathematics", progress: 90, completedLessons: 9, totalLessons: 10 },
	{ subjectId: "english", subject: "English", progress: 80, completedLessons: 8, totalLessons: 10 },
	{ subjectId: "science", subject: "Science", progress: 75, completedLessons: 6, totalLessons: 8 },
	{ subjectId: "history", subject: "History", progress: 85, completedLessons: 17, totalLessons: 20 },
	{ subjectId: "japanese", subject: "Japanese", progress: 70, completedLessons: 7, totalLessons: 10 },
	{ subjectId: "computer-science", subject: "Computer Science", progress: 92, completedLessons: 23, totalLessons: 25 },
]

export const studentProgressStats = {
	assignmentsCompleted: 8,
	totalAssignments: 10,
	quizzesCompleted: 6,
	totalQuizzes: 8,
	quizAverage: 87,
}

export const studentLearningActivities = [
	{ id: "learning-activity-1", date: "2026-09-29", title: "Completed Mathematics Quiz", subject: "Mathematics", type: "Quiz" },
	{ id: "learning-activity-2", date: "2026-09-28", title: "Completed English Assignment", subject: "English", type: "Assignment" },
	{ id: "learning-activity-3", date: "2026-09-27", title: "Completed Science Lesson", subject: "Science", type: "Lesson" },
	{ id: "learning-activity-4", date: "2026-09-26", title: "Completed Japanese Quiz", subject: "Japanese", type: "Quiz" },
]

export const studentLearningAchievements = [
	{ title: "Quiz Master", description: "Completed 5 quizzes." },
	{ title: "Perfect Score", description: "Scored 100% on a quiz." },
	{ title: "Consistent Learner", description: "Completed lessons in 5 subjects." },
]

export const teacherDashboardData = {
	teacherName: "Mr. Kim",
	classes: [
		{
			id: "class-math-101",
			name: "Mathematics 101",
			subject: "Mathematics",
			status: "Active",
			students: 24,
			schedule: "Mon, Wed, Fri | 09:00 - 10:00",
			room: "Room 201",
		},
		{
			id: "class-english-201",
			name: "English Literature",
			subject: "English",
			status: "Active",
			students: 18,
			schedule: "Mon, Thu | 11:00 - 12:00",
			room: "Room 105",
		},
		{
			id: "class-science-110",
			name: "Science Lab",
			subject: "Science",
			status: "Active",
			students: 26,
			schedule: "Tue, Fri | 14:00 - 15:30",
			room: "Science Lab 2",
		},
		{
			id: "class-history-202",
			name: "World History",
			subject: "History",
			status: "Active",
			students: 28,
			schedule: "Tue, Thu | 13:00 - 14:00",
			room: "Room 302",
		},
	],
	upcomingClasses: [
		{ classId: "class-math-101", time: "09:00" },
		{ classId: "class-english-201", time: "11:00" },
		{ classId: "class-science-110", time: "14:00" },
	],
	pendingGrading: [
			{ id: "grading-math-quiz", title: "Mathematics Quiz", className: "Mathematics 101", submissions: 24, dueDate: "Sep 30", status: "Grading" },
			{ id: "grading-english-essay", title: "English Essay", className: "English Literature", submissions: 18, dueDate: "Oct 2", status: "Grading" },
			{ id: "grading-science-worksheet", title: "Science Worksheet", className: "Science Lab", submissions: 26, dueDate: "Oct 4", status: "Active" },
			{ id: "grading-history-report", title: "History Report", className: "World History", submissions: 28, dueDate: "Oct 7", status: "Active" },
			{ id: "grading-math-homework", title: "Algebra Practice", className: "Mathematics 101", submissions: 23, dueDate: "Oct 8", status: "Active" },
			{ id: "grading-english-reading", title: "Reading Response", className: "English Literature", submissions: 17, dueDate: "Oct 9", status: "Active" },
			{ id: "grading-science-lab", title: "Lab Reflection", className: "Science Lab", submissions: 25, dueDate: "Oct 10", status: "Grading" },
			{ id: "grading-history-map", title: "Historical Map", className: "World History", submissions: 27, dueDate: "Oct 11", status: "Active" },
			{ id: "grading-math-test", title: "Unit Test", className: "Mathematics 101", submissions: 24, dueDate: "Oct 12", status: "Active" },
			{ id: "grading-english-review", title: "Book Review", className: "English Literature", submissions: 18, dueDate: "Oct 13", status: "Active" },
			{ id: "grading-science-project", title: "Science Project", className: "Science Lab", submissions: 26, dueDate: "Oct 14", status: "Completed" },
			{ id: "grading-history-essay", title: "History Essay", className: "World History", submissions: 28, dueDate: "Oct 15", status: "Completed" },
	],
	recentQuizActivity: [
		{ id: "quiz-activity-1", description: "Chanyeol completed Mathematics Quiz", timeAgo: "2 minutes ago" },
		{ id: "quiz-activity-2", description: "English Literature quiz submission received", timeAgo: "18 minutes ago" },
		{ id: "quiz-activity-3", description: "Science Lab quiz published", timeAgo: "1 hour ago" },
	],
	recentAnnouncements: [
		{ id: "teacher-announcement-1", title: "Midterm review resources", content: "The midterm review packet and worked examples are ready. Please bring your questions to our next class review.", targetClass: "Mathematics 101", date: "Sep 29, 2026", status: "Published" },
		{ id: "teacher-announcement-2", title: "Reading discussion moved to Thursday", content: "This week's reading discussion will meet on Thursday. Please finish the assigned chapters and bring one passage to discuss.", targetClass: "English Literature", date: "Sep 28, 2026", status: "Published" },
		{ id: "teacher-announcement-3", title: "Lab safety reminders", content: "Wear safety glasses during experiments, keep work areas clear, and follow the lab equipment instructions.", targetClass: "Science Lab", date: "Sep 26, 2026", status: "Draft" },
	],
}

const teacherNames = [...new Set([
	teacherDashboardData.teacherName,
	...studentSubjects.map((subject) => subject.teacher),
])]

export const adminTeacherRecords = teacherNames.map((name) => {
	const assignedSubjects = name === teacherDashboardData.teacherName
		? [...new Set(teacherDashboardData.classes.map((classItem) => classItem.subject))]
		: studentSubjects.filter((subject) => subject.teacher === name).map((subject) => subject.name)
	const assignedClasses = name === teacherDashboardData.teacherName
		? teacherDashboardData.classes
		: teacherDashboardData.classes.filter((classItem) => assignedSubjects.includes(classItem.subject))
	const teacherId = `TCH-${name.replace(/[^a-z\d]/gi, "").toUpperCase()}`

	return {
		id: teacherId.toLowerCase(),
		teacherId,
		name,
		status: "Active",
		subjects: assignedSubjects,
		classIds: assignedClasses.map((classItem) => classItem.id),
	}
})

export const teacherScheduleRecords = [
	{ id: "schedule-math-2026-09-28", classId: "class-math-101", date: "2026-09-28", startTime: "09:00", endTime: "10:00", status: "Completed" },
	{ id: "schedule-english-2026-09-28", classId: "class-english-201", date: "2026-09-28", startTime: "11:00", endTime: "12:00", status: "Completed" },
	{ id: "schedule-history-2026-09-29", classId: "class-history-202", date: "2026-09-29", startTime: "13:00", endTime: "14:00", status: "Ongoing" },
	{ id: "schedule-science-2026-09-29", classId: "class-science-110", date: "2026-09-29", startTime: "14:00", endTime: "15:30", status: "Upcoming" },
	{ id: "schedule-math-2026-09-30", classId: "class-math-101", date: "2026-09-30", startTime: "09:00", endTime: "10:00", status: "Upcoming" },
	{ id: "schedule-english-2026-10-01", classId: "class-english-201", date: "2026-10-01", startTime: "11:00", endTime: "12:00", status: "Upcoming" },
	{ id: "schedule-history-2026-10-01", classId: "class-history-202", date: "2026-10-01", startTime: "13:00", endTime: "14:00", status: "Upcoming" },
	{ id: "schedule-math-2026-10-02", classId: "class-math-101", date: "2026-10-02", startTime: "09:00", endTime: "10:00", status: "Upcoming" },
	{ id: "schedule-science-2026-10-02", classId: "class-science-110", date: "2026-10-02", startTime: "14:00", endTime: "15:30", status: "Upcoming" },
]

export const teacherLearningMaterials = [
	{ id: "material-algebra-notes", title: "Linear Equations Review", description: "Lesson notes covering one-variable equations, inverse operations, and worked examples for the midterm review.", classId: "class-math-101", type: "Lesson Notes", date: "2026-09-29", status: "Published" },
	{ id: "material-functions-worksheet", title: "Functions Practice Worksheet", description: "Practice identifying functions, evaluating expressions, and interpreting input-output tables.", classId: "class-math-101", type: "Worksheet", date: "2026-09-27", status: "Draft" },
	{ id: "material-literature-pdf", title: "Character Analysis Guide", description: "A reading guide with prompts for tracking character motivation and supporting claims with passages from the text.", classId: "class-english-201", type: "PDF", date: "2026-09-28", status: "Published" },
	{ id: "material-poetry-presentation", title: "Poetry and Figurative Language", description: "Presentation introducing imagery, metaphor, and sound devices with short classroom examples.", classId: "class-english-201", type: "Presentation", date: "2026-09-25", status: "Published" },
	{ id: "material-lab-video", title: "Lab Safety Demonstration", description: "Short video demonstrating protective equipment, safe handling, and cleanup procedures for the current lab unit.", classId: "class-science-110", type: "Video", date: "2026-09-26", status: "Published" },
	{ id: "material-history-link", title: "Primary Sources: Ancient Civilizations", description: "Curated source collection for comparing trade, government, and daily life across ancient civilizations.", classId: "class-history-202", type: "Link", date: "2026-09-24", status: "Draft" },
]

export const teacherAssignmentDetails = {
	"grading-math-quiz": {
		status: "Grading",
		description: "Check students' understanding of linear equations and core algebra skills.",
		gradedSubmissions: 2,
		submittedDate: "Sep 29, 2026",
		gradesByStudent: { "STU-1042": "92%", "STU-1051": "88%" },
	},
	"grading-english-essay": {
		status: "Grading",
		description: "An essay response analyzing themes and character development in the class reading.",
		gradedSubmissions: 1,
		submittedDate: "Sep 29, 2026",
		gradesByStudent: { "STU-2014": "94%" },
	},
	"grading-science-worksheet": {
		status: "Active",
		description: "Review the scientific method, observations, and controlled experiments.",
		gradedSubmissions: 0,
		submittedDate: "Sep 29, 2026",
	},
	"grading-history-report": {
		status: "Active",
		description: "Prepare a short report about an important historical event covered in class.",
		gradedSubmissions: 0,
		submittedDate: "Sep 29, 2026",
	},
	"grading-math-homework": {
		status: "Active",
		description: "Practice solving multi-step algebra problems and show your work.",
		gradedSubmissions: 0,
		submittedDate: "Sep 28, 2026",
	},
	"grading-english-reading": {
		status: "Active",
		description: "Submit a short response on the assigned reading and its central ideas.",
		gradedSubmissions: 0,
		submittedDate: "Sep 28, 2026",
	},
	"grading-science-lab": {
		status: "Grading",
		description: "Summarize lab observations and explain how the results support the hypothesis.",
		gradedSubmissions: 4,
		submittedDate: "Sep 27, 2026",
	},
	"grading-history-map": {
		status: "Active",
		description: "Label key locations and trade routes on the historical map.",
		gradedSubmissions: 0,
		submittedDate: "Sep 27, 2026",
	},
	"grading-math-test": {
		status: "Grading",
		description: "Assess understanding of the current mathematics unit.",
		gradedSubmissions: 12,
		submittedDate: "Sep 26, 2026",
	},
	"grading-english-review": {
		status: "Active",
		description: "Write a review discussing the book's main ideas and supporting details.",
		gradedSubmissions: 0,
		submittedDate: "Sep 26, 2026",
	},
	"grading-science-project": {
		status: "Completed",
		description: "Present the results of a class science investigation.",
		gradedSubmissions: 26,
		submittedDate: "Sep 24, 2026",
	},
	"grading-history-essay": {
		status: "Completed",
		description: "Explain how a historical event influenced later developments.",
		gradedSubmissions: 28,
		submittedDate: "Sep 23, 2026",
	},
}

export const teacherClassDetails = {
	"class-math-101": {
		students: [
			{ id: "STU-1042", name: "Chanyeol Park", attendance: 96, grade: "A-", status: "Active" },
			{ id: "STU-1051", name: "Mina Lee", attendance: 100, grade: "A", status: "Active" },
			{ id: "STU-1078", name: "Jihoon Kim", attendance: 92, grade: "B+", status: "Active" },
		],
		assignments: [
			{ id: "math-quiz-1", name: "Mathematics Quiz", type: "Quiz", dueDate: "Sep 30", submissions: 24, status: "Grading" },
			{ id: "math-practice-2", name: "Algebra Practice", type: "Assignment", dueDate: "Oct 8", submissions: 12, status: "Active" },
			{ id: "math-review-1", name: "Number Review", type: "Assignment", dueDate: "Sep 20", submissions: 24, status: "Completed" },
		],
		quizActivity: [
			{ id: "math-event-1", description: "Chanyeol Park completed Mathematics Quiz", timeAgo: "2 minutes ago" },
			{ id: "math-event-2", description: "Mathematics Quiz submission received", timeAgo: "18 minutes ago" },
		],
	},
	"class-english-201": {
		students: [
			{ id: "STU-2014", name: "Yuna Choi", attendance: 94, grade: "A-", status: "Active" },
			{ id: "STU-2033", name: "Daniel Seo", attendance: 89, grade: "B+", status: "Active" },
			{ id: "STU-2048", name: "Sora Han", attendance: 98, grade: "A", status: "Active" },
		],
		assignments: [
			{ id: "english-essay-1", name: "English Essay", type: "Assignment", dueDate: "Oct 2", submissions: 18, status: "Grading" },
			{ id: "english-reading-1", name: "Reading Response", type: "Assignment", dueDate: "Oct 9", submissions: 8, status: "Active" },
			{ id: "english-quiz-1", name: "Vocabulary Quiz", type: "Quiz", dueDate: "Sep 18", submissions: 18, status: "Completed" },
		],
		quizActivity: [
			{ id: "english-event-1", description: "Yuna Choi submitted Vocabulary in Context", timeAgo: "12 minutes ago" },
			{ id: "english-event-2", description: "Reading Comprehension Quiz published", timeAgo: "1 hour ago" },
		],
	},
	"class-science-110": {
		students: [
			{ id: "STU-3012", name: "Alex Jung", attendance: 91, grade: "B+", status: "Active" },
			{ id: "STU-3027", name: "Hana Lim", attendance: 96, grade: "A-", status: "Active" },
			{ id: "STU-3054", name: "Min Park", attendance: 88, grade: "B", status: "Active" },
		],
		assignments: [
			{ id: "science-worksheet-1", name: "Science Worksheet", type: "Assignment", dueDate: "Oct 4", submissions: 26, status: "Active" },
			{ id: "science-lab-1", name: "Lab Reflection", type: "Assignment", dueDate: "Oct 10", submissions: 14, status: "Active" },
			{ id: "science-quiz-1", name: "Scientific Method Review", type: "Quiz", dueDate: "Sep 21", submissions: 26, status: "Completed" },
		],
		quizActivity: [
			{ id: "science-event-1", description: "Min Park completed Scientific Method Review", timeAgo: "35 minutes ago" },
			{ id: "science-event-2", description: "Science Lab Quiz submission received", timeAgo: "Yesterday" },
		],
	},
	"class-history-202": {
		students: [
			{ id: "STU-4010", name: "Jae Moon", attendance: 97, grade: "A", status: "Active" },
			{ id: "STU-4039", name: "Nari Cho", attendance: 93, grade: "A-", status: "Active" },
			{ id: "STU-4061", name: "Eric Yoon", attendance: 86, grade: "B", status: "Inactive" },
		],
		assignments: [
			{ id: "history-report-1", name: "History Report", type: "Assignment", dueDate: "Oct 7", submissions: 28, status: "Active" },
			{ id: "history-map-1", name: "Historical Map", type: "Assignment", dueDate: "Oct 11", submissions: 10, status: "Active" },
			{ id: "history-quiz-1", name: "World History Review", type: "Quiz", dueDate: "Sep 19", submissions: 28, status: "Completed" },
		],
		quizActivity: [
			{ id: "history-event-1", description: "Jae Moon submitted World History Review", timeAgo: "25 minutes ago" },
			{ id: "history-event-2", description: "Ancient Civilizations Quiz published", timeAgo: "Yesterday" },
		],
	},
}

export const teacherAttendanceRecords = [
	{ studentId: "STU-1042", classId: "class-math-101", date: "2026-09-29", status: "Present" },
	{ studentId: "STU-1051", classId: "class-math-101", date: "2026-09-29", status: "Late" },
	{ studentId: "STU-1078", classId: "class-math-101", date: "2026-09-29", status: "Present" },
	{ studentId: "STU-2014", classId: "class-english-201", date: "2026-09-29", status: "Present" },
	{ studentId: "STU-2033", classId: "class-english-201", date: "2026-09-29", status: "Present" },
	{ studentId: "STU-2048", classId: "class-english-201", date: "2026-09-29", status: "Absent" },
	{ studentId: "STU-3012", classId: "class-science-110", date: "2026-09-29", status: "Present" },
	{ studentId: "STU-3027", classId: "class-science-110", date: "2026-09-29", status: "Late" },
	{ studentId: "STU-3054", classId: "class-science-110", date: "2026-09-29", status: "Present" },
	{ studentId: "STU-4010", classId: "class-history-202", date: "2026-09-29", status: "Present" },
	{ studentId: "STU-4039", classId: "class-history-202", date: "2026-09-29", status: "Present" },
	{ studentId: "STU-4061", classId: "class-history-202", date: "2026-09-29", status: "Absent" },
	{ studentId: "STU-1042", classId: "class-math-101", date: "2026-09-28", status: "Present" },
	{ studentId: "STU-1051", classId: "class-math-101", date: "2026-09-28", status: "Present" },
	{ studentId: "STU-1078", classId: "class-math-101", date: "2026-09-28", status: "Late" },
	{ studentId: "STU-2014", classId: "class-english-201", date: "2026-09-28", status: "Late" },
	{ studentId: "STU-2033", classId: "class-english-201", date: "2026-09-28", status: "Present" },
	{ studentId: "STU-2048", classId: "class-english-201", date: "2026-09-28", status: "Present" },
	{ studentId: "STU-3012", classId: "class-science-110", date: "2026-09-28", status: "Absent" },
	{ studentId: "STU-3027", classId: "class-science-110", date: "2026-09-28", status: "Present" },
	{ studentId: "STU-3054", classId: "class-science-110", date: "2026-09-28", status: "Present" },
	{ studentId: "STU-4010", classId: "class-history-202", date: "2026-09-28", status: "Present" },
	{ studentId: "STU-4039", classId: "class-history-202", date: "2026-09-28", status: "Late" },
	{ studentId: "STU-4061", classId: "class-history-202", date: "2026-09-28", status: "Present" },
	{ studentId: "STU-1042", classId: "class-math-101", date: "2026-09-25", status: "Present" },
	{ studentId: "STU-1051", classId: "class-math-101", date: "2026-09-25", status: "Present" },
	{ studentId: "STU-1078", classId: "class-math-101", date: "2026-09-25", status: "Present" },
	{ studentId: "STU-2014", classId: "class-english-201", date: "2026-09-25", status: "Present" },
	{ studentId: "STU-2033", classId: "class-english-201", date: "2026-09-25", status: "Absent" },
	{ studentId: "STU-2048", classId: "class-english-201", date: "2026-09-25", status: "Present" },
	{ studentId: "STU-3012", classId: "class-science-110", date: "2026-09-25", status: "Present" },
	{ studentId: "STU-3027", classId: "class-science-110", date: "2026-09-25", status: "Present" },
	{ studentId: "STU-3054", classId: "class-science-110", date: "2026-09-25", status: "Absent" },
	{ studentId: "STU-4010", classId: "class-history-202", date: "2026-09-25", status: "Late" },
	{ studentId: "STU-4039", classId: "class-history-202", date: "2026-09-25", status: "Present" },
	{ studentId: "STU-4061", classId: "class-history-202", date: "2026-09-25", status: "Present" },
]

export const studentQuizzes = [
	{
		id: "algebra-skills-check",
		classId: "class-math-101",
		teacherStatus: "Published",
		title: "Algebra Skills Check",
		subject: "Mathematics",
		topic: "Linear equations",
		description: "Practice solving and checking one-step and two-step linear equations.",
		dueDate: "Oct 1, 2026",
		timeLimit: 1,
		maxAttempts: 2,
		attemptsUsed: 0,
		status: "Available",
		questions: [
			{
				id: "algebra-1",
				question: "Solve for x: x + 7 = 12.",
				choices: ["3", "5", "7", "19"],
				correctAnswer: "5",
			},
			{
				id: "algebra-2",
				question: "Solve for x: 3x = 21.",
				choices: ["6", "7", "18", "24"],
				correctAnswer: "7",
			},
			{
				id: "algebra-3",
				question: "Solve for x: 2x + 4 = 14.",
				choices: ["4", "5", "6", "9"],
				correctAnswer: "5",
			},
			{
				id: "algebra-4",
				question: "Solve for x: x / 4 = 3.",
				choices: ["7", "8", "12", "16"],
				correctAnswer: "12",
			},
			{
				id: "algebra-5",
				question: "Solve for x: 5x - 6 = 19.",
				choices: ["3", "4", "5", "6"],
				correctAnswer: "5",
			},
		],
	},
	{
		id: "vocabulary-in-context",
		classId: "class-english-201",
		teacherStatus: "Published",
		title: "Vocabulary in Context",
		subject: "English",
		topic: "Reading comprehension",
		description: "Identify word meanings and usage from short reading passages.",
		dueDate: "Oct 3, 2026",
		timeLimit: 2,
		maxAttempts: 3,
		attemptsUsed: 1,
		status: "Available",
		questions: [
			{
				id: "vocabulary-1",
				question: "Which word is closest in meaning to 'rapid'?",
				choices: ["Quiet", "Swift", "Narrow", "Careful"],
				correctAnswer: "Swift",
			},
			{
				id: "vocabulary-2",
				question: "In 'The arduous hike took all day,' what does 'arduous' mean?",
				choices: ["Difficult", "Brief", "Pleasant", "Ordinary"],
				correctAnswer: "Difficult",
			},
			{
				id: "vocabulary-3",
				question: "Which word is an antonym of 'generous'?",
				choices: ["Kind", "Selfish", "Helpful", "Friendly"],
				correctAnswer: "Selfish",
			},
			{
				id: "vocabulary-4",
				question: "Which word best completes the sentence: She gave a ___ explanation that was easy to follow.",
				choices: ["Clear", "Fragile", "Distant", "Silent"],
				correctAnswer: "Clear",
			},
			{
				id: "vocabulary-5",
				question: "What does 'observe' mean?",
				choices: ["To notice carefully", "To change quickly", "To explain briefly", "To forget completely"],
				correctAnswer: "To notice carefully",
			},
		],
	},
	{
		id: "scientific-method-review",
		classId: "class-science-110",
		teacherStatus: "Published",
		title: "Scientific Method Review",
		subject: "Science",
		topic: "Observation and experiments",
		description: "Review variables, observations, and the steps used in a controlled experiment.",
		dueDate: "Oct 6, 2026",
		timeLimit: 3,
		maxAttempts: 1,
		attemptsUsed: 0,
		status: "Available",
		questions: [
			{
				id: "science-1",
				question: "What is a testable explanation for an observation called?",
				choices: ["A conclusion", "A hypothesis", "A constant", "A measurement"],
				correctAnswer: "A hypothesis",
			},
			{
				id: "science-2",
				question: "In an experiment, which variable is deliberately changed?",
				choices: ["Dependent variable", "Control group", "Independent variable", "Constant"],
				correctAnswer: "Independent variable",
			},
			{
				id: "science-3",
				question: "Why is a control group useful?",
				choices: ["It provides a comparison", "It changes every variable", "It records the conclusion", "It replaces observations"],
				correctAnswer: "It provides a comparison",
			},
			{
				id: "science-4",
				question: "Which is an example of quantitative data?",
				choices: ["The leaf feels rough", "The liquid is blue", "The plant is 12 cm tall", "The rock looks shiny"],
				correctAnswer: "The plant is 12 cm tall",
			},
			{
				id: "science-5",
				question: "Why should an experiment be repeated?",
				choices: ["To make results more reliable", "To avoid recording data", "To change the hypothesis", "To remove the control"],
				correctAnswer: "To make results more reliable",
			},
		],
	},
	{
		id: "world-history-review",
		classId: "class-history-202",
		teacherStatus: "Published",
		title: "World History Review",
		subject: "History",
		topic: "Ancient civilizations",
		description: "Check your understanding of key events and ideas from ancient civilizations.",
		dueDate: "Oct 8, 2026",
		timeLimit: 4,
		maxAttempts: 2,
		attemptsUsed: 2,
		status: "Completed",
		questions: [
			{
				id: "history-1",
				question: "Which river was central to ancient Egyptian civilization?",
				choices: ["Amazon", "Nile", "Danube", "Indus"],
				correctAnswer: "Nile",
			},
			{
				id: "history-2",
				question: "Which ancient Greek city is known for developing democracy?",
				choices: ["Sparta", "Athens", "Corinth", "Thebes"],
				correctAnswer: "Athens",
			},
			{
				id: "history-3",
				question: "Which early civilization developed cuneiform writing?",
				choices: ["Sumer", "Rome", "Maya", "Persia"],
				correctAnswer: "Sumer",
			},
			{
				id: "history-4",
				question: "What was one major purpose of the Silk Road?",
				choices: ["Connecting trade routes", "Building Roman roads", "Mapping the oceans", "Moving the capital"],
				correctAnswer: "Connecting trade routes",
			},
			{
				id: "history-5",
				question: "What were many ancient Egyptian pyramids built to serve as?",
				choices: ["Markets", "Tombs", "Schools", "Harbors"],
				correctAnswer: "Tombs",
			},
		],
	},
]

export const teacherQuizDrafts = [
	{
		id: "quadratic-functions-draft",
		title: "Quadratic Functions Practice",
		classId: "class-math-101",
		subject: "Mathematics",
		topic: "Quadratic functions",
		description: "Practice identifying and interpreting quadratic functions.",
		dueDate: "Oct 15, 2026",
		timeLimit: 20,
		maxAttempts: 2,
		attemptsUsed: 0,
		status: "Draft",
		questions: [],
	},
]

export const teacherQuizzes = [
	...studentQuizzes.map(({ teacherStatus, ...quiz }) => ({
		...quiz,
		status: teacherStatus ?? "Published",
	})),
	...teacherQuizDrafts,
]

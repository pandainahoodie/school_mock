function Sidebar() {
  return (
    <aside>
      <h2>Park Chanyeol School</h2>

      <nav>
        <p>Dashboard</p>
        <p>My Classes</p>
        <p>Quizzes</p>
        <p>Assignments</p>
        <p>Attendance</p>
        <p>Grades</p>
        <p>Announcements</p>
        <p>Schedule</p>
      </nav>
    </aside>
  )
}

export default Sidebar
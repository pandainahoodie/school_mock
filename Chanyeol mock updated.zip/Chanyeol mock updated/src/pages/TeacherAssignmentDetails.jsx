import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom"
import {
  teacherAssignmentDetails,
  teacherClassDetails,
  teacherDashboardData,
} from "../../Data/mockData"
import "./TeacherAssignmentDetails.css"

const statusFilters = ["All", "Submitted", "Pending", "Graded"]

function TeacherAssignmentDetails() {
  const { assignmentId } = useParams()
  const navigate = useNavigate()
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("All")
  const assignment = teacherDashboardData.pendingGrading.find((item) => item.id === assignmentId)
  const assignmentDetails = teacherAssignmentDetails[assignmentId]
  const classItem = assignment
    ? teacherDashboardData.classes.find((item) => item.name === assignment.className)
    : null

  if (!assignment || !assignmentDetails || !classItem) {
    return (
      <div className="teacher-assignment-details">
        <section className="teacher-assignment-details__not-found">
          <h1>Assignment not found</h1>
          <button type="button" onClick={() => navigate("/teacher/assignments")}>
            Back to Assignments
          </button>
        </section>
      </div>
    )
  }

  const classRoster = teacherClassDetails[classItem.id]?.students ?? []
  const totalStudents = classItem.students
  const gradedCount = Math.min(
    assignment.status === "Completed"
      ? assignment.submissions
      : assignmentDetails.gradedSubmissions ?? 0,
    assignment.submissions,
  )
  const submittedCount = Math.max(assignment.submissions - gradedCount, 0)
  const pendingCount = Math.max(totalStudents - submittedCount - gradedCount, 0)
  const submissions = classRoster.map((student, index) => {
    let status = "Pending"
    if (index < gradedCount) {
      status = "Graded"
    } else if (index < assignment.submissions) {
      status = "Submitted"
    }

    return {
      ...student,
      status,
      submittedDate: status === "Pending" ? "—" : assignmentDetails.submittedDate,
      grade: status === "Graded"
        ? assignmentDetails.gradesByStudent?.[student.id] ?? student.grade
        : null,
    }
  })
  const normalizedSearch = search.trim().toLowerCase()
  const filteredSubmissions = submissions.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(normalizedSearch) ||
      student.id.toLowerCase().includes(normalizedSearch)
    const matchesStatus = statusFilter === "All" || student.status === statusFilter

    return matchesSearch && matchesStatus
  })
  const completedSubmissions = submittedCount + gradedCount
  const submissionPercent = totalStudents > 0 ? (completedSubmissions / totalStudents) * 100 : 0

  return (
    <div className="teacher-assignment-details">
      <button
        className="teacher-assignment-details__back-button"
        type="button"
        onClick={() => navigate("/teacher/assignments")}
      >
        Back to Assignments
      </button>

      <header className="teacher-assignment-details__heading">
        <div>
          <p className="teacher-assignment-details__eyebrow">{assignment.className} · {classItem.subject}</p>
          <h1>{assignment.title}</h1>
          <p>{assignmentDetails.description}</p>
        </div>
        <span className={`teacher-assignment-details__status teacher-assignment-details__status--${assignmentDetails.status.toLowerCase()}`}>
          {assignmentDetails.status}
        </span>
      </header>

      <section className="teacher-assignment-details__overview" aria-label="Assignment overview">
        <article>
          <span>Class</span>
          <strong>{assignment.className}</strong>
        </article>
        <article>
          <span>Subject</span>
          <strong>{classItem.subject}</strong>
        </article>
        <article>
          <span>Due Date</span>
          <strong>{assignment.dueDate}, 2026</strong>
        </article>
        <article>
          <span>Total Students</span>
          <strong>{totalStudents}</strong>
        </article>
        <article>
          <span>Submissions</span>
          <strong>{assignment.submissions}</strong>
        </article>
      </section>

      <section className="teacher-assignment-details__progress-section" aria-labelledby="submission-progress-title">
        <div className="teacher-assignment-details__section-heading">
          <h2 id="submission-progress-title">Submission Progress</h2>
          <span>{completedSubmissions} / {totalStudents} submitted or graded</span>
        </div>
        <div
          className="teacher-assignment-details__progress-track"
          role="progressbar"
          aria-label="Assignment submission progress"
          aria-valuemin="0"
          aria-valuemax={totalStudents}
          aria-valuenow={completedSubmissions}
        >
          <span
            className="teacher-assignment-details__progress-submitted"
            style={{ width: `${(submittedCount / (totalStudents || 1)) * 100}%` }}
          />
          <span
            className="teacher-assignment-details__progress-graded"
            style={{ width: `${(gradedCount / (totalStudents || 1)) * 100}%` }}
          />
        </div>
        <div className="teacher-assignment-details__progress-counts">
          <span><i className="teacher-assignment-details__legend teacher-assignment-details__legend--submitted" />Submitted <strong>{submittedCount}</strong></span>
          <span><i className="teacher-assignment-details__legend teacher-assignment-details__legend--pending" />Pending <strong>{pendingCount}</strong></span>
          <span><i className="teacher-assignment-details__legend teacher-assignment-details__legend--graded" />Graded <strong>{gradedCount}</strong></span>
          <span className="teacher-assignment-details__progress-percent">{submissionPercent.toFixed(0)}%</span>
        </div>
      </section>

      <section className="teacher-assignment-details__section" aria-labelledby="student-submissions-title">
        <div className="teacher-assignment-details__toolbar">
          <h2 id="student-submissions-title">Student Submissions</h2>
          <div className="teacher-assignment-details__filters">
            <label>
              <span className="teacher-assignment-details__visually-hidden">Search students by name or ID</span>
              <input
                type="search"
                placeholder="Search students..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="teacher-assignment-details__visually-hidden">Filter submissions by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                {statusFilters.map((status) => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
            </label>
          </div>
        </div>

        <div className="teacher-assignment-details__table-wrap">
          <table className="teacher-assignment-details__table">
            <thead>
              <tr>
                <th scope="col">Student</th>
                <th scope="col">Student ID</th>
                <th scope="col">Status</th>
                <th scope="col">Submitted Date</th>
                <th scope="col">Grade</th>
              </tr>
            </thead>
            <tbody>
              {filteredSubmissions.length > 0 ? filteredSubmissions.map((student) => (
                <tr key={student.id}>
                  <th scope="row" data-label="Student">{student.name}</th>
                  <td data-label="Student ID">{student.id}</td>
                  <td data-label="Status">
                    <span className={`teacher-assignment-details__status teacher-assignment-details__status--${student.status.toLowerCase()}`}>
                      {student.status}
                    </span>
                  </td>
                  <td data-label="Submitted Date">{student.submittedDate}</td>
                  <td data-label="Grade">{student.grade ?? "—"}</td>
                </tr>
              )) : (
                <tr>
                  <td className="teacher-assignment-details__empty" colSpan="5">
                    No submissions match your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

export default TeacherAssignmentDetails

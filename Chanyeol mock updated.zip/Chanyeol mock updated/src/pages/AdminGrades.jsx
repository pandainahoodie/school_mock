import { useState } from "react"
import { Link } from "react-router-dom"
import {
  studentGrades,
  teacherClassDetails,
  teacherDashboardData,
} from "../../Data/mockData"
import "./AdminGrades.css"

const rosterStudents = Object.values(teacherClassDetails)
  .flatMap((classDetails) => classDetails.students)
const student = rosterStudents.find((record) => record.name === "Chanyeol Park")
const classBySubject = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.subject, classItem]),
)
const gradeRecords = studentGrades.flatMap((subject) => {
  const classItem = classBySubject[subject.subject]

  return subject.assessments.map((assessment) => {
    const percentage = assessment.total > 0 ? (assessment.score / assessment.total) * 100 : 0

    return {
      id: `${subject.subjectId}-${assessment.name}`,
      studentName: student?.name ?? "Chanyeol Park",
      studentId: student?.id ?? "",
      classId: classItem?.id ?? "",
      className: classItem?.name ?? "No class assigned",
      subjectId: subject.subjectId,
      subject: subject.subject,
      assessment: assessment.name,
      score: assessment.score,
      total: assessment.total,
      percentage,
      status: percentage < 85 ? "Needs Attention" : "Passing",
    }
  })
})
const subjects = [...new Set(gradeRecords.map((record) => record.subject))]

function formatPercentage(value) {
  return `${value.toFixed(1).replace(/\.0$/, "")}%`
}

function AdminGrades() {
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("All classes")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const normalizedSearch = search.trim().toLowerCase()
  const filteredRecords = gradeRecords.filter((record) => {
    const matchesSearch = [record.studentName, record.studentId, record.subject, record.className]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesClass = classFilter === "All classes" || record.classId === classFilter
    const matchesSubject = subjectFilter === "All subjects" || record.subject === subjectFilter
    const matchesStatus = statusFilter === "All statuses" || record.status === statusFilter

    return matchesSearch && matchesClass && matchesSubject && matchesStatus
  })
  const averagePercentage = filteredRecords.length > 0
    ? filteredRecords.reduce((total, record) => total + record.percentage, 0) / filteredRecords.length
    : 0
  const passingCount = filteredRecords.filter((record) => record.status === "Passing").length
  const needsAttentionCount = filteredRecords.filter((record) => record.status === "Needs Attention").length
  const summary = [
    { label: "Total Records", value: filteredRecords.length },
    { label: "Students", value: new Set(filteredRecords.map((record) => record.studentId)).size },
    { label: "Overall Average", value: formatPercentage(averagePercentage) },
    { label: "Passing", value: passingCount },
    { label: "Needs Attention", value: needsAttentionCount },
  ]
  const subjectSummaries = subjects.map((subject) => {
    const records = filteredRecords.filter((record) => record.subject === subject)
    const average = records.length > 0
      ? records.reduce((total, record) => total + record.percentage, 0) / records.length
      : 0

    return {
      subject,
      subjectId: records[0]?.subjectId ?? studentGrades.find((item) => item.subject === subject)?.subjectId,
      records: records.length,
      average,
      passing: records.filter((record) => record.status === "Passing").length,
      needsAttention: records.filter((record) => record.status === "Needs Attention").length,
    }
  }).filter((summaryItem) => summaryItem.records > 0)

  return (
    <div className="admin-grades">
      <header className="admin-grades__heading">
        <h1>Grades</h1>
        <p>Monitor student academic performance across the school.</p>
      </header>

      <section className="admin-grades__summary" aria-label="Grade summary">
        {summary.map(({ label, value }) => (
          <article className="admin-grades__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-grades__section" aria-labelledby="admin-grade-records-title">
        <div className="admin-grades__toolbar">
          <div>
            <h2 id="admin-grade-records-title">Assessment Records</h2>
            <p>Showing {filteredRecords.length} of {gradeRecords.length}</p>
          </div>
          <div className="admin-grades__filters">
            <label>
              <span className="admin-grades__visually-hidden">Search grades by student, ID, subject, or class</span>
              <input
                type="search"
                placeholder="Search grades..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="admin-grades__visually-hidden">Filter grades by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {teacherDashboardData.classes.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span className="admin-grades__visually-hidden">Filter grades by subject</span>
              <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
                <option value="All subjects">All subjects</option>
                {subjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
              </select>
            </label>
            <label>
              <span className="admin-grades__visually-hidden">Filter grades by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Passing">Passing</option>
                <option value="Needs Attention">Needs Attention</option>
              </select>
            </label>
          </div>
        </div>

        <div className="admin-grades__table-wrap">
          <table className="admin-grades__table">
            <thead>
              <tr>
                <th scope="col">Student</th>
                <th scope="col">Student ID</th>
                <th scope="col">Class</th>
                <th scope="col">Subject</th>
                <th scope="col">Score</th>
                <th scope="col">Percentage</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredRecords.length > 0 ? filteredRecords.map((record) => (
                <tr key={record.id}>
                  <th scope="row" data-label="Student">
                    <Link to={`/admin/students/${record.studentId}`}>{record.studentName}</Link>
                  </th>
                  <td data-label="Student ID">{record.studentId}</td>
                  <td data-label="Class">
                    {record.classId ? <Link to={`/admin/classes/${record.classId}`}>{record.className}</Link> : record.className}
                  </td>
                  <td data-label="Subject">
                    <Link to={`/admin/subjects/${record.subjectId}`}>{record.subject}</Link>
                  </td>
                  <td data-label="Score">{record.score} / {record.total}</td>
                  <td data-label="Percentage">{formatPercentage(record.percentage)}</td>
                  <td data-label="Status">
                    <span className={`admin-grades__status admin-grades__status--${record.status === "Passing" ? "passing" : "attention"}`}>
                      {record.status}
                    </span>
                  </td>
                  <td data-label="Action">
                    <Link className="admin-grades__view-link" to={`/admin/students/${record.studentId}`}>
                      View Student
                    </Link>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="admin-grades__empty" colSpan="8">No grade records match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="admin-grades__section" aria-labelledby="admin-subject-grade-title">
        <div className="admin-grades__section-heading">
          <h2 id="admin-subject-grade-title">Performance by Subject</h2>
        </div>
        <div className="admin-grades__subject-grid">
          {subjectSummaries.map((subject) => (
            <article className="admin-grades__subject-card" key={subject.subjectId}>
              <div className="admin-grades__subject-heading">
                <Link to={`/admin/subjects/${subject.subjectId}`}>{subject.subject}</Link>
                <strong>{formatPercentage(subject.average)}</strong>
              </div>
              <span>{subject.records} records</span>
              <div className="admin-grades__subject-counts">
                <span>Passing <strong>{subject.passing}</strong></span>
                <span>Needs Attention <strong>{subject.needsAttention}</strong></span>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}

export default AdminGrades
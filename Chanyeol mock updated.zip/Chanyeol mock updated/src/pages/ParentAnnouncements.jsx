import { Link } from "react-router-dom"
import { teacherDashboardData } from "../../Data/mockData"
import "./ParentAnnouncements.css"

const STUDENT_CLASS = "Mathematics 101"
const announcements = teacherDashboardData.recentAnnouncements
  .filter((announcement) => announcement.targetClass === STUDENT_CLASS && announcement.status === "Published")
  .map((announcement) => ({
    ...announcement,
    author: teacherDashboardData.teacherName,
  }))
  .sort((left, right) => Date.parse(right.date) - Date.parse(left.date))

function ParentAnnouncements() {
  return (
    <div className="parent-academic parent-announcements">
      <header className="parent-academic__heading">
        <div>
          <h1>Announcements</h1>
          <p>School updates shared with Chanyeol's class.</p>
        </div>
        <Link className="parent-academic__back-link" to="/parent">Parent Dashboard</Link>
      </header>

      <section className="parent-academic__section" aria-labelledby="parent-announcements-title">
        <div className="parent-academic__section-heading">
          <h2 id="parent-announcements-title">Class Announcements</h2>
          <span>{announcements.length} updates</span>
        </div>
        <div className="parent-announcements__list">
          {announcements.length > 0 ? announcements.map((announcement) => (
            <article className="parent-announcements__card" key={announcement.id}>
              <div className="parent-announcements__card-heading">
                <div>
                  <h3>{announcement.title}</h3>
                  <span>{announcement.targetClass}</span>
                </div>
                <span className={`parent-academic__status parent-academic__status--${announcement.status.toLowerCase()}`}>
                  {announcement.status}
                </span>
              </div>
              <p>{announcement.content}</p>
              <footer><span>{announcement.author}</span><time>{announcement.date}</time></footer>
            </article>
          )) : <p className="parent-academic__empty">No announcements are available for this class.</p>}
        </div>
      </section>
    </div>
  )
}

export default ParentAnnouncements
import {
  studentLearningActivities,
  studentLearningAchievements,
  studentLearningProgress,
  studentProgressStats,
} from "../../Data/mockData"
import "./Progress.css"

function formatActivityDate(date) {
  const [year, month, day] = date.split("-").map(Number)
  return new Date(year, month - 1, day).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  })
}

function Progress() {
  const overallProgress = studentLearningProgress.length > 0
    ? studentLearningProgress.reduce((total, subject) => total + subject.progress, 0) /
      studentLearningProgress.length
    : 0
  const recentActivities = [...studentLearningActivities].sort((left, right) =>
    right.date.localeCompare(left.date),
  )

  return (
    <div className="progress-page">
      <div className="progress-page__heading">
        <h1>Learning Progress</h1>
        <p>Track your learning completion, practice, and recent activity.</p>
      </div>

      <section className="progress-page__overview" aria-label="Overall learning progress">
        <article className="progress-page__overall-card">
          <div className="progress-page__overall-heading">
            <div>
              <span>Overall Progress</span>
              <strong>{overallProgress.toFixed(0)}%</strong>
            </div>
            <span className="progress-page__subject-count">{studentLearningProgress.length} subjects</span>
          </div>
          <div
            className="progress-page__progress-track progress-page__progress-track--overall"
            role="progressbar"
            aria-label="Overall learning progress"
            aria-valuemin="0"
            aria-valuemax="100"
            aria-valuenow={overallProgress}
          >
            <span style={{ width: `${overallProgress}%` }} />
          </div>
        </article>

        <div className="progress-page__stats">
          <article className="progress-page__stat-card">
            <span>Assignments Completed</span>
            <strong>{studentProgressStats.assignmentsCompleted} / {studentProgressStats.totalAssignments}</strong>
          </article>
          <article className="progress-page__stat-card">
            <span>Quizzes Completed</span>
            <strong>{studentProgressStats.quizzesCompleted} / {studentProgressStats.totalQuizzes}</strong>
          </article>
          <article className="progress-page__stat-card">
            <span>Quiz Average</span>
            <strong>{studentProgressStats.quizAverage}%</strong>
          </article>
        </div>
      </section>

      <section className="progress-page__section" aria-labelledby="subject-progress-title">
        <div className="progress-page__section-heading">
          <h2 id="subject-progress-title">Subject Progress</h2>
        </div>
        <div className="progress-page__subject-grid">
          {studentLearningProgress.map((subject) => (
            <article className="progress-page__subject-card" key={subject.subjectId}>
              <div className="progress-page__subject-heading">
                <h3>{subject.subject}</h3>
                <strong>{subject.progress}%</strong>
              </div>
              <div
                className="progress-page__progress-track"
                role="progressbar"
                aria-label={`${subject.subject} learning progress`}
                aria-valuemin="0"
                aria-valuemax="100"
                aria-valuenow={subject.progress}
              >
                <span style={{ width: `${subject.progress}%` }} />
              </div>
              <p>{subject.completedLessons} / {subject.totalLessons} lessons completed</p>
            </article>
          ))}
        </div>
      </section>

      <div className="progress-page__lower-grid">
        <section className="progress-page__section" aria-labelledby="recent-activity-title">
          <div className="progress-page__section-heading">
            <h2 id="recent-activity-title">Recent Learning Activity</h2>
          </div>
          <ol className="progress-page__activity-list">
            {recentActivities.map((activity) => (
              <li className="progress-page__activity-item" key={activity.id}>
                <time dateTime={activity.date}>{formatActivityDate(activity.date)}</time>
                <div>
                  <strong>{activity.title}</strong>
                  <span>{activity.subject}</span>
                </div>
                <span className="progress-page__activity-type">{activity.type}</span>
              </li>
            ))}
          </ol>
        </section>

        <section className="progress-page__section" aria-labelledby="achievements-title">
          <div className="progress-page__section-heading">
            <h2 id="achievements-title">Achievements</h2>
          </div>
          <div className="progress-page__achievement-list">
            {studentLearningAchievements.map((achievement) => (
              <article className="progress-page__achievement-card" key={achievement.title}>
                <span className="progress-page__achievement-badge">Earned</span>
                <h3>{achievement.title}</h3>
                <p>{achievement.description}</p>
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}

export default Progress

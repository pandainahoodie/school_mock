import { Link, useNavigate, useParams } from "react-router-dom"
import {
  studentSubjects,
  teacherClassDetails,
  teacherDashboardData,
  teacherScheduleRecords,
} from "../../Data/mockData"
import "./AdminSubjects.css"

const classRecords = teacherDashboardData.classes
const classById = Object.fromEntries(classRecords.map((classItem) => [classItem.id, classItem]))

function formatTime(time) {
  const [hours, minutes] = time.split(":").map(Number)

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "UTC",
  }).format(new Date(Date.UTC(2026, 0, 1, hours, minutes)))
}

function AdminSubjectDetails() {
  const { subjectId } = useParams()
  const navigate = useNavigate()
  const subject = studentSubjects.find((item) => item.id === subjectId)

  if (!subject) {
    return (
      <div className="admin-subject-details">
        <section className="admin-subject-details__not-found">
          <h1>Subject not found</h1>
          <button type="button" onClick={() => navigate("/admin/subjects")}>
            Back to Subjects
          </button>
        </section>
      </div>
    )
  }

  const assignedClasses = classRecords.filter((classItem) => classItem.subject === subject.name)
  const studentRecords = [...new Map(assignedClasses.flatMap((classItem) => (
    teacherClassDetails[classItem.id]?.students ?? []
  )).map((student) => [student.id, student])).values()]
  const schedules = teacherScheduleRecords
    .filter((record) => assignedClasses.some((classItem) => classItem.id === record.classId))
    .sort((left, right) => left.date.localeCompare(right.date) || left.startTime.localeCompare(right.startTime))
  const assignments = assignedClasses.flatMap((classItem) => (
    teacherClassDetails[classItem.id]?.assignments ?? []
  )).slice(0, 5)
  const quizActivity = assignedClasses.flatMap((classItem) => (
    teacherClassDetails[classItem.id]?.quizActivity ?? []
  )).slice(0, 5)

  return (
    <div className="admin-subject-details">
      <button
        className="admin-subject-details__back-button"
        type="button"
        onClick={() => navigate("/admin/subjects")}
      >
        Back to Subjects
      </button>

      <header className="admin-subject-details__heading">
        <div>
          <p className="admin-subject-details__eyebrow">School Subject</p>
          <h1>{subject.name}</h1>
        </div>
        <span className="admin-subjects__status admin-subjects__status--active">Active</span>
      </header>

      <section className="admin-subject-details__summary" aria-label="Subject overview">
        <article>
          <span>Teacher</span>
          <strong>{subject.teacher}</strong>
        </article>
        <article>
          <span>Classes</span>
          <strong>{assignedClasses.length}</strong>
        </article>
        <article>
          <span>Rostered Students</span>
          <strong>{studentRecords.length}</strong>
        </article>
      </section>

      <section className="admin-subject-details__section" aria-labelledby="subject-classes-title">
        <div className="admin-subject-details__section-heading">
          <h2 id="subject-classes-title">Assigned Classes</h2>
        </div>
        {assignedClasses.length > 0 ? (
          <div className="admin-subject-details__class-grid">
            {assignedClasses.map((classItem) => (
              <article className="admin-subject-details__class-card" key={classItem.id}>
                <div>
                  <h3>{classItem.name}</h3>
                  <span>{classItem.room} · {classItem.students} enrolled</span>
                </div>
                <div className="admin-subject-details__class-links">
                  <Link to={`/admin/classes/${classItem.id}`}>Class Details</Link>
                  <Link to={`/teacher/classes/${classItem.id}/students`}>Student Roster</Link>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <p className="admin-subject-details__empty">No classes are assigned to this subject yet.</p>
        )}
      </section>

      <div className="admin-subject-details__columns">
        <section className="admin-subject-details__section" aria-labelledby="subject-schedule-title">
          <div className="admin-subject-details__section-heading">
            <h2 id="subject-schedule-title">Class Schedule</h2>
            <Link to="/teacher/schedule">Open Schedule</Link>
          </div>
          <div className="admin-subject-details__records">
            {schedules.length > 0 ? schedules.map((record) => (
              <article className="admin-subject-details__record" key={record.id}>
                <div>
                  <h3>{classById[record.classId]?.name ?? subject.name}</h3>
                  <span>{record.date} · {formatTime(record.startTime)}–{formatTime(record.endTime)}</span>
                </div>
                <span className={`admin-subject-details__schedule-status admin-subject-details__schedule-status--${record.status.toLowerCase()}`}>
                  {record.status}
                </span>
              </article>
            )) : <p className="admin-subject-details__empty">No schedule records available.</p>}
          </div>
        </section>

        <section className="admin-subject-details__section" aria-labelledby="subject-assignments-title">
          <div className="admin-subject-details__section-heading">
            <h2 id="subject-assignments-title">Recent Assignments</h2>
          </div>
          <div className="admin-subject-details__records">
            {assignments.length > 0 ? assignments.map((assignment) => (
              <article className="admin-subject-details__record" key={assignment.id}>
                <div>
                  <h3>{assignment.name}</h3>
                  <span>{assignment.type} · Due {assignment.dueDate}</span>
                </div>
                <span>{assignment.status}</span>
              </article>
            )) : <p className="admin-subject-details__empty">No assignment records available.</p>}
          </div>
        </section>
      </div>

      {quizActivity.length > 0 && (
        <section className="admin-subject-details__section" aria-labelledby="subject-quiz-activity-title">
          <div className="admin-subject-details__section-heading">
            <h2 id="subject-quiz-activity-title">Recent Quiz Activity</h2>
          </div>
          <div className="admin-subject-details__records">
            {quizActivity.map((activity) => (
              <article className="admin-subject-details__activity-row" key={activity.id}>
                <p>{activity.description}</p>
                <time>{activity.timeAgo}</time>
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  )
}

export default AdminSubjectDetails
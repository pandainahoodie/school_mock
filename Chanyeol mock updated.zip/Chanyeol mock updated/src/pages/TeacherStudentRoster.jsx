import { useMemo, useState } from "react"
import { useNavigate, useParams } from "react-router-dom"
import { teacherClassDetails, teacherDashboardData } from "../../Data/mockData"
import "./TeacherStudentRoster.css"

const gradePoints = {
  A: 4,
  "A-": 3.7,
  "B+": 3.3,
  B: 3,
  "B-": 2.7,
  "C+": 2.3,
  C: 2,
  "C-": 1.7,
  D: 1,
  F: 0,
}

function TeacherStudentRoster() {
  const { classId } = useParams()
  const navigate = useNavigate()
  const [search, setSearch] = useState("")
  const classItem = teacherDashboardData.classes.find((item) => item.id === classId)
  const students = teacherClassDetails[classId]?.students

  const filteredStudents = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase()
    if (!normalizedSearch) {
      return students ?? []
    }

    return (students ?? []).filter((student) =>
      student.name.toLowerCase().includes(normalizedSearch) ||
      student.id.toLowerCase().includes(normalizedSearch),
    )
  }, [search, students])

  if (!classItem || !students) {
    return (
      <div className="teacher-roster">
        <section className="teacher-roster__not-found">
          <h1>Class not found</h1>
          <button type="button" onClick={() => navigate("/teacher/classes")}>
            Back to My Classes
          </button>
        </section>
      </div>
    )
  }

  const averageAttendance = students.length > 0
    ? students.reduce((total, student) => total + student.attendance, 0) / students.length
    : 0
  const averageGrade = students.length > 0
    ? students.reduce((total, student) => total + (gradePoints[student.grade] ?? 0), 0) / students.length
    : 0

  return (
    <div className="teacher-roster">
      <header className="teacher-roster__header">
        <div>
          <p className="teacher-roster__eyebrow">{classItem.subject} · Student Roster</p>
          <h1>{classItem.name}</h1>
        </div>
        <button
          className="teacher-roster__back-button"
          type="button"
          onClick={() => navigate(`/teacher/classes/${classItem.id}`)}
        >
          Back to Class Details
        </button>
      </header>

      <section className="teacher-roster__summary" aria-label="Roster summary">
        <article className="teacher-roster__summary-card">
          <span>Total Students</span>
          <strong>{students.length}</strong>
        </article>
        <article className="teacher-roster__summary-card">
          <span>Average Attendance</span>
          <strong>{averageAttendance.toFixed(1).replace(/\.0$/, "")}%</strong>
        </article>
        <article className="teacher-roster__summary-card">
          <span>Average Grade</span>
          <strong>{averageGrade.toFixed(1)} GPA</strong>
        </article>
      </section>

      <section className="teacher-roster__section" aria-labelledby="roster-title">
        <div className="teacher-roster__section-heading">
          <h2 id="roster-title">Students</h2>
          <label className="teacher-roster__search">
            <span className="teacher-roster__visually-hidden">Search students by name or ID</span>
            <input
              type="search"
              placeholder="Search students..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </label>
        </div>

        <div className="teacher-roster__table-wrap">
          <table className="teacher-roster__table">
            <thead>
              <tr>
                <th scope="col">Student</th>
                <th scope="col">Student ID</th>
                <th scope="col">Attendance</th>
                <th scope="col">Current Grade</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.length > 0 ? (
                filteredStudents.map((student) => (
                  <tr key={student.id}>
                    <th scope="row" data-label="Student">{student.name}</th>
                    <td data-label="Student ID">{student.id}</td>
                    <td data-label="Attendance">{student.attendance}%</td>
                    <td data-label="Current Grade">{student.grade}</td>
                    <td data-label="Status">
                      <span className="teacher-roster__status">Active</span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className="teacher-roster__empty" colSpan="5">
                    No students match your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

export default TeacherStudentRoster

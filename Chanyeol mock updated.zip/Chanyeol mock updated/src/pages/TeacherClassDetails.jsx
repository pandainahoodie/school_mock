import { useNavigate, useParams } from "react-router-dom"
import { teacherClassDetails, teacherDashboardData } from "../../Data/mockData"
import "./TeacherClassDetails.css"

function TeacherClassDetails() {
  const { classId } = useParams()
  const navigate = useNavigate()
  const classItem = teacherDashboardData.classes.find((item) => item.id === classId)
  const details = teacherClassDetails[classId]

  if (!classItem || !details) {
    return (
      <div className="teacher-class-details">
        <section className="teacher-class-details__not-found">
          <h1>Class not found</h1>
          <button type="button" onClick={() => navigate("/teacher/classes")}>
            Back to My Classes
          </button>
        </section>
      </div>
    )
  }

  return (
    <div className="teacher-class-details">
      <button
        className="teacher-class-details__back-button"
        type="button"
        onClick={() => navigate("/teacher/classes")}
      >
        Back to My Classes
      </button>

      <header className="teacher-class-details__heading">
        <p className="teacher-class-details__eyebrow">CLASS OVERVIEW</p>
        <h1>{classItem.name}</h1>
        <p>{classItem.subject} · Class overview and recent learning activity.</p>
      </header>

      <section className="teacher-class-details__overview" aria-label="Class information">
        <article>
          <span>Teacher</span>
          <strong>{teacherDashboardData.teacherName}</strong>
        </article>
        <article>
          <span>Subject</span>
          <strong>{classItem.subject}</strong>
        </article>
        <article>
          <span>Students</span>
          <strong>{classItem.students}</strong>
        </article>
        <article>
          <span>Schedule</span>
          <strong>{classItem.schedule}</strong>
        </article>
        <article>
          <span>Room</span>
          <strong>{classItem.room}</strong>
        </article>
      </section>

      <section className="teacher-class-details__section" aria-labelledby="class-students-title">
        <div className="teacher-class-details__section-heading">
          <h2 id="class-students-title">Students</h2>
          <button
            className="teacher-class-details__back-button"
            type="button"
            onClick={() => navigate(`/teacher/classes/${classItem.id}/students`)}
          >
            View All Students
          </button>
        </div>
        <div className="teacher-class-details__student-grid">
          {details.students.map((student) => (
            <article className="teacher-class-details__student-card" key={student.id}>
              <div className="teacher-class-details__student-name">
                <h3>{student.name}</h3>
                <span>{student.id}</span>
              </div>
              <dl>
                <div><dt>Attendance</dt><dd>{student.attendance}%</dd></div>
                <div><dt>Current Grade</dt><dd>{student.grade}</dd></div>
              </dl>
            </article>
          ))}
        </div>
      </section>

      <div className="teacher-class-details__lower-grid">
        <section className="teacher-class-details__section" aria-labelledby="class-assignments-title">
          <div className="teacher-class-details__section-heading">
            <h2 id="class-assignments-title">Recent Assignments</h2>
          </div>
          <div className="teacher-class-details__list-card">
            {details.assignments.map((assignment) => (
              <article className="teacher-class-details__assignment-row" key={assignment.id}>
                <div>
                  <h3>{assignment.name}</h3>
                  <span>{assignment.type} · Due {assignment.dueDate}</span>
                </div>
                <div className="teacher-class-details__assignment-meta">
                  <span>{assignment.submissions} submissions</span>
                  <span className={`teacher-class-details__status teacher-class-details__status--${assignment.status.toLowerCase()}`}>
                    {assignment.status}
                  </span>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="teacher-class-details__section" aria-labelledby="class-quiz-activity-title">
          <div className="teacher-class-details__section-heading">
            <h2 id="class-quiz-activity-title">Recent Quiz Activity</h2>
          </div>
          <ol className="teacher-class-details__activity-list">
            {details.quizActivity.map((activity) => (
              <li key={activity.id}>
                <span className="teacher-class-details__activity-marker" aria-hidden="true" />
                <div>
                  <p>{activity.description}</p>
                  <time>{activity.timeAgo}</time>
                </div>
              </li>
            ))}
          </ol>
        </section>
      </div>
    </div>
  )
}

export default TeacherClassDetails

import { useState } from "react"
import { Link } from "react-router-dom"
import {
  studentSubjects,
  teacherDashboardData,
  teacherScheduleRecords,
} from "../../Data/mockData"
import MockActionModal from "../components/MockActionModal"
import "./AdminSchedules.css"

const INITIAL_SCHEDULE_DATE = "2026-09-29"
const classById = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
)
const subjectByName = Object.fromEntries(studentSubjects.map((subject) => [subject.name, subject]))
const scheduleEntries = teacherScheduleRecords.flatMap((record) => {
  const classItem = classById[record.classId]
  if (!classItem) {
    return []
  }

  return [{
    ...record,
    className: classItem.name,
    subject: classItem.subject,
    teacher: subjectByName[classItem.subject]?.teacher ?? teacherDashboardData.teacherName,
    room: classItem.room,
  }]
})
const classes = teacherDashboardData.classes
const subjects = [...new Set(scheduleEntries.map((entry) => entry.subject))]
const teachers = [...new Set(scheduleEntries.map((entry) => entry.teacher))]
const rooms = [...new Set(scheduleEntries.map((entry) => entry.room))]
const statuses = [...new Set(scheduleEntries.map((entry) => entry.status))]

function shiftDate(date, offset) {
  const [year, month, day] = date.split("-").map(Number)

  return new Date(Date.UTC(year, month - 1, day + offset)).toISOString().slice(0, 10)
}

function formatDate(date) {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${date}T00:00:00Z`))
}

function formatTime(time) {
  const [hours, minutes] = time.split(":").map(Number)

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "UTC",
  }).format(new Date(Date.UTC(2026, 0, 1, hours, minutes)))
}

function AdminSchedules() {
  const [selectedDate, setSelectedDate] = useState(INITIAL_SCHEDULE_DATE)
  const [classFilter, setClassFilter] = useState("All classes")
  const [teacherFilter, setTeacherFilter] = useState("All teachers")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [roomFilter, setRoomFilter] = useState("All rooms")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const [activeModal, setActiveModal] = useState(false)
  const filteredEntries = scheduleEntries
    .filter((entry) => entry.date === selectedDate)
    .filter((entry) => (
      (classFilter === "All classes" || entry.classId === classFilter) &&
      (teacherFilter === "All teachers" || entry.teacher === teacherFilter) &&
      (subjectFilter === "All subjects" || entry.subject === subjectFilter) &&
      (roomFilter === "All rooms" || entry.room === roomFilter) &&
      (statusFilter === "All statuses" || entry.status === statusFilter)
    ))
    .sort((left, right) => left.startTime.localeCompare(right.startTime))
  const summary = [
    { label: "Total Schedule Entries", value: scheduleEntries.length },
    { label: "Today's Classes", value: scheduleEntries.filter((entry) => entry.date === INITIAL_SCHEDULE_DATE).length },
    { label: "Upcoming Classes", value: scheduleEntries.filter((entry) => entry.status === "Upcoming").length },
    { label: "Rooms In Use", value: new Set(scheduleEntries.map((entry) => entry.room)).size },
  ]

  const modalFields = [
    { name: "className", label: "Class", type: "select", options: classes.map((classItem) => classItem.name), value: classes[0]?.name ?? "" },
    { name: "date", label: "Date", type: "date", required: true },
    { name: "startTime", label: "Start time", type: "time", required: true },
    { name: "endTime", label: "End time", type: "time", required: true },
    { name: "room", label: "Room", type: "text", placeholder: "e.g. Room 105", required: true },
    { name: "status", label: "Status", type: "select", options: ["Upcoming", "Ongoing", "Completed"], value: "Upcoming" },
  ]

  return (
    <div className="admin-schedules">
      <header className="admin-schedules__heading">
        <div>
          <h1>Schedules</h1>
          <p>View the school's scheduled classes and room assignments.</p>
        </div>
        <button className="admin-schedules__add-button" type="button" onClick={() => setActiveModal(true)}>
          Add Schedule
        </button>
      </header>

      <section className="admin-schedules__summary" aria-label="Schedule summary">
        {summary.map(({ label, value }) => (
          <article className="admin-schedules__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-schedules__section" aria-labelledby="admin-schedule-day">
        <div className="admin-schedules__toolbar">
          <div className="admin-schedules__date-heading">
            <h2 id="admin-schedule-day">{formatDate(selectedDate)}</h2>
            <button type="button" onClick={() => setSelectedDate(INITIAL_SCHEDULE_DATE)}>
              Today
            </button>
          </div>
          <div className="admin-schedules__day-navigation" aria-label="Choose schedule day">
            <button type="button" aria-label="Previous Day" onClick={() => setSelectedDate((date) => shiftDate(date, -1))}>
              Previous Day
            </button>
            <button type="button" aria-label="Next Day" onClick={() => setSelectedDate((date) => shiftDate(date, 1))}>
              Next Day
            </button>
          </div>
        </div>

        <div className="admin-schedules__filters">
          <label>
            <span className="admin-schedules__visually-hidden">Filter schedules by class</span>
            <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
              <option value="All classes">All classes</option>
              {classes.map((classItem) => <option key={classItem.id} value={classItem.id}>{classItem.name}</option>)}
            </select>
          </label>
          <label>
            <span className="admin-schedules__visually-hidden">Filter schedules by teacher</span>
            <select value={teacherFilter} onChange={(event) => setTeacherFilter(event.target.value)}>
              <option value="All teachers">All teachers</option>
              {teachers.map((teacher) => <option key={teacher} value={teacher}>{teacher}</option>)}
            </select>
          </label>
          <label>
            <span className="admin-schedules__visually-hidden">Filter schedules by subject</span>
            <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
              <option value="All subjects">All subjects</option>
              {subjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
            </select>
          </label>
          <label>
            <span className="admin-schedules__visually-hidden">Filter schedules by room</span>
            <select value={roomFilter} onChange={(event) => setRoomFilter(event.target.value)}>
              <option value="All rooms">All rooms</option>
              {rooms.map((room) => <option key={room} value={room}>{room}</option>)}
            </select>
          </label>
          <label>
            <span className="admin-schedules__visually-hidden">Filter schedules by status</span>
            <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
              <option value="All statuses">All statuses</option>
              {statuses.map((status) => <option key={status} value={status}>{status}</option>)}
            </select>
          </label>
        </div>

        <div className="admin-schedules__table-wrap">
          <table className="admin-schedules__table">
            <thead>
              <tr>
                <th scope="col">Time</th>
                <th scope="col">Class</th>
                <th scope="col">Subject</th>
                <th scope="col">Teacher</th>
                <th scope="col">Room</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredEntries.length > 0 ? filteredEntries.map((entry) => (
                <tr key={entry.id}>
                  <td data-label="Time">{formatTime(entry.startTime)}–{formatTime(entry.endTime)}</td>
                  <th scope="row" data-label="Class">{entry.className}</th>
                  <td data-label="Subject">{entry.subject}</td>
                  <td data-label="Teacher">{entry.teacher}</td>
                  <td data-label="Room">{entry.room}</td>
                  <td data-label="Status">
                    <span className={`admin-schedules__status admin-schedules__status--${entry.status.toLowerCase()}`}>
                      {entry.status}
                    </span>
                  </td>
                  <td data-label="Action">
                    <Link className="admin-schedules__view-link" to={`/admin/schedules/${entry.id}`}>
                      View Schedule
                    </Link>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="admin-schedules__empty" colSpan="7">No schedules found for this day.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <MockActionModal
        isOpen={activeModal}
        title="Add Schedule"
        description="Plan a new school timetable entry in the mock academic calendar."
        submitLabel="Save Schedule"
        fields={modalFields}
        onClose={() => setActiveModal(false)}
        onSubmit={() => setActiveModal(false)}
      />
    </div>
  )
}

export default AdminSchedules
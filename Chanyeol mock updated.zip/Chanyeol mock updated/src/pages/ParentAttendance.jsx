import { Link } from "react-router-dom"
import { studentAttendanceRecords, studentSubjects, teacherDashboardData } from "../../Data/mockData"
import "./ParentAttendance.css"

const classBySubject = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.subject, classItem]),
)
const attendanceRecords = studentAttendanceRecords
  .map((record) => ({
    ...record,
    classItem: classBySubject[record.subject],
  }))
  .sort((left, right) => right.date.localeCompare(left.date) || right.id.localeCompare(left.id))

function formatDate(date) {
  const [year, month, day] = date.split("-").map(Number)

  return new Date(Date.UTC(year, month - 1, day, 12)).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  })
}

function ParentAttendance() {
  const total = attendanceRecords.length
  const present = attendanceRecords.filter((record) => record.status === "Present").length
  const late = attendanceRecords.filter((record) => record.status === "Late").length
  const absent = attendanceRecords.filter((record) => record.status === "Absent").length
  const rate = total > 0 ? ((present + late) / total) * 100 : 0
  const subjectSummaries = studentSubjects.map((subject) => {
    const records = attendanceRecords.filter((record) => record.subjectId === subject.id)
    const attended = records.filter((record) => record.status === "Present" || record.status === "Late").length

    return {
      ...subject,
      total: records.length,
      present: records.filter((record) => record.status === "Present").length,
      late: records.filter((record) => record.status === "Late").length,
      absent: records.filter((record) => record.status === "Absent").length,
      rate: records.length > 0 ? (attended / records.length) * 100 : 0,
      classItem: classBySubject[subject.name],
    }
  }).filter((summary) => summary.total > 0)
  const summaryCards = [
    { label: "Attendance Rate", value: `${rate.toFixed(1)}%` },
    { label: "Present", value: present },
    { label: "Late", value: late },
    { label: "Absent", value: absent },
  ]

  return (
    <div className="parent-academic parent-attendance">
      <header className="parent-academic__heading">
        <div>
          <h1>Attendance</h1>
          <p>Review Chanyeol's attendance history and consistency.</p>
        </div>
        <Link className="parent-academic__back-link" to="/parent">Parent Dashboard</Link>
      </header>

      <section className="parent-academic__summary" aria-label="Attendance summary">
        {summaryCards.map(({ label, value }) => (
          <article className="parent-academic__summary-card" key={label}>
            <span>{label}</span><strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="parent-academic__section" aria-labelledby="parent-attendance-records-title">
        <div className="parent-academic__section-heading">
          <h2 id="parent-attendance-records-title">Recent Attendance</h2>
          <span>{total} records</span>
        </div>
        <div className="parent-academic__table-wrap">
          <table className="parent-academic__table">
            <thead><tr><th>Date</th><th>Subject</th><th>Class</th><th>Status</th><th>Remarks</th></tr></thead>
            <tbody>
              {attendanceRecords.map((record) => (
                <tr key={record.id}>
                  <td data-label="Date"><time>{formatDate(record.date)}</time></td>
                  <td data-label="Subject">{record.subject}</td>
                  <td data-label="Class">
                    {record.classItem ? <Link to={`/teacher/classes/${record.classItem.id}`}>{record.classItem.name}</Link> : "No class assigned"}
                  </td>
                  <td data-label="Status">
                    <span className={`parent-academic__status parent-academic__status--${record.status.toLowerCase()}`}>{record.status}</span>
                  </td>
                  <td data-label="Remarks">{record.remarks || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="parent-academic__section" aria-labelledby="parent-attendance-subject-title">
        <div className="parent-academic__section-heading">
          <h2 id="parent-attendance-subject-title">By Subject</h2>
        </div>
        <div className="parent-academic__card-grid">
          {subjectSummaries.map((subject) => (
            <article className="parent-academic__card parent-attendance__subject-card" key={subject.id}>
              <div className="parent-academic__card-heading">
                <div>
                  <h3>{subject.name}</h3>
                  <span>{subject.classItem?.name ?? "No class assigned"}</span>
                </div>
                <strong>{subject.rate.toFixed(1)}%</strong>
              </div>
              <div className="parent-academic__counts">
                <span>Present <strong>{subject.present}</strong></span>
                <span>Late <strong>{subject.late}</strong></span>
                <span>Absent <strong>{subject.absent}</strong></span>
                <span>Total <strong>{subject.total}</strong></span>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}

export default ParentAttendance
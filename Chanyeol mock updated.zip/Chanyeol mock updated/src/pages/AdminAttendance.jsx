import { useState } from "react"
import { Link } from "react-router-dom"
import {
  studentAttendanceRecords,
  studentSubjects,
  teacherClassDetails,
  teacherDashboardData,
} from "../../Data/mockData"
import "./AdminAttendance.css"

const rosterStudents = Object.values(teacherClassDetails)
  .flatMap((classDetails) => classDetails.students)
const student = rosterStudents.find((record) => record.name === "Chanyeol Park")
const classBySubject = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.subject, classItem]),
)
const subjectById = Object.fromEntries(studentSubjects.map((subject) => [subject.id, subject]))
const attendanceEntries = [...new Map(studentAttendanceRecords.map((record) => {
  const subject = subjectById[record.subjectId]
  const classItem = classBySubject[subject?.name ?? record.subject]
  const attendanceEntry = {
    ...record,
    studentId: student?.id ?? "",
    studentName: student?.name ?? "Student",
    subject: subject?.name ?? record.subject,
    classId: classItem?.id ?? "",
    className: classItem?.name ?? "No class assigned",
  }

  return [record.id, attendanceEntry]
})).values()]

function formatDate(date) {
  const [year, month, day] = date.split("-").map(Number)

  return new Date(Date.UTC(year, month - 1, day, 12)).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  })
}

function AdminAttendance() {
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("All classes")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [dateFilter, setDateFilter] = useState("")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const normalizedSearch = search.trim().toLowerCase()
  const filteredRecords = attendanceEntries
    .filter((record) => {
      const matchesSearch = [record.studentName, record.studentId]
        .some((value) => value.toLowerCase().includes(normalizedSearch))
      const matchesClass = classFilter === "All classes" || record.classId === classFilter
      const matchesSubject = subjectFilter === "All subjects" || record.subject === subjectFilter
      const matchesDate = !dateFilter || record.date === dateFilter
      const matchesStatus = statusFilter === "All statuses" || record.status === statusFilter

      return matchesSearch && matchesClass && matchesSubject && matchesDate && matchesStatus
    })
    .sort((left, right) => right.date.localeCompare(left.date) || right.id.localeCompare(left.id))
  const presentCount = filteredRecords.filter((record) => record.status === "Present").length
  const lateCount = filteredRecords.filter((record) => record.status === "Late").length
  const absentCount = filteredRecords.filter((record) => record.status === "Absent").length
  const attendanceRate = filteredRecords.length > 0
    ? ((presentCount + lateCount) / filteredRecords.length) * 100
    : 0
  const summary = [
    { label: "Total Records", value: filteredRecords.length },
    { label: "Present", value: presentCount },
    { label: "Late", value: lateCount },
    { label: "Absent", value: absentCount },
    { label: "Attendance Rate", value: `${attendanceRate.toFixed(1)}%` },
  ]
  const classSummaries = [...filteredRecords.reduce((groups, record) => {
    const groupId = record.classId || `unassigned-${record.subjectId}`
    const groupName = record.classId ? record.className : `${record.subject} · No class assigned`
    const group = groups.get(groupId) ?? {
      id: groupId,
      name: groupName,
      classId: record.classId,
      total: 0,
      present: 0,
      late: 0,
      absent: 0,
    }

    group.total += 1
    group[record.status.toLowerCase()] += 1
    groups.set(groupId, group)

    return groups
  }, new Map()).values()].map((group) => ({
    ...group,
    attendanceRate: group.total > 0 ? ((group.present + group.late) / group.total) * 100 : 0,
  }))
  const subjects = [...new Set(studentSubjects.map((subject) => subject.name))]

  return (
    <div className="admin-attendance">
      <header className="admin-attendance__heading">
        <h1>Attendance</h1>
        <p>Monitor student attendance across the school.</p>
      </header>

      <section className="admin-attendance__summary" aria-label="Attendance summary">
        {summary.map(({ label, value }) => (
          <article className="admin-attendance__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-attendance__section" aria-labelledby="admin-attendance-records-title">
        <div className="admin-attendance__toolbar">
          <div>
            <h2 id="admin-attendance-records-title">Student Attendance</h2>
            <p>Showing {filteredRecords.length} of {attendanceEntries.length} records</p>
          </div>
          <div className="admin-attendance__filters">
            <label>
              <span className="admin-attendance__visually-hidden">Search by student name or ID</span>
              <input
                type="search"
                placeholder="Search student or ID..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="admin-attendance__visually-hidden">Filter attendance by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {teacherDashboardData.classes.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span className="admin-attendance__visually-hidden">Filter attendance by subject</span>
              <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
                <option value="All subjects">All subjects</option>
                {subjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
              </select>
            </label>
            <label>
              <span className="admin-attendance__visually-hidden">Filter attendance by date</span>
              <input type="date" value={dateFilter} onChange={(event) => setDateFilter(event.target.value)} />
            </label>
            <label>
              <span className="admin-attendance__visually-hidden">Filter attendance by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Present">Present</option>
                <option value="Late">Late</option>
                <option value="Absent">Absent</option>
              </select>
            </label>
          </div>
        </div>

        <div className="admin-attendance__table-wrap">
          <table className="admin-attendance__table">
            <thead>
              <tr>
                <th scope="col">Student</th>
                <th scope="col">Student ID</th>
                <th scope="col">Class</th>
                <th scope="col">Subject</th>
                <th scope="col">Date</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredRecords.length > 0 ? filteredRecords.map((record) => (
                <tr key={record.id}>
                  <th scope="row" data-label="Student">
                    <Link to={`/admin/students/${record.studentId}`}>{record.studentName}</Link>
                  </th>
                  <td data-label="Student ID">{record.studentId}</td>
                  <td data-label="Class">{record.className}</td>
                  <td data-label="Subject">{record.subject}</td>
                  <td data-label="Date"><time dateTime={record.date}>{formatDate(record.date)}</time></td>
                  <td data-label="Status">
                    <span className={`admin-attendance__status admin-attendance__status--${record.status.toLowerCase()}`}>
                      {record.status}
                    </span>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="admin-attendance__empty" colSpan="6">No attendance records match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="admin-attendance__section" aria-labelledby="admin-class-attendance-title">
        <div className="admin-attendance__section-heading">
          <h2 id="admin-class-attendance-title">Attendance by Class</h2>
        </div>
        <div className="admin-attendance__class-grid">
          {classSummaries.map((classSummary) => (
            <article className="admin-attendance__class-card" key={classSummary.id}>
              <div className="admin-attendance__class-heading">
                {classSummary.classId ? (
                  <Link to={`/admin/classes/${classSummary.classId}`}>{classSummary.name}</Link>
                ) : <h3>{classSummary.name}</h3>}
                <strong>{classSummary.attendanceRate.toFixed(1)}%</strong>
              </div>
              <div className="admin-attendance__class-counts">
                <span>Total <strong>{classSummary.total}</strong></span>
                <span>Present <strong>{classSummary.present}</strong></span>
                <span>Late <strong>{classSummary.late}</strong></span>
                <span>Absent <strong>{classSummary.absent}</strong></span>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}

export default AdminAttendance
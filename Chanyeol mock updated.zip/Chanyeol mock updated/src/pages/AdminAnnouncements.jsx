import { useState } from "react"
import { Link } from "react-router-dom"
import {
  adminTeacherRecords,
  teacherDashboardData,
} from "../../Data/mockData"
import MockActionModal from "../components/MockActionModal"
import "./AdminAnnouncements.css"

const classByName = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.name, classItem]),
)
const author = teacherDashboardData.teacherName
const authorRecord = adminTeacherRecords.find((teacher) => teacher.name === author)
const announcements = teacherDashboardData.recentAnnouncements
  .map((announcement) => ({
    ...announcement,
    author,
    authorId: authorRecord?.teacherId,
    classId: classByName[announcement.targetClass]?.id ?? "",
  }))
  .sort((left, right) => Date.parse(right.date) - Date.parse(left.date))

function AdminAnnouncements() {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const [authorFilter, setAuthorFilter] = useState("All authors")
  const [classFilter, setClassFilter] = useState("All classes")
  const [activeModal, setActiveModal] = useState(false)
  const normalizedSearch = search.trim().toLowerCase()
  const filteredAnnouncements = announcements.filter((announcement) => {
    const matchesSearch = [announcement.title, announcement.content, announcement.author]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesStatus = statusFilter === "All statuses" || announcement.status === statusFilter
    const matchesAuthor = authorFilter === "All authors" || announcement.author === authorFilter
    const matchesClass = classFilter === "All classes" || announcement.classId === classFilter

    return matchesSearch && matchesStatus && matchesAuthor && matchesClass
  })
  const summary = [
    { label: "Total Announcements", value: announcements.length },
    { label: "Published", value: announcements.filter((item) => item.status === "Published").length },
    { label: "Draft", value: announcements.filter((item) => item.status === "Draft").length },
    { label: "Active Announcements", value: announcements.filter((item) => item.status === "Published").length },
  ]
  const authors = [...new Set(announcements.map((announcement) => announcement.author))]

  const modalFields = [
    { name: "announcementTitle", label: "Title", type: "text", placeholder: "e.g. Parent orientation", required: true },
    { name: "targetClass", label: "Audience", type: "select", options: ["All classes", ...teacherDashboardData.classes.map((classItem) => classItem.name)], value: "All classes" },
    { name: "author", label: "Author", type: "select", options: authors, value: authors[0] ?? author },
    { name: "status", label: "Status", type: "select", options: ["Draft", "Published"], value: "Draft" },
    { name: "content", label: "Message", type: "textarea", placeholder: "Write the announcement here.", required: true },
  ]

  return (
    <div className="admin-announcements">
      <header className="admin-announcements__heading">
        <div>
          <h1>Announcements</h1>
          <p>Monitor school announcements and their publishing status.</p>
        </div>
        <button className="admin-announcements__add-button" type="button" onClick={() => setActiveModal(true)}>
          Add Announcement
        </button>
      </header>

      <section className="admin-announcements__summary" aria-label="Announcement summary">
        {summary.map(({ label, value }) => (
          <article className="admin-announcements__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-announcements__section" aria-labelledby="admin-announcement-list-title">
        <div className="admin-announcements__toolbar">
          <div>
            <h2 id="admin-announcement-list-title">School Announcements</h2>
            <p>Showing {filteredAnnouncements.length} of {announcements.length}</p>
          </div>
          <div className="admin-announcements__filters">
            <label>
              <span className="admin-announcements__visually-hidden">Search announcements by title, content, or author</span>
              <input
                type="search"
                placeholder="Search announcements..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="admin-announcements__visually-hidden">Filter announcements by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Published">Published</option>
                <option value="Draft">Draft</option>
              </select>
            </label>
            <label>
              <span className="admin-announcements__visually-hidden">Filter announcements by author</span>
              <select value={authorFilter} onChange={(event) => setAuthorFilter(event.target.value)}>
                <option value="All authors">All authors</option>
                {authors.map((name) => <option key={name} value={name}>{name}</option>)}
              </select>
            </label>
            <label>
              <span className="admin-announcements__visually-hidden">Filter announcements by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {teacherDashboardData.classes.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
          </div>
        </div>

        <div className="admin-announcements__list" aria-live="polite">
          {filteredAnnouncements.length > 0 ? filteredAnnouncements.map((announcement) => (
            <article className="admin-announcements__card" key={announcement.id}>
              <div className="admin-announcements__card-heading">
                <div>
                  <h3>
                    <Link to={`/admin/announcements/${announcement.id}`}>{announcement.title}</Link>
                  </h3>
                  <span className="admin-announcements__audience">
                    {announcement.classId ? (
                      <Link to={`/admin/classes/${announcement.classId}`}>{announcement.targetClass}</Link>
                    ) : announcement.targetClass}
                  </span>
                </div>
                <span className={`admin-announcements__status admin-announcements__status--${announcement.status.toLowerCase()}`}>
                  {announcement.status}
                </span>
              </div>
              <p className="admin-announcements__preview">{announcement.content}</p>
              <footer className="admin-announcements__meta">
                {announcement.authorId ? (
                  <Link to={`/admin/teachers/${announcement.authorId}`}>{announcement.author}</Link>
                ) : <span>{announcement.author}</span>}
                <time>{announcement.date}</time>
              </footer>
              <Link className="admin-announcements__details-link" to={`/admin/announcements/${announcement.id}`}>
                View Details
              </Link>
            </article>
          )) : (
            <p className="admin-announcements__empty">No announcements match your filters.</p>
          )}
        </div>
      </section>

      <MockActionModal
        isOpen={activeModal}
        title="Add Announcement"
        description="Draft a new school-wide or class-specific announcement."
        submitLabel="Publish Announcement"
        fields={modalFields}
        onClose={() => setActiveModal(false)}
        onSubmit={() => setActiveModal(false)}
      />
    </div>
  )
}

export default AdminAnnouncements
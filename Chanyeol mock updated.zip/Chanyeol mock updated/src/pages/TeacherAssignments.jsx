import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { teacherAssignmentDetails, teacherDashboardData } from "../../Data/mockData"
import "./TeacherAssignments.css"

const statusFilters = ["All statuses", "Active", "Grading", "Completed"]

function TeacherAssignments() {
  const navigate = useNavigate()
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const classByName = Object.fromEntries(
    teacherDashboardData.classes.map((classItem) => [classItem.name, classItem]),
  )
  const assignments = teacherDashboardData.pendingGrading.map((assignment) => {
    const classItem = classByName[assignment.className]

    return {
      ...assignment,
      subject: classItem?.subject ?? "",
      totalStudents: classItem?.students ?? 0,
      status: teacherAssignmentDetails[assignment.id]?.status ?? "Active",
    }
  })
  const normalizedSearch = search.trim().toLowerCase()
  const filteredAssignments = assignments.filter((assignment) => {
    const matchesSearch = [assignment.title, assignment.subject, assignment.className]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesStatus = statusFilter === "All statuses" || assignment.status === statusFilter

    return matchesSearch && matchesStatus
  })
  const summaryItems = [
    { label: "Total Assignments", value: assignments.length },
    { label: "Active", value: assignments.filter((assignment) => assignment.status === "Active").length },
    { label: "Awaiting Grading", value: assignments.filter((assignment) => assignment.status === "Grading").length },
    { label: "Completed", value: assignments.filter((assignment) => assignment.status === "Completed").length },
  ]

  return (
    <div className="teacher-assignments">
      <div className="teacher-assignments__heading">
        <h1>Assignments</h1>
        <p>Manage and review assignments across your classes.</p>
      </div>

      <section className="teacher-assignments__summary" aria-label="Assignment summary">
        {summaryItems.map(({ label, value }) => (
          <article className="teacher-assignments__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="teacher-assignments__section" aria-labelledby="teacher-assignment-list-title">
        <div className="teacher-assignments__toolbar">
          <h2 id="teacher-assignment-list-title">All Assignments</h2>
          <div className="teacher-assignments__filters">
            <label>
              <span className="teacher-assignments__visually-hidden">Search assignments</span>
              <input
                type="search"
                placeholder="Search title, subject, or class..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="teacher-assignments__visually-hidden">Filter by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                {statusFilters.map((status) => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
            </label>
          </div>
        </div>

        <div className="teacher-assignments__table-wrap">
          <table className="teacher-assignments__table">
            <thead>
              <tr>
                <th scope="col">Assignment</th>
                <th scope="col">Subject</th>
                <th scope="col">Class</th>
                <th scope="col">Due Date</th>
                <th scope="col">Submissions</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredAssignments.length > 0 ? filteredAssignments.map((assignment) => (
                <tr key={assignment.id}>
                  <th scope="row" data-label="Assignment">
                    <span>{assignment.title}</span>
                    <button
                      className="teacher-assignments__view-button"
                      type="button"
                      onClick={() => navigate(`/teacher/assignments/${assignment.id}`)}
                    >
                      View Assignment
                    </button>
                  </th>
                  <td data-label="Subject">{assignment.subject}</td>
                  <td data-label="Class">{assignment.className}</td>
                  <td data-label="Due Date">{assignment.dueDate}</td>
                  <td data-label="Submissions">{assignment.submissions} / {assignment.totalStudents}</td>
                  <td data-label="Status">
                    <span className={`teacher-assignments__status teacher-assignments__status--${assignment.status.toLowerCase()}`}>
                      {assignment.status}
                    </span>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="teacher-assignments__empty" colSpan="6">No assignments match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

export default TeacherAssignments

import { useCallback, useEffect, useRef, useState } from "react"
import { useNavigate, useParams, useSearchParams } from "react-router-dom"
import { studentQuizzes } from "../../Data/mockData"
import "./QuizAttempt.css"

function formatRemainingTime(timeInSeconds) {
  const minutes = Math.floor(timeInSeconds / 60)
  const seconds = timeInSeconds % 60

  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`
}

function shuffleItems(items) {
  const shuffledItems = [...items]

  for (let index = shuffledItems.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1))
    ;[shuffledItems[index], shuffledItems[randomIndex]] = [
      shuffledItems[randomIndex],
      shuffledItems[index],
    ]
  }

  return shuffledItems
}

function createRandomizedQuestions(questions) {
  return shuffleItems(questions).map((question) => ({
    ...question,
    choices: shuffleItems(question.choices),
  }))
}

function getAttemptStorageKey(quizId) {
  return `quizAttempt_${quizId}`
}

function createAttemptId(quizId) {
  return `${quizId}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}

function removeSavedAttempt(quizId) {
  try {
    localStorage.removeItem(getAttemptStorageKey(quizId))
  } catch {
    // Storage can be unavailable in restricted browser contexts.
  }
}

function readSavedAttempt(quiz) {
  let savedAttempt

  try {
    const savedValue = localStorage.getItem(getAttemptStorageKey(quiz.id))
    if (!savedValue) {
      return null
    }
    savedAttempt = JSON.parse(savedValue)
  } catch {
    removeSavedAttempt(quiz.id)
    return null
  }

  const originalQuestions = new Map(quiz.questions.map((question) => [question.id, question]))
  const savedQuestionIds = new Set(
    Array.isArray(savedAttempt?.questions)
      ? savedAttempt.questions.map((question) => question.id)
      : [],
  )
  const questionsAreValid =
    Array.isArray(savedAttempt?.questions) &&
    savedAttempt.questions.length === quiz.questions.length &&
    savedQuestionIds.size === quiz.questions.length &&
    savedAttempt.questions.every((question) => {
      const originalQuestion = originalQuestions.get(question.id)
      return (
        originalQuestion &&
        question.question === originalQuestion.question &&
        question.correctAnswer === originalQuestion.correctAnswer &&
        Array.isArray(question.choices) &&
        question.choices.length === originalQuestion.choices.length &&
        originalQuestion.choices.every((choice) => question.choices.includes(choice))
      )
    })
  const answersAreValid =
    savedAttempt?.selectedAnswers &&
    typeof savedAttempt.selectedAnswers === "object" &&
    !Array.isArray(savedAttempt.selectedAnswers) &&
    Object.entries(savedAttempt.selectedAnswers).every(([questionId, answer]) =>
      originalQuestions.get(questionId)?.choices.includes(answer),
    )
  const attemptIsValid =
    savedAttempt?.quizId === quiz.id &&
    savedAttempt.submitted !== true &&
    !savedAttempt.result &&
    savedAttempt.status !== "submitted" &&
    questionsAreValid &&
    answersAreValid &&
    Number.isInteger(savedAttempt.currentQuestionIndex) &&
    savedAttempt.currentQuestionIndex >= 0 &&
    savedAttempt.currentQuestionIndex < quiz.questions.length &&
    Number.isFinite(savedAttempt.remainingTime) &&
    savedAttempt.remainingTime >= 0 &&
    savedAttempt.remainingTime <= quiz.timeLimit * 60 &&
    Number.isFinite(savedAttempt.savedAt) &&
    (!savedAttempt.attemptId || typeof savedAttempt.attemptId === "string")

  if (!attemptIsValid) {
    removeSavedAttempt(quiz.id)
    return null
  }

  const elapsedSeconds = Math.floor(Math.max(Date.now() - savedAttempt.savedAt, 0) / 1000)

  return {
    ...savedAttempt,
    attemptId: savedAttempt.attemptId ?? createAttemptId(quiz.id),
    remainingTime: Math.max(savedAttempt.remainingTime - elapsedSeconds, 0),
  }
}

function calculateQuizResult(questions, selectedAnswers) {
  const questionReview = questions.map((question, index) => {
    const selectedAnswer = selectedAnswers[question.id] ?? null

    return {
      questionNumber: index + 1,
      questionId: question.id,
      question: question.question,
      choices: [...question.choices],
      selectedAnswer,
      correctAnswer: question.correctAnswer,
      isCorrect: selectedAnswer === question.correctAnswer,
    }
  })
  const correctAnswers = questionReview.filter((item) => item.isCorrect).length
  const totalQuestions = questions.length

  return {
    correctAnswers,
    incorrectAnswers: totalQuestions - correctAnswers,
    totalQuestions,
    percentage: totalQuestions === 0 ? 0 : Math.round((correctAnswers / totalQuestions) * 100),
    questionReview,
  }
}

function QuizAttempt({ completedAttempts, quizHistory, onComplete }) {
  const { quizId } = useParams()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const historyId = searchParams.get("history")
  const quiz = studentQuizzes.find((item) => item.id === quizId)
  const historyRecord = quizHistory[quizId]?.find((record) => record.id === historyId) ?? null
  const isViewingHistory = historyId !== null
  const attemptsUsed = quiz ? completedAttempts[quiz.id] ?? quiz.attemptsUsed : 0
  const canStart = !isViewingHistory && quiz?.status === "Available" && attemptsUsed < quiz.maxAttempts
  const [savedAttempt] = useState(() =>
    quiz && canStart ? readSavedAttempt(quiz) : null,
  )
  const [attemptQuestions] = useState(() =>
    savedAttempt?.questions ?? (canStart ? createRandomizedQuestions(quiz.questions) : []),
  )
  const [attemptId] = useState(() =>
    savedAttempt?.attemptId ?? (canStart ? createAttemptId(quiz.id) : null),
  )
  const initialRemainingTime = savedAttempt?.remainingTime ?? (canStart ? quiz.timeLimit * 60 : 0)
  const initialSelectedAnswers = savedAttempt?.selectedAnswers ?? {}
  const [remainingTime, setRemainingTime] = useState(initialRemainingTime)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(
    savedAttempt?.currentQuestionIndex ?? 0,
  )
  const [selectedAnswers, setSelectedAnswers] = useState(initialSelectedAnswers)
  const [result, setResult] = useState(() =>
    historyRecord ?? (
      savedAttempt?.remainingTime === 0
        ? calculateQuizResult(savedAttempt.questions, savedAttempt.selectedAnswers)
        : null
    ),
  )
  const remainingTimeRef = useRef(initialRemainingTime)
  const selectedAnswersRef = useRef(initialSelectedAnswers)
  const completionReportedRef = useRef(isViewingHistory)
  const isSubmitted = result !== null || remainingTime === 0

  const submitAttempt = useCallback(() => {
    if (!quiz || !canStart || completionReportedRef.current) {
      return
    }

    const attemptResult = calculateQuizResult(attemptQuestions, selectedAnswersRef.current)
    completionReportedRef.current = true
    removeSavedAttempt(quiz.id)
    const completedRecord = onComplete(quiz.id, attemptId, attemptResult)
    setResult(completedRecord ?? attemptResult)
  }, [attemptId, attemptQuestions, canStart, onComplete, quiz])

  useEffect(() => {
    if (!quiz || !canStart || isViewingHistory || result !== null || remainingTimeRef.current === 0) {
      return undefined
    }

    const intervalId = setInterval(() => {
      const nextTime = Math.max(remainingTimeRef.current - 1, 0)
      remainingTimeRef.current = nextTime
      setRemainingTime(nextTime)

      if (nextTime === 0) {
        submitAttempt()
      }
    }, 1000)

    return () => clearInterval(intervalId)
  }, [quiz, canStart, isViewingHistory, attemptQuestions, result, submitAttempt])

  useEffect(() => {
    if (!quiz || result === null || isViewingHistory) {
      return
    }

    removeSavedAttempt(quiz.id)
    if (!completionReportedRef.current) {
      completionReportedRef.current = true
      removeSavedAttempt(quiz.id)
      onComplete(quiz.id, attemptId, result)
    }
  }, [attemptId, isViewingHistory, onComplete, quiz, result])

  useEffect(() => {
    if (!quiz || isViewingHistory) {
      return
    }

    if (!canStart || result !== null || remainingTime === 0) {
      removeSavedAttempt(quiz.id)
      return
    }

    try {
      localStorage.setItem(
        getAttemptStorageKey(quiz.id),
        JSON.stringify({
          quizId: quiz.id,
          attemptId,
          selectedAnswers,
          currentQuestionIndex,
          questions: attemptQuestions,
          remainingTime,
          savedAt: Date.now(),
        }),
      )
    } catch {
      // Keep the attempt usable if browser storage is unavailable.
    }
  }, [
    attemptQuestions,
    attemptId,
    canStart,
    currentQuestionIndex,
    isViewingHistory,
    quiz,
    remainingTime,
    result,
    selectedAnswers,
  ])

  if (!quiz) {
    return (
      <div className="quiz-attempt">
        <button className="quiz-attempt__back-button" type="button" onClick={() => navigate("/quizzes")}>
          Back to Quizzes
        </button>
        <p>Quiz not found.</p>
      </div>
    )
  }

  if (isViewingHistory && !historyRecord) {
    return (
      <div className="quiz-attempt">
        <button className="quiz-attempt__back-button" type="button" onClick={() => navigate(`/quizzes/${quiz.id}`)}>
          Back to Quiz
        </button>
        <p>Saved attempt not found.</p>
      </div>
    )
  }

  if (!canStart && result === null) {
    return (
      <div className="quiz-attempt">
        <button className="quiz-attempt__back-button" type="button" onClick={() => navigate("/quizzes")}>
          Back to Quizzes
        </button>
        <section className="quiz-attempt__card" role="status">
          <h1>{quiz.title}</h1>
          <p>No attempts remaining for this quiz.</p>
        </section>
      </div>
    )
  }

  const question = attemptQuestions[currentQuestionIndex]
  const isFinalQuestion = currentQuestionIndex === attemptQuestions.length - 1
  const progress = ((currentQuestionIndex + 1) / attemptQuestions.length) * 100

  function selectAnswer(answer) {
    if (isSubmitted) {
      return
    }

    const updatedAnswers = {
      ...selectedAnswersRef.current,
      [question.id]: answer,
    }
    selectedAnswersRef.current = updatedAnswers
    setSelectedAnswers(updatedAnswers)
  }

  function submitQuiz() {
    submitAttempt()
  }

  return (
    <div className="quiz-attempt">
      <button className="quiz-attempt__back-button" type="button" onClick={() => navigate("/quizzes")}>
        Back to Quizzes
      </button>

      <section className="quiz-attempt__card">
        <header className="quiz-attempt__header">
          <div>
            <p className="quiz-attempt__subject">{quiz.subject}</p>
            <h1>{quiz.title}</h1>
          </div>
          <div className="quiz-attempt__header-details">
            {!isSubmitted && (
            <span className="quiz-attempt__question-count">
              Question {currentQuestionIndex + 1} of {attemptQuestions.length}
            </span>
            )}
            {!isViewingHistory && (
              <div className={`quiz-attempt__timer${remainingTime === 0 ? " quiz-attempt__timer--expired" : ""}`}>
                <span>Time Remaining</span>
                <strong>{formatRemainingTime(remainingTime)}</strong>
              </div>
            )}
          </div>
        </header>

        {result !== null ? (
          <div className="quiz-attempt__results">
            <section className="quiz-attempt__score" aria-labelledby="quiz-complete-title">
              <p className="quiz-attempt__eyebrow">QUIZ RESULTS</p>
              <h2 id="quiz-complete-title">Quiz Complete</h2>
              {result.attemptNumber && (
                <p className="quiz-attempt__attempt-meta">
                  Attempt {result.attemptNumber} · Completed {new Date(result.completedAt).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })}
                </p>
              )}
              <div className="quiz-attempt__score-summary">
                <div>
                  <span>Score</span>
                  <strong>{result.correctAnswers} / {result.totalQuestions}</strong>
                </div>
                <strong className="quiz-attempt__percentage">{result.percentage}%</strong>
              </div>
              <div className="quiz-attempt__answer-totals">
                <p><span>Correct Answers</span><strong>{result.correctAnswers}</strong></p>
                <p><span>Incorrect Answers</span><strong>{result.incorrectAnswers}</strong></p>
              </div>
            </section>

            <section className="quiz-attempt__review" aria-labelledby="quiz-review-title">
              <h2 id="quiz-review-title">Question Review</h2>
              <ol>
                {result.questionReview.map((review) => (
                  <li
                    className={`quiz-attempt__review-item${review.isCorrect ? " quiz-attempt__review-item--correct" : " quiz-attempt__review-item--incorrect"}`}
                    key={review.questionNumber}
                  >
                    <div className="quiz-attempt__review-heading">
                      <h3>Question {review.questionNumber}</h3>
                      <span>{review.isCorrect ? "Correct" : "Incorrect"}</span>
                    </div>
                    <p className="quiz-attempt__review-question">{review.question}</p>
                    {Array.isArray(review.choices) && (
                      <p className="quiz-attempt__review-choices">
                        <span>Choices shown:</span> {review.choices.join(" · ")}
                      </p>
                    )}
                    <p><span>Your answer:</span> {review.selectedAnswer ?? "Not answered"}</p>
                    <p><span>Correct answer:</span> {review.correctAnswer}</p>
                  </li>
                ))}
              </ol>
            </section>
          </div>
        ) : isSubmitted ? (
          <div className="quiz-attempt__submitted" role="status">
            <h2>Submitting quiz...</h2>
          </div>
        ) : (
          <>
            <div className="quiz-attempt__progress-label">
              <span>Progress</span>
              <span>{currentQuestionIndex + 1} of {attemptQuestions.length}</span>
            </div>
            <div
              className="quiz-attempt__progress-track"
              role="progressbar"
              aria-label="Quiz progress"
              aria-valuemin="1"
              aria-valuemax={attemptQuestions.length}
              aria-valuenow={currentQuestionIndex + 1}
            >
              <span style={{ width: `${progress}%` }} />
            </div>

            <div className="quiz-attempt__question">
              <h2>{question.question}</h2>
              <fieldset className="quiz-attempt__choices">
                <legend className="quiz-attempt__visually-hidden">Select one answer</legend>
                {question.choices.map((choice) => {
                  const isSelected = selectedAnswers[question.id] === choice

                  return (
                    <label
                      className={`quiz-attempt__choice${isSelected ? " quiz-attempt__choice--selected" : ""}`}
                      key={choice}
                    >
                      <input
                        type="radio"
                        name={`answer-${question.id}`}
                        value={choice}
                        checked={isSelected}
                        disabled={isSubmitted}
                        onChange={() => selectAnswer(choice)}
                      />
                      <span>{choice}</span>
                    </label>
                  )
                })}
              </fieldset>
            </div>

            <footer className="quiz-attempt__navigation">
              <button
                className="quiz-attempt__secondary-button"
                type="button"
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex((index) => index - 1)}
              >
                Previous
              </button>
              {isFinalQuestion ? (
                <button
                  className="quiz-attempt__primary-button"
                  type="button"
                  onClick={submitQuiz}
                >
                  Submit Quiz
                </button>
              ) : (
                <button
                  className="quiz-attempt__primary-button"
                  type="button"
                  onClick={() => setCurrentQuestionIndex((index) => index + 1)}
                >
                  Next
                </button>
              )}
            </footer>
          </>
        )}
      </section>
    </div>
  )
}

export default QuizAttempt

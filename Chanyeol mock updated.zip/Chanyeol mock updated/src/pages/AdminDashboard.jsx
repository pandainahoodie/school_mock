import { useState } from "react"
import {
  studentSubjects,
  teacherAssignmentDetails,
  teacherAttendanceRecords,
  teacherClassDetails,
  teacherDashboardData,
  teacherScheduleRecords,
} from "../../Data/mockData"
import MockActionModal from "../components/MockActionModal"
import "./AdminDashboard.css"

const gradePercentages = {
  A: 95,
  "A-": 91,
  "B+": 88,
  B: 82,
  "B-": 79,
  "C+": 76,
  C: 72,
  "C-": 69,
  D: 65,
  F: 50,
}

const classes = teacherDashboardData.classes
const classById = Object.fromEntries(classes.map((classItem) => [classItem.id, classItem]))
const studentById = Object.fromEntries(
  Object.values(teacherClassDetails)
    .flatMap((classDetails) => classDetails.students)
    .map((student) => [student.id, student]),
)
const teachers = new Set([
  ...studentSubjects.map((subject) => subject.teacher),
  teacherDashboardData.teacherName,
])
const totalStudents = classes.reduce((total, classItem) => total + classItem.students, 0)
const rosterGrades = Object.values(teacherClassDetails)
  .flatMap((classDetails) => classDetails.students)
const averageGrade = rosterGrades.length > 0
  ? rosterGrades.reduce((total, student) => total + (gradePercentages[student.grade] ?? 0), 0) / rosterGrades.length
  : 0
const averageAttendance = teacherAttendanceRecords.length > 0
  ? teacherAttendanceRecords.filter((record) => record.status !== "Absent").length / teacherAttendanceRecords.length * 100
  : 0
const activeAnnouncements = teacherDashboardData.recentAnnouncements
  .filter((announcement) => announcement.status === "Published").length
const upcomingSchedule = teacherScheduleRecords
  .filter((record) => record.status === "Upcoming")
  .map((record) => {
    const classItem = classById[record.classId]
    const subject = studentSubjects.find((item) => item.name === classItem?.subject)

    return classItem ? {
      ...record,
      className: classItem.name,
      subject: classItem.subject,
      teacher: subject?.teacher ?? teacherDashboardData.teacherName,
      room: classItem.room,
    } : null
  })
  .filter(Boolean)
  .sort((left, right) => left.date.localeCompare(right.date) || left.startTime.localeCompare(right.startTime))

function formatTime(time) {
  const [hours, minutes] = time.split(":").map(Number)

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "UTC",
  }).format(new Date(Date.UTC(2026, 0, 1, hours, minutes)))
}

function formatScheduleDate(date) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${date}T12:00:00Z`))
}

function getRecentGradeActivity() {
  const assignmentById = Object.fromEntries(
    teacherDashboardData.pendingGrading.map((assignment) => [assignment.id, assignment]),
  )

  return Object.entries(teacherAssignmentDetails).flatMap(([assignmentId, details]) => {
    const assignment = assignmentById[assignmentId]

    return Object.entries(details.gradesByStudent ?? {}).map(([studentId, grade]) => ({
      id: `${assignmentId}-${studentId}`,
      type: "Graded work",
      description: `${assignment?.title ?? "Assignment"} graded for ${studentById[studentId]?.name ?? studentId}: ${grade}`,
      date: details.submittedDate,
    }))
  }).slice(0, 3)
}

function AdminDashboard() {
  const [activeAction, setActiveAction] = useState(null)
  const summary = [
    { label: "Total Students", value: totalStudents },
    { label: "Total Teachers", value: teachers.size },
    { label: "Total Classes", value: classes.length },
    { label: "Total Subjects", value: studentSubjects.length },
  ]
  const overview = [
    { label: "Average Attendance", value: `${averageAttendance.toFixed(1)}%` },
    { label: "Average Grade", value: `${averageGrade.toFixed(1)}%` },
    { label: "Active Announcements", value: activeAnnouncements },
    { label: "Upcoming Classes", value: upcomingSchedule.length },
  ]
  const recentActivity = [
    ...getRecentGradeActivity(),
    ...teacherDashboardData.recentQuizActivity.map((activity) => ({
      id: activity.id,
      type: "Quiz activity",
      description: activity.description,
      date: activity.timeAgo,
    })),
    ...teacherDashboardData.recentAnnouncements.map((announcement) => ({
      id: announcement.id,
      type: "Announcement",
      description: `${announcement.title} · ${announcement.targetClass}`,
      date: announcement.date,
    })),
  ].slice(0, 7)
  const quickActions = ["Add Student", "Add Teacher", "Add Class", "Add Subject", "Add Schedule"]

  const modalConfig = {
    "Add Student": {
      title: "Add Student",
      description: "Create a new student record in this mock school roster.",
      submitLabel: "Save Student",
      fields: [
        { name: "studentName", label: "Student name", type: "text", placeholder: "e.g. Mina Park", required: true },
        { name: "studentId", label: "Student ID", type: "text", placeholder: "STU-XXXX", required: true },
        { name: "className", label: "Class", type: "select", options: classes.map((classItem) => classItem.name), value: classes[0]?.name ?? "" },
        { name: "status", label: "Status", type: "select", options: ["Active", "Inactive"], value: "Active" },
      ],
    },
    "Add Teacher": {
      title: "Add Teacher",
      description: "Add a teaching staff member to the mock school directory.",
      submitLabel: "Save Teacher",
      fields: [
        { name: "teacherName", label: "Teacher name", type: "text", placeholder: "e.g. Chloe Kim", required: true },
        { name: "teacherId", label: "Teacher ID", type: "text", placeholder: "TCH-XXXX", required: true },
        { name: "subject", label: "Subject", type: "select", options: studentSubjects.map((subject) => subject.name), value: studentSubjects[0]?.name ?? "" },
        { name: "status", label: "Status", type: "select", options: ["Active", "Inactive"], value: "Active" },
      ],
    },
    "Add Class": {
      title: "Add Class",
      description: "Create a new class for the current mock academic year.",
      submitLabel: "Save Class",
      fields: [
        { name: "className", label: "Class name", type: "text", placeholder: "e.g. Biology 210", required: true },
        { name: "subject", label: "Subject", type: "select", options: studentSubjects.map((subject) => subject.name), value: studentSubjects[0]?.name ?? "" },
        { name: "teacher", label: "Teacher", type: "select", options: [...teachers], value: [...teachers][0] ?? "" },
        { name: "room", label: "Room", type: "text", placeholder: "e.g. Lab 2A", required: true },
      ],
    },
    "Add Subject": {
      title: "Add Subject",
      description: "Introduce a new subject and assign the first teacher.",
      submitLabel: "Save Subject",
      fields: [
        { name: "subjectName", label: "Subject name", type: "text", placeholder: "e.g. Art History", required: true },
        { name: "teacher", label: "Teacher", type: "select", options: [...teachers], value: [...teachers][0] ?? "" },
        { name: "description", label: "Description", type: "textarea", placeholder: "Brief overview of the course.", required: true },
      ],
    },
    "Add Schedule": {
      title: "Add Schedule",
      description: "Plan a mock class meeting for a future school day.",
      submitLabel: "Save Schedule",
      fields: [
        { name: "className", label: "Class", type: "select", options: classes.map((classItem) => classItem.name), value: classes[0]?.name ?? "" },
        { name: "date", label: "Date", type: "date", required: true },
        { name: "startTime", label: "Start time", type: "time", required: true },
        { name: "endTime", label: "End time", type: "time", required: true },
        { name: "room", label: "Room", type: "text", placeholder: "e.g. Room 205", required: true },
      ],
    },
  }

  const activeModal = activeAction ? modalConfig[activeAction] : null

  return (
    <div className="admin-dashboard">
      <header className="admin-dashboard__welcome">
        <p className="admin-dashboard__eyebrow">SCHOOL OVERVIEW</p>
        <h1>Welcome back, Admin</h1>
        <p>Here is the latest overview of students, teaching, and school activity.</p>
      </header>

      <section className="admin-dashboard__summary" aria-label="School summary">
        {summary.map(({ label, value }) => (
          <article className="admin-dashboard__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-dashboard__overview" aria-label="School performance overview">
        {overview.map(({ label, value }) => (
          <article className="admin-dashboard__overview-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <div className="admin-dashboard__columns">
        <section className="admin-dashboard__section" aria-labelledby="admin-recent-activity-title">
          <div className="admin-dashboard__section-heading">
            <h2 id="admin-recent-activity-title">Recent Activity</h2>
            <span>{recentActivity.length} updates</span>
          </div>
          <ol className="admin-dashboard__activity-list">
            {recentActivity.map((activity) => (
              <li key={activity.id}>
                <span className="admin-dashboard__activity-marker" aria-hidden="true" />
                <div>
                  <span className="admin-dashboard__activity-type">{activity.type}</span>
                  <p>{activity.description}</p>
                  <time>{activity.date}</time>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <section className="admin-dashboard__section" aria-labelledby="admin-upcoming-classes-title">
          <div className="admin-dashboard__section-heading">
            <h2 id="admin-upcoming-classes-title">Upcoming Classes</h2>
            <span>{upcomingSchedule.length} scheduled</span>
          </div>
          <div className="admin-dashboard__schedule-list">
            {upcomingSchedule.map((schedule) => (
              <article className="admin-dashboard__schedule-row" key={schedule.id}>
                <time>
                  <strong>{formatTime(schedule.startTime)}</strong>
                  <span>{formatScheduleDate(schedule.date)}</span>
                </time>
                <div>
                  <h3>{schedule.subject}</h3>
                  <p>{schedule.className} · {schedule.teacher}</p>
                  <span>{schedule.room}</span>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>

      <section className="admin-dashboard__section" aria-labelledby="admin-quick-actions-title">
        <div className="admin-dashboard__section-heading">
          <h2 id="admin-quick-actions-title">Quick Actions</h2>
        </div>
        <div className="admin-dashboard__actions">
          {quickActions.map((action) => (
            <button className="admin-dashboard__action" type="button" key={action} onClick={() => setActiveAction(action)}>
              {action}
            </button>
          ))}
        </div>
      </section>

      {activeModal ? (
        <MockActionModal
          isOpen={Boolean(activeModal)}
          title={activeModal.title}
          description={activeModal.description}
          submitLabel={activeModal.submitLabel}
          fields={activeModal.fields}
          onClose={() => setActiveAction(null)}
          onSubmit={() => setActiveAction(null)}
        />
      ) : null}
    </div>
  )
}

export default AdminDashboard
import "./Assignments.css"
import { useNavigate } from "react-router-dom"

function Assignments({ assignments }) {
  const navigate = useNavigate()

  return (
    <div className="assignments-page">
      <div className="assignments-page__heading">
        <h1>Assignments</h1>
        <p>Review your coursework, due dates, and submission status.</p>
      </div>

      <div className="assignments-page__table-wrap">
        <table className="assignments-page__table">
          <caption className="assignments-page__visually-hidden">Student assignments</caption>
          <thead>
            <tr>
              <th scope="col">Assignment</th>
              <th scope="col">Subject</th>
              <th scope="col">Due date</th>
              <th scope="col">Status</th>
              <th scope="col"><span className="assignments-page__visually-hidden">Action</span></th>
            </tr>
          </thead>
          <tbody>
            {assignments.map(({ id, title, subject, dueDate, status }) => (
              <tr key={id}>
                <th scope="row">{title}</th>
                <td>{subject}</td>
                <td>{dueDate}</td>
                <td>
                  <span className={`assignments-page__status assignments-page__status--${status.toLowerCase()}`}>
                    {status}
                  </span>
                </td>
                <td>
                  <button
                    className="assignments-page__view-button"
                    type="button"
                    onClick={() => navigate(`/assignments/${id}`)}
                  >
                    View Assignment
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Assignments

import { useNavigate } from "react-router-dom"
import { studentQuizzes } from "../../Data/mockData"
import "./Quizzes.css"

function Quizzes({ completedAttempts, quizHistory }) {
  const navigate = useNavigate()

  return (
    <div className="quizzes-page">
      <div className="quizzes-page__heading">
        <h1>Quizzes</h1>
        <p>Review your upcoming quizzes, topics, and remaining attempts.</p>
      </div>

      <section className="quizzes-page__grid" aria-label="Student quizzes">
        {studentQuizzes.map((quiz) => {
          const attemptsUsed = completedAttempts[quiz.id] ?? quiz.attemptsUsed
          const attemptsRemaining = Math.max(quiz.maxAttempts - attemptsUsed, 0)
          const canStart = quiz.status === "Available" && attemptsRemaining > 0
          const history = quizHistory[quiz.id] ?? []

          return (
            <article className="quizzes-page__card" key={quiz.id}>
              <div className="quizzes-page__card-heading">
                <div>
                  <p className="quizzes-page__subject">{quiz.subject}</p>
                  <h2>{quiz.title}</h2>
                </div>
                <span className={`quizzes-page__status quizzes-page__status--${quiz.status.toLowerCase()}`}>
                  {quiz.status}
                </span>
              </div>

              <p className="quizzes-page__description">{quiz.description}</p>

              <dl className="quizzes-page__details">
                <div>
                  <dt>Topic</dt>
                  <dd>{quiz.topic}</dd>
                </div>
                <div>
                  <dt>Due date</dt>
                  <dd>{quiz.dueDate}</dd>
                </div>
                <div>
                  <dt>Time limit</dt>
                  <dd>{quiz.timeLimit} minutes</dd>
                </div>
                <div>
                  <dt>Attempts used</dt>
                  <dd>{attemptsUsed} / {quiz.maxAttempts}</dd>
                </div>
              </dl>

              {canStart ? (
                <button
                  className="quizzes-page__start-button"
                  type="button"
                  onClick={() => navigate(`/quizzes/${quiz.id}`)}
                >
                  Start Quiz
                </button>
              ) : (
                <p className="quizzes-page__availability">
                  {attemptsRemaining === 0
                    ? "No attempts remaining"
                    : quiz.status === "Completed"
                      ? "Quiz completed"
                      : "Not available yet"}
                </p>
              )}

              <section className="quizzes-page__history" aria-label={`${quiz.title} attempt history`}>
                <h3>Attempt History</h3>
                {history.length === 0 ? (
                  <p className="quizzes-page__history-empty">No completed attempts yet.</p>
                ) : (
                  <ul>
                    {history.map((attempt) => (
                      <li className="quizzes-page__history-item" key={attempt.id}>
                        <div className="quizzes-page__history-info">
                          <strong>Attempt {attempt.attemptNumber}</strong>
                          <span>{attempt.score} / {attempt.totalQuestions} · {attempt.percentage}%</span>
                          <time dateTime={attempt.completedAt}>
                            Completed {new Date(attempt.completedAt).toLocaleDateString("en-US", {
                              month: "short",
                              day: "numeric",
                              year: "numeric",
                            })}
                          </time>
                        </div>
                        <button
                          className="quizzes-page__history-button"
                          type="button"
                          onClick={() => navigate(`/quizzes/${quiz.id}?history=${encodeURIComponent(attempt.id)}`)}
                        >
                          View Results
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </article>
          )
        })}
      </section>
    </div>
  )
}

export default Quizzes

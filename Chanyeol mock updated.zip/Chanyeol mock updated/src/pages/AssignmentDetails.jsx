import "./AssignmentDetails.css"
import { useNavigate, useParams } from "react-router-dom"

function AssignmentDetails({ assignments, onSubmit }) {
  const { assignmentId } = useParams()
  const navigate = useNavigate()
  const assignment = assignments.find((item) => item.id === assignmentId)

  if (!assignment) {
    return (
      <div className="assignment-details">
        <button
          className="assignment-details__back-button"
          type="button"
          onClick={() => navigate("/assignments")}
        >
          Back to Assignments
        </button>
        <p>Assignment not found.</p>
      </div>
    )
  }

  return (
    <div className="assignment-details">
      <button
        className="assignment-details__back-button"
        type="button"
        onClick={() => navigate("/assignments")}
      >
        Back to Assignments
      </button>

      <article className="assignment-details__card">
        <div className="assignment-details__heading">
          <div>
            <p className="assignment-details__eyebrow">ASSIGNMENT DETAILS</p>
            <h1>{assignment.title}</h1>
          </div>
          <span className={`assignment-details__status assignment-details__status--${assignment.status.toLowerCase()}`}>
            {assignment.status}
          </span>
        </div>

        <dl className="assignment-details__metadata">
          <div>
            <dt>Subject</dt>
            <dd>{assignment.subject}</dd>
          </div>
          <div>
            <dt>Due date</dt>
            <dd>{assignment.dueDate}</dd>
          </div>
          <div>
            <dt>Status</dt>
            <dd>{assignment.status}</dd>
          </div>
        </dl>

        <section className="assignment-details__description" aria-labelledby="assignment-description-title">
          <h2 id="assignment-description-title">Description</h2>
          <p>{assignment.description}</p>
        </section>

        {assignment.status === "Pending" ? (
          <button
            className="assignment-details__submit-button"
            type="button"
            onClick={() => onSubmit(assignment.id)}
          >
            Submit Assignment
          </button>
        ) : (
          <p className="assignment-details__status-message" role="status">
            {assignment.status === "Submitted"
              ? "Your assignment has been submitted."
              : "This assignment has been graded."}
          </p>
        )}
      </article>
    </div>
  )
}

export default AssignmentDetails

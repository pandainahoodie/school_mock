import { useState } from "react"
import { teacherDashboardData } from "../../Data/mockData"
import MockActionModal from "../components/MockActionModal"
import "./TeacherDashboard.css"

function TeacherDashboard() {
  const [activeAction, setActiveAction] = useState(null)
  const totalStudents = teacherDashboardData.classes.reduce(
    (total, classItem) => total + classItem.students,
    0,
  )
  const classById = Object.fromEntries(
    teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
  )
  const summaryItems = [
    { label: "My Classes", value: teacherDashboardData.classes.length },
    { label: "Total Students", value: totalStudents },
    { label: "Pending Grading", value: teacherDashboardData.pendingGrading.length },
    { label: "Upcoming Classes", value: teacherDashboardData.upcomingClasses.length },
  ]
  const quickActions = ["Create Quiz", "Add Assignment", "Post Announcement", "Add Material"]

  const modalConfig = {
    "Create Quiz": {
      title: "Create Quiz",
      description: "Draft a new assessment for one of your classes.",
      submitLabel: "Publish Quiz",
      fields: [
        { name: "quizTitle", label: "Quiz title", type: "text", placeholder: "e.g. Chapter 5 Review", required: true },
        { name: "className", label: "Class", type: "select", options: teacherDashboardData.classes.map((classItem) => classItem.name), value: teacherDashboardData.classes[0]?.name ?? "" },
        { name: "dueDate", label: "Due date", type: "date", required: true },
        { name: "duration", label: "Duration (minutes)", type: "number", placeholder: "30", required: true },
      ],
    },
    "Add Assignment": {
      title: "Add Assignment",
      description: "Create a new assignment for the current unit.",
      submitLabel: "Save Assignment",
      fields: [
        { name: "assignmentTitle", label: "Assignment title", type: "text", placeholder: "e.g. Lab Reflection", required: true },
        { name: "className", label: "Class", type: "select", options: teacherDashboardData.classes.map((classItem) => classItem.name), value: teacherDashboardData.classes[0]?.name ?? "" },
        { name: "dueDate", label: "Due date", type: "date", required: true },
        { name: "points", label: "Points", type: "number", placeholder: "100", required: true },
      ],
    },
    "Post Announcement": {
      title: "Post Announcement",
      description: "Share a school update with a class or whole school community.",
      submitLabel: "Publish",
      fields: [
        { name: "announcementTitle", label: "Title", type: "text", placeholder: "e.g. Midterm Review", required: true },
        { name: "className", label: "Audience", type: "select", options: ["All classes", ...teacherDashboardData.classes.map((classItem) => classItem.name)], value: "All classes" },
        { name: "message", label: "Message", type: "textarea", placeholder: "Write your announcement here.", required: true },
      ],
    },
    "Add Material": {
      title: "Add Material",
      description: "Upload a lesson resource for students to review.",
      submitLabel: "Save Material",
      fields: [
        { name: "materialTitle", label: "Material title", type: "text", placeholder: "e.g. Algebra Notes", required: true },
        { name: "className", label: "Class", type: "select", options: teacherDashboardData.classes.map((classItem) => classItem.name), value: teacherDashboardData.classes[0]?.name ?? "" },
        { name: "type", label: "Type", type: "select", options: ["Lesson Notes", "Worksheet", "Presentation", "Video", "PDF"], value: "Lesson Notes" },
        { name: "description", label: "Description", type: "textarea", placeholder: "Describe what students will review.", required: true },
      ],
    },
  }

  const activeModal = activeAction ? modalConfig[activeAction] : null

  return (
    <div className="teacher-dashboard">
      <section className="teacher-dashboard__welcome">
        <p className="teacher-dashboard__eyebrow">TEACHER OVERVIEW</p>
        <h1>Welcome back, {teacherDashboardData.teacherName}!</h1>
        <p>Here's what's happening with your classes today.</p>
      </section>

      <section className="teacher-dashboard__summary" aria-label="Teaching summary">
        {summaryItems.map(({ label, value }) => (
          <article className="teacher-dashboard__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <div className="teacher-dashboard__two-column">
        <section className="teacher-dashboard__section" aria-labelledby="todays-classes-title">
          <div className="teacher-dashboard__section-heading">
            <h2 id="todays-classes-title">Today's Classes</h2>
          </div>
          <div className="teacher-dashboard__list-card">
            {teacherDashboardData.upcomingClasses.map((upcomingClass) => {
              const classItem = classById[upcomingClass.classId]

              return (
                <article className="teacher-dashboard__class-row" key={upcomingClass.classId}>
                  <time>{upcomingClass.time}</time>
                  <div>
                    <h3>{classItem.name}</h3>
                    <span>{classItem.room}</span>
                  </div>
                  <span className="teacher-dashboard__student-count">{classItem.students} students</span>
                </article>
              )
            })}
          </div>
        </section>

        <section className="teacher-dashboard__section" aria-labelledby="pending-grading-title">
          <div className="teacher-dashboard__section-heading">
            <h2 id="pending-grading-title">Pending Grading</h2>
            <span>{teacherDashboardData.pendingGrading.length} items</span>
          </div>
          <div className="teacher-dashboard__list-card">
            {teacherDashboardData.pendingGrading.slice(0, 3).map((item) => (
              <article className="teacher-dashboard__grading-row" key={item.id}>
                <div>
                  <h3>{item.title}</h3>
                  <span>{item.className} · {item.submissions} submissions</span>
                </div>
                <time>Due {item.dueDate}</time>
              </article>
            ))}
          </div>
        </section>
      </div>

      <div className="teacher-dashboard__two-column">
        <section className="teacher-dashboard__section" aria-labelledby="recent-quiz-activity-title">
          <div className="teacher-dashboard__section-heading">
            <h2 id="recent-quiz-activity-title">Recent Quiz Activity</h2>
          </div>
          <ol className="teacher-dashboard__activity-list">
            {teacherDashboardData.recentQuizActivity.map((activity) => (
              <li key={activity.id}>
                <span className="teacher-dashboard__activity-marker" aria-hidden="true" />
                <div>
                  <p>{activity.description}</p>
                  <span>{activity.timeAgo}</span>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <section className="teacher-dashboard__section" aria-labelledby="recent-announcements-title">
          <div className="teacher-dashboard__section-heading">
            <h2 id="recent-announcements-title">Recent Announcements</h2>
          </div>
          <div className="teacher-dashboard__list-card">
            {teacherDashboardData.recentAnnouncements.map((announcement) => (
              <article className="teacher-dashboard__announcement-row" key={announcement.id}>
                <div>
                  <h3>{announcement.title}</h3>
                  <span>{announcement.targetClass}</span>
                </div>
                <time>{announcement.date}</time>
              </article>
            ))}
          </div>
        </section>
      </div>

      <section className="teacher-dashboard__section" aria-labelledby="my-classes-title">
        <div className="teacher-dashboard__section-heading">
          <h2 id="my-classes-title">My Classes</h2>
        </div>
        <div className="teacher-dashboard__class-grid">
          {teacherDashboardData.classes.map((classItem) => (
            <article className="teacher-dashboard__class-card" key={classItem.id}>
              <div>
                <h3>{classItem.name}</h3>
                <span>{classItem.subject}</span>
              </div>
              <dl>
                <div><dt>Students</dt><dd>{classItem.students}</dd></div>
                <div><dt>Schedule</dt><dd>{classItem.schedule}</dd></div>
                <div><dt>Room</dt><dd>{classItem.room}</dd></div>
              </dl>
            </article>
          ))}
        </div>
      </section>

      <section className="teacher-dashboard__section" aria-labelledby="quick-actions-title">
        <div className="teacher-dashboard__section-heading">
          <h2 id="quick-actions-title">Quick Actions</h2>
        </div>
        <div className="teacher-dashboard__actions">
          {quickActions.map((action) => (
            <button className="teacher-dashboard__action" type="button" key={action} onClick={() => setActiveAction(action)}>
              {action}
            </button>
          ))}
        </div>
      </section>

      {activeModal ? (
        <MockActionModal
          isOpen={Boolean(activeModal)}
          title={activeModal.title}
          description={activeModal.description}
          submitLabel={activeModal.submitLabel}
          fields={activeModal.fields}
          onClose={() => setActiveAction(null)}
          onSubmit={() => setActiveAction(null)}
        />
      ) : null}
    </div>
  )
}

export default TeacherDashboard

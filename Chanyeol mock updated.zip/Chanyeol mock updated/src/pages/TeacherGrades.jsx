import { useState } from "react"
import { teacherClassDetails, teacherDashboardData } from "../../Data/mockData"
import "./TeacherGrades.css"

const gradePercentages = {
  A: 95,
  "A-": 91,
  "B+": 88,
  B: 82,
  "B-": 79,
  "C+": 76,
  C: 72,
  "C-": 69,
  D: 65,
  F: 50,
}

function TeacherGrades() {
  const [classFilter, setClassFilter] = useState("All classes")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [search, setSearch] = useState("")
  const gradeRows = teacherDashboardData.classes.flatMap((classItem) =>
    (teacherClassDetails[classItem.id]?.students ?? []).map((student) => {
      const percentage = gradePercentages[student.grade] ?? 0

      return {
        ...student,
        classId: classItem.id,
        className: classItem.name,
        subject: classItem.subject,
        percentage,
        status: percentage < 85 ? "Needs Attention" : "Passing",
      }
    }),
  )
  const normalizedSearch = search.trim().toLowerCase()
  const filteredRows = gradeRows.filter((student) => {
    const matchesClass = classFilter === "All classes" || student.classId === classFilter
    const matchesSubject = subjectFilter === "All subjects" || student.subject === subjectFilter
    const matchesSearch = [student.name, student.id]
      .some((value) => value.toLowerCase().includes(normalizedSearch))

    return matchesClass && matchesSubject && matchesSearch
  })
  const overallAverage = gradeRows.length > 0
    ? gradeRows.reduce((total, student) => total + student.percentage, 0) / gradeRows.length
    : 0
  const subjects = [...new Set(teacherDashboardData.classes.map((classItem) => classItem.subject))]

  const summary = [
    { label: "Classes", value: teacherDashboardData.classes.length },
    { label: "Students", value: new Set(gradeRows.map((student) => student.id)).size },
    { label: "Overall Average", value: `${overallAverage.toFixed(1)}%` },
  ]

  return (
    <div className="teacher-grades">
      <header className="teacher-grades__heading">
        <h1>Grades</h1>
        <p>Review current student performance across your classes.</p>
      </header>

      <section className="teacher-grades__summary" aria-label="Grade summary">
        {summary.map(({ label, value }) => (
          <article className="teacher-grades__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="teacher-grades__section" aria-labelledby="teacher-grades-title">
        <div className="teacher-grades__toolbar">
          <div>
            <h2 id="teacher-grades-title">Student Grades</h2>
            <p>{filteredRows.length} of {gradeRows.length} students</p>
          </div>
          <div className="teacher-grades__filters">
            <label>
              <span className="teacher-grades__visually-hidden">Filter by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {teacherDashboardData.classes.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span className="teacher-grades__visually-hidden">Filter by subject</span>
              <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
                <option value="All subjects">All subjects</option>
                {subjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
              </select>
            </label>
            <label>
              <span className="teacher-grades__visually-hidden">Search by student name or ID</span>
              <input
                type="search"
                placeholder="Search student or ID..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
          </div>
        </div>

        <div className="teacher-grades__table-wrap">
          <table className="teacher-grades__table">
            <thead>
              <tr>
                <th scope="col">Student</th>
                <th scope="col">Student ID</th>
                <th scope="col">Class</th>
                <th scope="col">Subject</th>
                <th scope="col">Current Grade</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredRows.length > 0 ? filteredRows.map((student) => (
                <tr key={student.id}>
                  <th scope="row" data-label="Student">{student.name}</th>
                  <td data-label="Student ID">{student.id}</td>
                  <td data-label="Class">{student.className}</td>
                  <td data-label="Subject">{student.subject}</td>
                  <td data-label="Current Grade">{student.percentage}% ({student.grade})</td>
                  <td data-label="Status">
                    <span className={`teacher-grades__status teacher-grades__status--${student.status === "Passing" ? "passing" : "attention"}`}>
                      {student.status}
                    </span>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="teacher-grades__empty" colSpan="6">No students match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

export default TeacherGrades
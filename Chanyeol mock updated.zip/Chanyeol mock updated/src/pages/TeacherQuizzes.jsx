import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { teacherDashboardData, teacherQuizzes } from "../../Data/mockData"
import "./TeacherQuizzes.css"

const statusFilters = ["All statuses", "Published", "Draft"]

function TeacherQuizzes() {
  const navigate = useNavigate()
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const classById = Object.fromEntries(
    teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
  )
  const quizzes = teacherQuizzes.map((quiz) => {
    const classItem = classById[quiz.classId]

    return {
      ...quiz,
      className: classItem?.name ?? "Unassigned",
      questionCount: quiz.questions?.length ?? quiz.questionCount ?? 0,
    }
  })
  const normalizedSearch = search.trim().toLowerCase()
  const filteredQuizzes = quizzes.filter((quiz) => {
    const matchesSearch = [quiz.title, quiz.subject, quiz.className]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesStatus = statusFilter === "All statuses" || quiz.status === statusFilter

    return matchesSearch && matchesStatus
  })
  const summary = [
    { label: "Total Quizzes", value: quizzes.length },
    { label: "Published", value: quizzes.filter((quiz) => quiz.status === "Published").length },
    { label: "Drafts", value: quizzes.filter((quiz) => quiz.status === "Draft").length },
    { label: "Total Questions", value: quizzes.reduce((total, quiz) => total + quiz.questionCount, 0) },
  ]

  return (
    <div className="teacher-quizzes">
      <div className="teacher-quizzes__heading">
        <h1>Quizzes</h1>
        <p>Create and manage quizzes for your classes.</p>
      </div>

      <section className="teacher-quizzes__summary" aria-label="Quiz summary">
        {summary.map(({ label, value }) => (
          <article className="teacher-quizzes__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="teacher-quizzes__section" aria-labelledby="teacher-quiz-list-title">
        <div className="teacher-quizzes__toolbar">
          <h2 id="teacher-quiz-list-title">All Quizzes</h2>
          <div className="teacher-quizzes__filters">
            <label>
              <span className="teacher-quizzes__visually-hidden">Search quizzes</span>
              <input
                type="search"
                placeholder="Search title, subject, or class..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="teacher-quizzes__visually-hidden">Filter quizzes by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                {statusFilters.map((status) => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
            </label>
          </div>
        </div>

        <div className="teacher-quizzes__table-wrap">
          <table className="teacher-quizzes__table">
            <thead>
              <tr>
                <th scope="col">Quiz</th>
                <th scope="col">Class</th>
                <th scope="col">Subject</th>
                <th scope="col">Questions</th>
                <th scope="col">Time Limit</th>
                <th scope="col">Attempts</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredQuizzes.length > 0 ? filteredQuizzes.map((quiz) => (
                <tr key={quiz.id}>
                  <th scope="row" data-label="Quiz">{quiz.title}</th>
                  <td data-label="Class">{quiz.className}</td>
                  <td data-label="Subject">{quiz.subject}</td>
                  <td data-label="Questions">{quiz.questionCount}</td>
                  <td data-label="Time Limit">{quiz.timeLimit} min</td>
                  <td data-label="Attempts">{quiz.maxAttempts}</td>
                  <td data-label="Status">
                    <span className={`teacher-quizzes__status teacher-quizzes__status--${quiz.status.toLowerCase()}`}>
                      {quiz.status}
                    </span>
                  </td>
                  <td data-label="Action">
                    <button
                      className="teacher-quizzes__view-button"
                      type="button"
                      onClick={() => navigate(`/teacher/quizzes/${quiz.id}`)}
                    >
                      View Quiz
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="teacher-quizzes__empty" colSpan="8">No quizzes match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

export default TeacherQuizzes

import { useState } from "react"
import { Link } from "react-router-dom"
import { teacherDashboardData } from "../../Data/mockData"
import "./TeacherAnnouncements.css"

const classByName = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.name, classItem]),
)
const announcements = teacherDashboardData.recentAnnouncements.map((announcement) => ({
  ...announcement,
  author: teacherDashboardData.teacherName,
  classId: classByName[announcement.targetClass]?.id ?? "",
}))

function TeacherAnnouncements() {
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("All classes")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const normalizedSearch = search.trim().toLowerCase()
  const filteredAnnouncements = announcements.filter((announcement) => {
    const matchesSearch = [announcement.title, announcement.content]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesClass = classFilter === "All classes" || announcement.classId === classFilter
    const matchesStatus = statusFilter === "All statuses" || announcement.status === statusFilter

    return matchesSearch && matchesClass && matchesStatus
  })
  const summary = [
    { label: "Total Announcements", value: announcements.length },
    { label: "Published", value: announcements.filter((item) => item.status === "Published").length },
    { label: "Draft", value: announcements.filter((item) => item.status === "Draft").length },
  ]

  return (
    <div className="teacher-announcements">
      <header className="teacher-announcements__heading">
        <h1>Announcements</h1>
        <p>View announcements shared with your classes.</p>
      </header>

      <section className="teacher-announcements__summary" aria-label="Announcement summary">
        {summary.map(({ label, value }) => (
          <article className="teacher-announcements__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="teacher-announcements__section" aria-labelledby="announcement-list-title">
        <div className="teacher-announcements__toolbar">
          <div>
            <h2 id="announcement-list-title">Class Announcements</h2>
            <p>Showing {filteredAnnouncements.length} of {announcements.length}</p>
          </div>
          <div className="teacher-announcements__filters">
            <label>
              <span className="teacher-announcements__visually-hidden">Search announcements by title or content</span>
              <input
                type="search"
                placeholder="Search announcements..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="teacher-announcements__visually-hidden">Filter announcements by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {teacherDashboardData.classes.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span className="teacher-announcements__visually-hidden">Filter announcements by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Published">Published</option>
                <option value="Draft">Draft</option>
              </select>
            </label>
          </div>
        </div>

        <div className="teacher-announcements__list" aria-live="polite">
          {filteredAnnouncements.length > 0 ? filteredAnnouncements.map((announcement) => (
            <article className="teacher-announcements__card" key={announcement.id}>
              <div className="teacher-announcements__card-heading">
                <div>
                  <h3>
                    <Link to={`/teacher/announcements/${announcement.id}`}>{announcement.title}</Link>
                  </h3>
                  <p className="teacher-announcements__class">{announcement.targetClass}</p>
                </div>
                <span className={`teacher-announcements__status teacher-announcements__status--${announcement.status.toLowerCase()}`}>
                  {announcement.status}
                </span>
              </div>
              <p className="teacher-announcements__preview">{announcement.content}</p>
              <footer className="teacher-announcements__meta">
                <span>{announcement.author}</span>
                <time>{announcement.date}</time>
              </footer>
              <Link className="teacher-announcements__details-link" to={`/teacher/announcements/${announcement.id}`}>
                View details
              </Link>
            </article>
          )) : (
            <p className="teacher-announcements__empty">No announcements match your filters.</p>
          )}
        </div>
      </section>
    </div>
  )
}

export default TeacherAnnouncements
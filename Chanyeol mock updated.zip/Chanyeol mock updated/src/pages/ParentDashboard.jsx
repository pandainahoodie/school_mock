import { Link } from "react-router-dom"
import {
  studentAttendanceRecords,
  studentGrades,
  studentLearningActivities,
  studentLearningProgress,
  teacherClassDetails,
  teacherDashboardData,
  teacherScheduleRecords,
} from "../../Data/mockData"
import "./ParentDashboard.css"

const STUDENT_ID = "STU-1042"
const MOCK_TODAY = "2026-09-29"
const rosterEntry = Object.entries(teacherClassDetails)
  .flatMap(([classId, classDetails]) => classDetails.students.map((student) => ({ ...student, classId })))
  .find((student) => student.id === STUDENT_ID)
const classItem = teacherDashboardData.classes.find((item) => item.id === rosterEntry?.classId)
const overallGrade = studentGrades.length > 0
  ? studentGrades.reduce((total, grade) => total + grade.percentage, 0) / studentGrades.length
  : 0
const attendedRecords = studentAttendanceRecords.filter((record) => record.status === "Present" || record.status === "Late")
const attendanceRate = studentAttendanceRecords.length > 0
  ? attendedRecords.length / studentAttendanceRecords.length * 100
  : 0
const completedLessons = studentLearningProgress.reduce((total, item) => total + item.completedLessons, 0)
const totalLessons = studentLearningProgress.reduce((total, item) => total + item.totalLessons, 0)
const overallProgress = totalLessons > 0 ? completedLessons / totalLessons * 100 : 0
const upcomingSchedule = teacherScheduleRecords
  .filter((record) => record.classId === rosterEntry?.classId && record.date >= MOCK_TODAY && record.status === "Upcoming")
  .sort((left, right) => left.date.localeCompare(right.date) || left.startTime.localeCompare(right.startTime))
const recentActivities = studentLearningActivities
  .slice()
  .sort((left, right) => right.date.localeCompare(left.date))
const recentAnnouncements = teacherDashboardData.recentAnnouncements
  .filter((announcement) => announcement.targetClass === classItem?.name)
  .sort((left, right) => Date.parse(right.date) - Date.parse(left.date))
const parentActions = [
  { label: "View Grades", to: "/parent/grades" },
  { label: "View Attendance", to: "/parent/attendance" },
  { label: "View Assignments", to: "/parent/assignments" },
  { label: "View Quiz Results", to: "/parent/quiz-results" },
  { label: "View Progress", to: "/parent/progress" },
  { label: "View Announcements", to: "/parent/announcements" },
]

function formatTime(time) {
  const [hours, minutes] = time.split(":").map(Number)

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "UTC",
  }).format(new Date(Date.UTC(2026, 0, 1, hours, minutes)))
}

function formatDate(date) {
  return new Date(`${date}T12:00:00Z`).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  })
}

function ParentDashboard({ assignments }) {
  const upcomingAssignments = assignments.filter((assignment) => (
    assignment.status === "Pending" && Date.parse(assignment.dueDate) >= Date.parse(MOCK_TODAY)
  ))
  const summary = [
    { label: "Overall Grade", value: `${overallGrade.toFixed(1)}%` },
    { label: "Attendance", value: `${attendanceRate.toFixed(1)}%` },
    { label: "Pending Assignments", value: upcomingAssignments.length },
    { label: "Overall Progress", value: `${overallProgress.toFixed(1)}%` },
  ]

  return (
    <div className="parent-dashboard">
      <section className="parent-dashboard__welcome">
        <p className="parent-dashboard__eyebrow">PARENT OVERVIEW</p>
        <h1>Welcome back</h1>
        <p>Here's an overview of {rosterEntry?.name ?? "your child"}'s school activity.</p>
      </section>

      <section className="parent-dashboard__child" aria-label="Child information">
        <div className="parent-dashboard__child-heading">
          <div>
            <span>Student</span>
            <h2>{rosterEntry?.name ?? "Student record unavailable"}</h2>
          </div>
          <span className="parent-dashboard__student-id">{rosterEntry?.id ?? "No student ID"}</span>
        </div>
          <Link className="parent-dashboard__child-link" to="/parent/child">View Child Profile</Link>
        <dl className="parent-dashboard__child-details">
          <div>
            <dt>Class</dt>
            <dd>{classItem?.name ?? "Not assigned"}</dd>
          </div>
          <div>
            <dt>Overall Grade</dt>
            <dd>{overallGrade.toFixed(1)}%</dd>
          </div>
          <div>
            <dt>Attendance Rate</dt>
            <dd>{attendanceRate.toFixed(1)}%</dd>
          </div>
          <div>
            <dt>Overall Progress</dt>
            <dd>{overallProgress.toFixed(1)}%</dd>
          </div>
        </dl>
      </section>

      <section className="parent-dashboard__summary" aria-label="Academic summary">
        {summary.map(({ label, value }) => (
          <article className="parent-dashboard__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <div className="parent-dashboard__columns">
        <section className="parent-dashboard__section" aria-labelledby="parent-activity-title">
          <div className="parent-dashboard__section-heading">
            <h2 id="parent-activity-title">Recent Academic Activity</h2>
          </div>
          <ol className="parent-dashboard__activity-list">
            {recentActivities.map((activity) => (
              <li key={activity.id}>
                <span className="parent-dashboard__activity-marker" aria-hidden="true" />
                <div>
                  <span>{activity.type} · {activity.subject}</span>
                  <p>{activity.title}</p>
                  <time>{formatDate(activity.date)}</time>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <section className="parent-dashboard__section" aria-labelledby="parent-assignments-title">
          <div className="parent-dashboard__section-heading">
            <h2 id="parent-assignments-title">Upcoming Assignments</h2>
            <span>{upcomingAssignments.length} pending</span>
          </div>
          <div className="parent-dashboard__list-card">
            {upcomingAssignments.length > 0 ? upcomingAssignments.map((assignment) => (
              <article className="parent-dashboard__assignment-row" key={assignment.id}>
                <div>
                  <h3>{assignment.title}</h3>
                  <span>{assignment.subject}</span>
                </div>
                <div className="parent-dashboard__assignment-meta">
                  <time>Due {assignment.dueDate}</time>
                  <span>{assignment.status}</span>
                </div>
              </article>
            )) : <p className="parent-dashboard__empty">No upcoming assignments.</p>}
          </div>
        </section>
      </div>

      <div className="parent-dashboard__columns">
        <section className="parent-dashboard__section" aria-labelledby="parent-schedule-title">
          <div className="parent-dashboard__section-heading">
            <h2 id="parent-schedule-title">Upcoming Schedule</h2>
          </div>
          <div className="parent-dashboard__list-card">
            {upcomingSchedule.length > 0 ? upcomingSchedule.map((entry) => (
              <article className="parent-dashboard__schedule-row" key={entry.id}>
                <time>{formatDate(entry.date)} · {formatTime(entry.startTime)}</time>
                <div>
                  <h3>{classItem?.subject}</h3>
                  <span>{classItem?.name} · {classItem?.room}</span>
                </div>
              </article>
            )) : <p className="parent-dashboard__empty">No upcoming classes.</p>}
          </div>
        </section>

        <section className="parent-dashboard__section" aria-labelledby="parent-announcements-title">
          <div className="parent-dashboard__section-heading">
            <h2 id="parent-announcements-title">Recent Announcements</h2>
          </div>
          <div className="parent-dashboard__list-card">
            {recentAnnouncements.length > 0 ? recentAnnouncements.map((announcement) => (
              <article className="parent-dashboard__announcement-row" key={announcement.id}>
                <div>
                  <h3>{announcement.title}</h3>
                  <p>{announcement.content}</p>
                </div>
                <time>{announcement.date}</time>
              </article>
            )) : <p className="parent-dashboard__empty">No recent announcements.</p>}
          </div>
        </section>
      </div>

      <section className="parent-dashboard__section" aria-labelledby="parent-quick-links-title">
        <div className="parent-dashboard__section-heading">
          <h2 id="parent-quick-links-title">Quick Navigation</h2>
        </div>
        <div className="parent-dashboard__actions">
          {parentActions.map(({ label, to }) => (
            <Link className="parent-dashboard__action" to={to} key={to}>
              {label}
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}

export default ParentDashboard
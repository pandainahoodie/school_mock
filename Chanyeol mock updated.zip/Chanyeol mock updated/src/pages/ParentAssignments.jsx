import { useState } from "react"
import { Link } from "react-router-dom"
import "./ParentAssignments.css"

function ParentAssignments({ assignments }) {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const normalizedSearch = search.trim().toLowerCase()
  const filteredAssignments = [...assignments]
    .filter((assignment) => (
      (assignment.title.toLowerCase().includes(normalizedSearch) || assignment.subject.toLowerCase().includes(normalizedSearch)) &&
      (statusFilter === "All statuses" || assignment.status === statusFilter)
    ))
    .sort((left, right) => Date.parse(left.dueDate) - Date.parse(right.dueDate))
  const statuses = [...new Set(assignments.map((assignment) => assignment.status))]

  return (
    <div className="parent-academic parent-assignments">
      <header className="parent-academic__heading">
        <div>
          <h1>Assignments</h1>
          <p>Track Chanyeol's coursework, due dates, and submission status.</p>
        </div>
        <Link className="parent-academic__back-link" to="/parent">Parent Dashboard</Link>
      </header>

      <section className="parent-academic__section" aria-labelledby="parent-assignments-title">
        <div className="parent-academic__toolbar">
          <div>
            <h2 id="parent-assignments-title">All Assignments</h2>
            <p>Showing {filteredAssignments.length} of {assignments.length}</p>
          </div>
          <div className="parent-academic__filters parent-assignments__filters">
            <label>
              <span className="parent-academic__visually-hidden">Search assignments by title or subject</span>
              <input type="search" placeholder="Search assignments..." value={search} onChange={(event) => setSearch(event.target.value)} />
            </label>
            <label>
              <span className="parent-academic__visually-hidden">Filter assignments by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                {statuses.map((status) => <option key={status} value={status}>{status}</option>)}
              </select>
            </label>
          </div>
        </div>

        <div className="parent-academic__table-wrap">
          <table className="parent-academic__table">
            <thead><tr><th>Assignment</th><th>Subject</th><th>Due Date</th><th>Status</th></tr></thead>
            <tbody>
              {filteredAssignments.length > 0 ? filteredAssignments.map((assignment) => (
                <tr key={assignment.id}>
                  <th scope="row" data-label="Assignment">{assignment.title}</th>
                  <td data-label="Subject">{assignment.subject}</td>
                  <td data-label="Due Date">{assignment.dueDate}</td>
                  <td data-label="Status"><span className={`parent-academic__status parent-academic__status--${assignment.status.toLowerCase()}`}>{assignment.status}</span></td>
                </tr>
              )) : <tr><td className="parent-academic__empty" colSpan="4">No assignments match your filters.</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

export default ParentAssignments
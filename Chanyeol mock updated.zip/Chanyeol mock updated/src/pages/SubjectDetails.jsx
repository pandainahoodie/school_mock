import { useNavigate, useParams } from "react-router-dom"
import { initialAssignments, studentSubjects } from "../../Data/mockData"
import "./SubjectDetails.css"

function SubjectDetails() {
  const { subjectId } = useParams()
  const navigate = useNavigate()
  const subject = studentSubjects.find((item) => item.id === subjectId)

  if (!subject) {
    return (
      <div className="subject-details">
        <button className="subject-details__back-button" type="button" onClick={() => navigate("/subjects")}>
          Back to My Subjects
        </button>
        <p>Subject not found.</p>
      </div>
    )
  }

  const subjectAssignments = initialAssignments.filter(
    (assignment) =>
      assignment.subject === subject.name &&
      assignment.status === "Pending" &&
      !assignment.title.toLowerCase().includes("quiz"),
  )
  const subjectQuizzes = initialAssignments.filter(
    (assignment) =>
      assignment.subject === subject.name &&
      assignment.status === "Pending" &&
      assignment.title.toLowerCase().includes("quiz"),
  )

  return (
    <div className="subject-details">
      <button className="subject-details__back-button" type="button" onClick={() => navigate("/subjects")}>
        Back to My Subjects
      </button>

      <article className="subject-details__card">
        <header className="subject-details__heading">
          <div>
            <p className="subject-details__eyebrow">SUBJECT DETAILS</p>
            <h1>{subject.name}</h1>
          </div>
          <span className="subject-details__progress-value">{subject.progress}% complete</span>
        </header>

        <dl className="subject-details__metadata">
          <div>
            <dt>Teacher</dt>
            <dd>{subject.teacher}</dd>
          </div>
          <div>
            <dt>Schedule</dt>
            <dd>{subject.schedule}</dd>
          </div>
          <div>
            <dt>Room</dt>
            <dd>{subject.room}</dd>
          </div>
        </dl>

        <div
          className="subject-details__progress-track"
          role="progressbar"
          aria-label={`${subject.name} progress`}
          aria-valuemin="0"
          aria-valuemax="100"
          aria-valuenow={subject.progress}
        >
          <span style={{ width: `${subject.progress}%` }} />
        </div>

        <section className="subject-details__overview" aria-labelledby="subject-overview-title">
          <h2 id="subject-overview-title">Subject Overview</h2>
          <p>{subject.overview}</p>
        </section>

        <div className="subject-details__activities">
          <section className="subject-details__activity" aria-labelledby="subject-assignments-title">
            <h2 id="subject-assignments-title">Upcoming Assignments</h2>
            {subjectAssignments.length > 0 ? (
              <ul>
                {subjectAssignments.map((assignment) => (
                  <li key={assignment.id}>
                    <span>{assignment.title}</span>
                    <time>{assignment.dueDate}</time>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="subject-details__empty">No upcoming assignments.</p>
            )}
          </section>

          <section className="subject-details__activity" aria-labelledby="subject-quizzes-title">
            <h2 id="subject-quizzes-title">Upcoming Quizzes</h2>
            {subjectQuizzes.length > 0 ? (
              <ul>
                {subjectQuizzes.map((quiz) => (
                  <li key={quiz.id}>
                    <span>{quiz.title}</span>
                    <time>{quiz.dueDate}</time>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="subject-details__empty">No upcoming quizzes scheduled.</p>
            )}
          </section>
        </div>
      </article>
    </div>
  )
}

export default SubjectDetails

import { Link, useNavigate, useParams } from "react-router-dom"
import { studentSubjects, teacherDashboardData, teacherScheduleRecords } from "../../Data/mockData"
import "./AdminSchedules.css"

const classById = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
)
const subjectByName = Object.fromEntries(studentSubjects.map((subject) => [subject.name, subject]))
const scheduleEntries = teacherScheduleRecords.flatMap((record) => {
  const classItem = classById[record.classId]
  if (!classItem) {
    return []
  }

  return [{
    ...record,
    className: classItem.name,
    subject: classItem.subject,
    teacher: subjectByName[classItem.subject]?.teacher ?? teacherDashboardData.teacherName,
    room: classItem.room,
  }]
})

function formatTime(time) {
  const [hours, minutes] = time.split(":").map(Number)

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "UTC",
  }).format(new Date(Date.UTC(2026, 0, 1, hours, minutes)))
}

function AdminScheduleDetails() {
  const { scheduleId } = useParams()
  const navigate = useNavigate()
  const entry = scheduleEntries.find((record) => record.id === scheduleId)

  if (!entry) {
    return (
      <div className="admin-schedule-details">
        <section className="admin-schedule-details__not-found">
          <h1>Schedule not found</h1>
          <button type="button" onClick={() => navigate("/admin/schedules")}>
            Back to Schedules
          </button>
        </section>
      </div>
    )
  }

  return (
    <div className="admin-schedule-details">
      <button
        className="admin-schedule-details__back-button"
        type="button"
        onClick={() => navigate("/admin/schedules")}
      >
        Back to Schedules
      </button>

      <header className="admin-schedule-details__heading">
        <div>
          <p className="admin-schedule-details__eyebrow">Schedule Entry · {entry.date}</p>
          <h1>{entry.className}</h1>
        </div>
        <span className={`admin-schedules__status admin-schedules__status--${entry.status.toLowerCase()}`}>
          {entry.status}
        </span>
      </header>

      <section className="admin-schedule-details__summary" aria-label="Schedule details">
        <article>
          <span>Date</span>
          <strong>{entry.date}</strong>
        </article>
        <article>
          <span>Start Time</span>
          <strong>{formatTime(entry.startTime)}</strong>
        </article>
        <article>
          <span>End Time</span>
          <strong>{formatTime(entry.endTime)}</strong>
        </article>
        <article>
          <span>Subject</span>
          <strong>{entry.subject}</strong>
        </article>
        <article>
          <span>Teacher</span>
          <strong>{entry.teacher}</strong>
        </article>
        <article>
          <span>Room</span>
          <strong>{entry.room}</strong>
        </article>
      </section>

      <section className="admin-schedule-details__section" aria-labelledby="schedule-related-title">
        <div className="admin-schedule-details__section-heading">
          <h2 id="schedule-related-title">Related Views</h2>
        </div>
        <div className="admin-schedule-details__links">
          <Link to={`/teacher/classes/${entry.classId}`}>Class Details</Link>
          <Link to={`/teacher/classes/${entry.classId}/students`}>Student Roster</Link>
          <Link to="/teacher/schedule">Teacher Schedule</Link>
        </div>
      </section>
    </div>
  )
}

export default AdminScheduleDetails
import { studentAttendanceRecords, studentSubjects } from "../../Data/mockData"
import "./Attendance.css"

const statusOrder = ["Present", "Late", "Absent"]

function formatPercentage(value) {
  return `${value.toFixed(1).replace(/\.0$/, "")}%`
}

function formatDate(date) {
  const [year, month, day] = date.split("-").map(Number)
  return new Date(year, month - 1, day).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  })
}

function Attendance() {
  const totalRecords = studentAttendanceRecords.length
  const presentCount = studentAttendanceRecords.filter((record) => record.status === "Present").length
  const lateCount = studentAttendanceRecords.filter((record) => record.status === "Late").length
  const absentCount = studentAttendanceRecords.filter((record) => record.status === "Absent").length
  const attendedCount = presentCount + lateCount
  const overallAttendance = totalRecords > 0 ? (attendedCount / totalRecords) * 100 : 0
  const recentRecords = [...studentAttendanceRecords].sort((left, right) =>
    right.date.localeCompare(left.date),
  )
  const subjectSummaries = studentSubjects.map((subject) => {
    const records = studentAttendanceRecords.filter((record) => record.subjectId === subject.id)
    const attended = records.filter((record) => record.status !== "Absent").length
    const percentage = records.length > 0 ? (attended / records.length) * 100 : 0

    return { ...subject, attended, total: records.length, percentage }
  })
  const countsByStatus = {
    Present: presentCount,
    Late: lateCount,
    Absent: absentCount,
  }

  return (
    <div className="attendance-page">
      <div className="attendance-page__heading">
        <h1>Attendance</h1>
        <p>Review your attendance record and consistency by subject.</p>
      </div>

      <section className="attendance-page__summary" aria-label="Overall attendance summary">
        <article className="attendance-page__overall-card">
          <span>Overall Attendance</span>
          <strong>{formatPercentage(overallAttendance)}</strong>
          <div
            className="attendance-page__progress-track"
            role="progressbar"
            aria-label="Overall attendance"
            aria-valuemin="0"
            aria-valuemax="100"
            aria-valuenow={overallAttendance}
          >
            <span style={{ width: `${overallAttendance}%` }} />
          </div>
        </article>
        {statusOrder.map((status) => (
          <article className="attendance-page__count-card" key={status}>
            <span className={`attendance-page__status-badge attendance-page__status-badge--${status.toLowerCase()}`}>
              {status}
            </span>
            <strong>{countsByStatus[status]}</strong>
            <span>records</span>
          </article>
        ))}
      </section>

      <section className="attendance-page__section" aria-labelledby="recent-attendance-title">
        <div className="attendance-page__section-heading">
          <h2 id="recent-attendance-title">Recent Attendance</h2>
        </div>
        <div className="attendance-page__table-wrap">
          <table className="attendance-page__table">
            <thead>
              <tr>
                <th scope="col">Date</th>
                <th scope="col">Subject</th>
                <th scope="col">Status</th>
                <th scope="col">Remarks</th>
              </tr>
            </thead>
            <tbody>
              {recentRecords.map((record) => (
                <tr key={record.id}>
                  <td data-label="Date"><time dateTime={record.date}>{formatDate(record.date)}</time></td>
                  <td data-label="Subject">{record.subject}</td>
                  <td data-label="Status">
                    <span className={`attendance-page__status-badge attendance-page__status-badge--${record.status.toLowerCase()}`}>
                      {record.status}
                    </span>
                  </td>
                  <td data-label="Remarks">{record.remarks || "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="attendance-page__section" aria-labelledby="subject-attendance-title">
        <div className="attendance-page__section-heading">
          <h2 id="subject-attendance-title">By Subject</h2>
        </div>
        <div className="attendance-page__subject-grid">
          {subjectSummaries.map((subject) => (
            <article className="attendance-page__subject-card" key={subject.id}>
              <div className="attendance-page__subject-heading">
                <h3>{subject.name}</h3>
                <strong>{formatPercentage(subject.percentage)}</strong>
              </div>
              <div
                className="attendance-page__progress-track"
                role="progressbar"
                aria-label={`${subject.name} attendance`}
                aria-valuemin="0"
                aria-valuemax="100"
                aria-valuenow={subject.percentage}
              >
                <span style={{ width: `${subject.percentage}%` }} />
              </div>
              <p>{subject.attended} / {subject.total} attended</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}

export default Attendance

import { useEffect, useRef, useState } from "react"
import { Link } from "react-router-dom"
import {
  adminStudentClasses,
  readAdminStudents,
  saveAdminStudents,
} from "./adminStudentData"
import MockActionModal from "../components/MockActionModal"
import "./AdminStudents.css"

function AdminStudents() {
  const [students, setStudents] = useState(readAdminStudents)
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("All classes")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const [activeStudentModal, setActiveStudentModal] = useState(null)
  const [studentToDelete, setStudentToDelete] = useState(null)
  const [feedback, setFeedback] = useState("")
  const feedbackTimer = useRef(null)
  const normalizedSearch = search.trim().toLowerCase()
  const filteredStudents = students.filter((student) => {
    const matchesSearch = [student.name, student.studentId]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesClass = classFilter === "All classes" || student.classId === classFilter
    const matchesStatus = statusFilter === "All statuses" || student.status === statusFilter

    return matchesSearch && matchesClass && matchesStatus
  })
  const summary = [
    { label: "Total Students", value: students.length },
    { label: "Active Students", value: students.filter((student) => student.status === "Active").length },
    { label: "Inactive Students", value: students.filter((student) => student.status === "Inactive").length },
    { label: "Classes", value: new Set(students.map((student) => student.classId)).size },
  ]

  const modalFields = [
    {
      name: "name",
      label: "Student Name",
      type: "text",
      placeholder: "e.g. Yuna Lee",
      value: activeStudentModal?.student?.name ?? "",
      required: true,
    },
    {
      name: "studentId",
      label: "Student ID",
      type: "text",
      placeholder: "STU-XXXX",
      value: activeStudentModal?.student?.studentId ?? "",
      required: true,
    },
    {
      name: "className",
      label: "Class",
      type: "select",
      options: adminStudentClasses.map((classItem) => classItem.name),
      value: activeStudentModal?.student?.className ?? adminStudentClasses[0]?.name ?? "",
      required: true,
    },
    {
      name: "status",
      label: "Status",
      type: "select",
      options: ["Active", "Inactive"],
      value: activeStudentModal?.student?.status ?? "Active",
      required: true,
    },
  ]

  useEffect(() => () => window.clearTimeout(feedbackTimer.current), [])

  useEffect(() => {
    if (!studentToDelete) {
      return undefined
    }

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setStudentToDelete(null)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [studentToDelete])

  function showFeedback(message) {
    window.clearTimeout(feedbackTimer.current)
    setFeedback(message)
    feedbackTimer.current = window.setTimeout(() => setFeedback(""), 3500)
  }

  function commitStudents(updatedStudents) {
    setStudents(updatedStudents)
    saveAdminStudents(updatedStudents)
  }

  function validateStudent(values) {
    const enteredId = values.studentId.trim().toLowerCase()
    const editingId = activeStudentModal?.student?.studentId
    const duplicate = students.some((student) => (
      student.studentId.toLowerCase() === enteredId && student.studentId !== editingId
    ))

    return duplicate ? { studentId: "This Student ID is already in use." } : {}
  }

  function handleSaveStudent(values) {
    const studentId = values.studentId.trim()
    const name = values.name.trim()
    const classItem = adminStudentClasses.find((item) => item.name === values.className)

    if (!classItem) {
      return
    }

    if (activeStudentModal.mode === "edit") {
      const originalStudent = activeStudentModal.student
      const legacyIds = [...(originalStudent.legacyIds ?? [])]
      if (studentId !== originalStudent.studentId && !legacyIds.includes(originalStudent.studentId)) {
        legacyIds.push(originalStudent.studentId)
      }

      commitStudents(students.map((student) => student.studentId === originalStudent.studentId
        ? {
          ...student,
          id: studentId,
          studentId,
          name,
          classId: classItem.id,
          className: classItem.name,
          status: values.status,
          legacyIds,
        }
        : student))
      setActiveStudentModal(null)
      showFeedback("Student updated successfully.")
      return
    }

    commitStudents([
      ...students,
      {
        id: studentId,
        studentId,
        name,
        classId: classItem.id,
        className: classItem.name,
        status: values.status,
        attendance: null,
        grade: null,
        legacyIds: [],
      },
    ])
    setActiveStudentModal(null)
    showFeedback("Student added successfully.")
  }

  function handleDeleteStudent() {
    if (!studentToDelete) {
      return
    }

    commitStudents(students.filter((student) => student.studentId !== studentToDelete.studentId))
    setStudentToDelete(null)
    showFeedback("Student deleted successfully.")
  }

  return (
    <div className="admin-students">
      <header className="admin-students__heading">
        <div>
          <h1>Students</h1>
          <p>View and manage enrolled students across the school.</p>
        </div>
        <button className="admin-students__add-button" type="button" onClick={() => setActiveStudentModal({ mode: "add" })}>
          Add Student
        </button>
      </header>

      <section className="admin-students__summary" aria-label="Student summary">
        {summary.map(({ label, value }) => (
          <article className="admin-students__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-students__section" aria-labelledby="admin-student-list-title">
        <div className="admin-students__toolbar">
          <div>
            <h2 id="admin-student-list-title">Enrolled Students</h2>
            <p>Showing {filteredStudents.length} of {students.length}</p>
          </div>
          <div className="admin-students__filters">
            <label>
              <span className="admin-students__visually-hidden">Search by student name or ID</span>
              <input
                type="search"
                placeholder="Search students..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="admin-students__visually-hidden">Filter students by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {adminStudentClasses.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span className="admin-students__visually-hidden">Filter students by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </label>
          </div>
        </div>

        <div className="admin-students__table-wrap">
          <table className="admin-students__table">
            <thead>
              <tr>
                <th scope="col">Student Name</th>
                <th scope="col">Student ID</th>
                <th scope="col">Class</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.length > 0 ? filteredStudents.map((student) => (
                <tr key={student.studentId}>
                  <th scope="row" data-label="Student Name">{student.name}</th>
                  <td data-label="Student ID">{student.studentId}</td>
                  <td data-label="Class">{student.className}</td>
                  <td data-label="Status">
                    <span className={`admin-students__status admin-students__status--${student.status.toLowerCase()}`}>
                      {student.status}
                    </span>
                  </td>
                  <td data-label="Action">
                    <div className="admin-students__row-actions">
                      <Link className="admin-students__view-link" to={`/admin/students/${student.studentId}`}>
                        View
                      </Link>
                      <button
                        className="admin-students__row-action"
                        type="button"
                        onClick={() => setActiveStudentModal({ mode: "edit", student })}
                      >
                        Edit
                      </button>
                      <button
                        className="admin-students__row-action admin-students__row-action--delete"
                        type="button"
                        onClick={() => setStudentToDelete(student)}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="admin-students__empty" colSpan="5">No students match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {activeStudentModal ? (
        <MockActionModal
          key={`${activeStudentModal.mode}-${activeStudentModal.student?.studentId ?? "new"}`}
          isOpen
          title={activeStudentModal.mode === "edit" ? "Edit Student" : "Add Student"}
          description={activeStudentModal.mode === "edit"
            ? "Update this student record."
            : "Create a new student record for the mock school roster."}
          submitLabel={activeStudentModal.mode === "edit" ? "Save Changes" : "Add Student"}
          fields={modalFields}
          validate={validateStudent}
          onClose={() => setActiveStudentModal(null)}
          onSubmit={handleSaveStudent}
        />
      ) : null}

      {studentToDelete ? (
        <div className="admin-students__confirm-backdrop" onClick={() => setStudentToDelete(null)}>
          <section
            className="admin-students__confirm-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="delete-student-title"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              className="admin-students__confirm-close"
              type="button"
              aria-label="Close confirmation"
              onClick={() => setStudentToDelete(null)}
            >
              ×
            </button>
            <h2 id="delete-student-title">Delete this student?</h2>
            <p>Delete <strong>{studentToDelete.name}</strong> from the student list?</p>
            <div className="admin-students__confirm-actions">
              <button type="button" onClick={() => setStudentToDelete(null)}>Cancel</button>
              <button type="button" className="admin-students__confirm-delete" onClick={handleDeleteStudent}>
                Delete
              </button>
            </div>
          </section>
        </div>
      ) : null}

      {feedback ? (
        <div className="admin-students__toast" role="status" aria-live="polite">
          {feedback}
        </div>
      ) : null}
    </div>
  )
}

export default AdminStudents
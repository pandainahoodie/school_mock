import { useState } from "react"
import { Link } from "react-router-dom"
import { adminTeacherRecords, studentSubjects, teacherDashboardData } from "../../Data/mockData"
import MockActionModal from "../components/MockActionModal"
import "./AdminClasses.css"

const subjectByName = Object.fromEntries(studentSubjects.map((subject) => [subject.name, subject]))
const teachers = [...new Set(teacherDashboardData.classes.map((classItem) => (
  subjectByName[classItem.subject]?.teacher ?? adminTeacherRecords.find((teacher) => teacher.classIds.includes(classItem.id))?.name
)).filter(Boolean))]
const classes = teacherDashboardData.classes.map((classItem) => ({
  ...classItem,
  teacher: subjectByName[classItem.subject]?.teacher ?? adminTeacherRecords.find((teacher) => teacher.classIds.includes(classItem.id))?.name ?? "Unassigned",
  status: classItem.status ?? "Active",
}))
const subjects = [...new Set(classes.map((classItem) => classItem.subject))]

function AdminClasses() {
  const [search, setSearch] = useState("")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [teacherFilter, setTeacherFilter] = useState("All teachers")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const [activeModal, setActiveModal] = useState(false)
  const normalizedSearch = search.trim().toLowerCase()
  const filteredClasses = classes.filter((classItem) => {
    const matchesSearch = [classItem.name, classItem.teacher, classItem.subject]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesSubject = subjectFilter === "All subjects" || classItem.subject === subjectFilter
    const matchesTeacher = teacherFilter === "All teachers" || classItem.teacher === teacherFilter
    const matchesStatus = statusFilter === "All statuses" || classItem.status === statusFilter

    return matchesSearch && matchesSubject && matchesTeacher && matchesStatus
  })
  const summary = [
    { label: "Total Classes", value: classes.length },
    { label: "Active Classes", value: classes.filter((classItem) => classItem.status === "Active").length },
    { label: "Inactive Classes", value: classes.filter((classItem) => classItem.status === "Inactive").length },
    { label: "Total Students", value: classes.reduce((total, classItem) => total + classItem.students, 0) },
  ]

  const modalFields = [
    { name: "className", label: "Class name", type: "text", placeholder: "e.g. Biology 210", required: true },
    { name: "subject", label: "Subject", type: "select", options: subjects, value: subjects[0] ?? "" },
    { name: "teacher", label: "Teacher", type: "select", options: teachers, value: teachers[0] ?? "" },
    { name: "room", label: "Room", type: "text", placeholder: "e.g. Lab 2A", required: true },
    { name: "studentCount", label: "Students", type: "number", placeholder: "30", required: true },
    { name: "status", label: "Status", type: "select", options: ["Active", "Inactive"], value: "Active" },
  ]

  return (
    <div className="admin-classes">
      <header className="admin-classes__heading">
        <div>
          <h1>Classes</h1>
          <p>View and manage the school's classes and enrollment.</p>
        </div>
        <button className="admin-classes__add-button" type="button" onClick={() => setActiveModal(true)}>
          Add Class
        </button>
      </header>

      <section className="admin-classes__summary" aria-label="Class summary">
        {summary.map(({ label, value }) => (
          <article className="admin-classes__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-classes__section" aria-labelledby="admin-class-list-title">
        <div className="admin-classes__toolbar">
          <div>
            <h2 id="admin-class-list-title">School Classes</h2>
            <p>Showing {filteredClasses.length} of {classes.length}</p>
          </div>
          <div className="admin-classes__filters">
            <label>
              <span className="admin-classes__visually-hidden">Search classes by name, teacher, or subject</span>
              <input
                type="search"
                placeholder="Search classes..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="admin-classes__visually-hidden">Filter classes by subject</span>
              <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
                <option value="All subjects">All subjects</option>
                {subjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
              </select>
            </label>
            <label>
              <span className="admin-classes__visually-hidden">Filter classes by teacher</span>
              <select value={teacherFilter} onChange={(event) => setTeacherFilter(event.target.value)}>
                <option value="All teachers">All teachers</option>
                {teachers.map((teacher) => <option key={teacher} value={teacher}>{teacher}</option>)}
              </select>
            </label>
            <label>
              <span className="admin-classes__visually-hidden">Filter classes by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </label>
          </div>
        </div>

        <div className="admin-classes__table-wrap">
          <table className="admin-classes__table">
            <thead>
              <tr>
                <th scope="col">Class</th>
                <th scope="col">Subject</th>
                <th scope="col">Teacher</th>
                <th scope="col">Room</th>
                <th scope="col">Students</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredClasses.length > 0 ? filteredClasses.map((classItem) => (
                <tr key={classItem.id}>
                  <th scope="row" data-label="Class">{classItem.name}</th>
                  <td data-label="Subject">{classItem.subject}</td>
                  <td data-label="Teacher">{classItem.teacher}</td>
                  <td data-label="Room">{classItem.room}</td>
                  <td data-label="Students">{classItem.students}</td>
                  <td data-label="Status">
                    <span className={`admin-classes__status admin-classes__status--${classItem.status.toLowerCase()}`}>
                      {classItem.status}
                    </span>
                  </td>
                  <td data-label="Action">
                    <Link className="admin-classes__view-link" to={`/admin/classes/${classItem.id}`}>
                      View Class
                    </Link>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="admin-classes__empty" colSpan="7">No classes match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <MockActionModal
        isOpen={activeModal}
        title="Add Class"
        description="Create a mock class record and assign it to staff and space."
        submitLabel="Save Class"
        fields={modalFields}
        onClose={() => setActiveModal(false)}
        onSubmit={() => setActiveModal(false)}
      />
    </div>
  )
}

export default AdminClasses
import "./StudentDashboard.css"

const summaryItems = [
  { label: "Subjects", value: "6" },
  { label: "Pending Assignments", value: "4" },
  { label: "Attendance", value: "95%" },
]

const upcomingAssignments = [
  { title: "Mathematics Quiz", dueDate: "Sep 30" },
  { title: "English Essay", dueDate: "Oct 2" },
  { title: "Science Worksheet", dueDate: "Oct 4" },
]

const todaysSchedule = [
  { time: "09:00", subject: "Mathematics" },
  { time: "11:00", subject: "English" },
  { time: "14:00", subject: "Science" },
]

function StudentDashboard() {
  return (
    <div className="student-dashboard">
      <section className="student-dashboard__welcome" aria-labelledby="student-welcome-title">
        <p className="student-dashboard__eyebrow">STUDENT OVERVIEW</p>
        <h1 id="student-welcome-title">Welcome back, Chanyeol!</h1>
        <p>Here's what's happening with your learning today.</p>
      </section>

      <section className="student-dashboard__summary" aria-label="Learning summary">
        {summaryItems.map(({ label, value }) => (
          <article className="student-dashboard__summary-card" key={label}>
            <h2>{label}</h2>
            <p>{value}</p>
          </article>
        ))}
      </section>

      <div className="student-dashboard__details">
        <section className="student-dashboard__panel" aria-labelledby="upcoming-assignments-title">
          <h2 id="upcoming-assignments-title">Upcoming Assignments</h2>
          <ul className="student-dashboard__list">
            {upcomingAssignments.map(({ title, dueDate }) => (
              <li className="student-dashboard__list-item" key={title}>
                <span>{title}</span>
                <time>{`Due ${dueDate}`}</time>
              </li>
            ))}
          </ul>
        </section>

        <section className="student-dashboard__panel" aria-labelledby="todays-schedule-title">
          <h2 id="todays-schedule-title">Today's Schedule</h2>
          <ul className="student-dashboard__list">
            {todaysSchedule.map(({ time, subject }) => (
              <li className="student-dashboard__list-item" key={time}>
                <time>{time}</time>
                <span>{subject}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  )
}

export default StudentDashboard

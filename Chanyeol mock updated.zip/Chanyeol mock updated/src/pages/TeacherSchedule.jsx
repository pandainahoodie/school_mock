import { useState } from "react"
import { Link } from "react-router-dom"
import { teacherDashboardData, teacherScheduleRecords } from "../../Data/mockData"
import "./TeacherSchedule.css"

const INITIAL_SCHEDULE_DATE = "2026-09-29"
const classById = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
)
const scheduleEntries = teacherScheduleRecords.flatMap((record) => {
  const classItem = classById[record.classId]

  return classItem ? [{ ...record, className: classItem.name, subject: classItem.subject, room: classItem.room }] : []
})

function shiftDate(date, offset) {
  const [year, month, day] = date.split("-").map(Number)
  return new Date(Date.UTC(year, month - 1, day + offset)).toISOString().slice(0, 10)
}

function formatDate(date) {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${date}T00:00:00Z`))
}

function formatTime(time) {
  const [hours, minutes] = time.split(":").map(Number)
  return new Intl.DateTimeFormat("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
    timeZone: "UTC",
  }).format(new Date(Date.UTC(2026, 0, 1, hours, minutes)))
}

function getWeekStart(date) {
  const weekday = new Date(`${date}T00:00:00Z`).getUTCDay()
  const daysSinceMonday = (weekday + 6) % 7

  return shiftDate(date, -daysSinceMonday)
}

function TeacherSchedule() {
  const [selectedDate, setSelectedDate] = useState(INITIAL_SCHEDULE_DATE)
  const [classFilter, setClassFilter] = useState("All classes")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const filteredEntries = scheduleEntries.filter((entry) => (
    (classFilter === "All classes" || entry.classId === classFilter) &&
    (subjectFilter === "All subjects" || entry.subject === subjectFilter) &&
    (statusFilter === "All statuses" || entry.status === statusFilter)
  ))
  const dayEntries = filteredEntries
    .filter((entry) => entry.date === selectedDate)
    .sort((left, right) => left.startTime.localeCompare(right.startTime))
  const weekStart = getWeekStart(selectedDate)
  const weekEnd = shiftDate(weekStart, 6)
  const weekEntries = filteredEntries.filter((entry) => entry.date >= weekStart && entry.date <= weekEnd)
  const upcomingClasses = weekEntries.filter((entry) => entry.status === "Upcoming").length
  const weekLabel = selectedDate === INITIAL_SCHEDULE_DATE ? "Today's Classes" : "Selected Day Classes"
  const summary = [
    { label: weekLabel, value: dayEntries.length },
    { label: "Upcoming Classes", value: upcomingClasses },
    { label: "Classes This Week", value: weekEntries.length },
  ]
  const subjects = [...new Set(teacherDashboardData.classes.map((classItem) => classItem.subject))]

  return (
    <div className="teacher-schedule">
      <header className="teacher-schedule__heading">
        <h1>Schedule</h1>
        <p>View your upcoming classes and weekly teaching schedule.</p>
      </header>

      <section className="teacher-schedule__summary" aria-label="Schedule summary">
        {summary.map(({ label, value }) => (
          <article className="teacher-schedule__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="teacher-schedule__section" aria-labelledby="teacher-schedule-date">
        <div className="teacher-schedule__toolbar">
          <div className="teacher-schedule__day-heading">
            <h2 id="teacher-schedule-date">{formatDate(selectedDate)}</h2>
            <button type="button" onClick={() => setSelectedDate(INITIAL_SCHEDULE_DATE)}>
              Today
            </button>
          </div>
          <div className="teacher-schedule__day-navigation" aria-label="Choose schedule day">
            <button
              type="button"
              aria-label="Previous day"
              onClick={() => setSelectedDate((date) => shiftDate(date, -1))}
            >
              Previous Day
            </button>
            <button
              type="button"
              aria-label="Next day"
              onClick={() => setSelectedDate((date) => shiftDate(date, 1))}
            >
              Next Day
            </button>
          </div>
        </div>

        <div className="teacher-schedule__filters">
          <label>
            <span className="teacher-schedule__visually-hidden">Filter by class</span>
            <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
              <option value="All classes">All classes</option>
              {teacherDashboardData.classes.map((classItem) => (
                <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
              ))}
            </select>
          </label>
          <label>
            <span className="teacher-schedule__visually-hidden">Filter by subject</span>
            <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
              <option value="All subjects">All subjects</option>
              {subjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
            </select>
          </label>
          <label>
            <span className="teacher-schedule__visually-hidden">Filter by status</span>
            <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
              <option value="All statuses">All statuses</option>
              <option value="Upcoming">Upcoming</option>
              <option value="Ongoing">Ongoing</option>
              <option value="Completed">Completed</option>
            </select>
          </label>
        </div>

        <div className="teacher-schedule__timeline" aria-live="polite">
          {dayEntries.length > 0 ? dayEntries.map((entry) => (
            <Link
              className="teacher-schedule__class"
              key={entry.id}
              to={`/teacher/classes/${entry.classId}`}
              aria-label={`View ${entry.className} class details, ${entry.subject}, ${formatTime(entry.startTime)} to ${formatTime(entry.endTime)}`}
            >
              <div className="teacher-schedule__time">
                <time>{formatTime(entry.startTime)}</time>
                <span>{formatTime(entry.endTime)}</span>
              </div>
              <div className="teacher-schedule__class-info">
                <h3>{entry.subject}</h3>
                <p>{entry.className}</p>
                <span>{entry.room}</span>
              </div>
              <span className={`teacher-schedule__status teacher-schedule__status--${entry.status.toLowerCase()}`}>
                {entry.status}
              </span>
            </Link>
          )) : (
            <p className="teacher-schedule__empty">No classes scheduled for this day.</p>
          )}
        </div>
      </section>
    </div>
  )
}

export default TeacherSchedule
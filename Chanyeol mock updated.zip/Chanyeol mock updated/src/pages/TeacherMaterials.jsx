import { useState } from "react"
import { Link } from "react-router-dom"
import { teacherDashboardData, teacherLearningMaterials } from "../../Data/mockData"
import "./TeacherMaterials.css"

const classById = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
)
const materials = teacherLearningMaterials.map((material) => {
  const classItem = classById[material.classId]

  return {
    ...material,
    className: classItem?.name ?? "Unknown class",
    subject: classItem?.subject ?? "Unknown subject",
  }
})

function TeacherMaterials() {
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("All classes")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [typeFilter, setTypeFilter] = useState("All types")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const normalizedSearch = search.trim().toLowerCase()
  const filteredMaterials = materials.filter((material) => {
    const matchesSearch = [material.title, material.description]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesClass = classFilter === "All classes" || material.classId === classFilter
    const matchesSubject = subjectFilter === "All subjects" || material.subject === subjectFilter
    const matchesType = typeFilter === "All types" || material.type === typeFilter
    const matchesStatus = statusFilter === "All statuses" || material.status === statusFilter

    return matchesSearch && matchesClass && matchesSubject && matchesType && matchesStatus
  })
  const summary = [
    { label: "Total Materials", value: materials.length },
    { label: "Published", value: materials.filter((item) => item.status === "Published").length },
    { label: "Draft", value: materials.filter((item) => item.status === "Draft").length },
  ]
  const subjects = [...new Set(materials.map((material) => material.subject))]
  const types = [...new Set(materials.map((material) => material.type))]

  return (
    <div className="teacher-materials">
      <header className="teacher-materials__heading">
        <h1>Learning Materials</h1>
        <p>Organize and share learning resources with your classes.</p>
      </header>

      <section className="teacher-materials__summary" aria-label="Learning materials summary">
        {summary.map(({ label, value }) => (
          <article className="teacher-materials__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="teacher-materials__section" aria-labelledby="teacher-materials-title">
        <div className="teacher-materials__toolbar">
          <div>
            <h2 id="teacher-materials-title">All Materials</h2>
            <p>Showing {filteredMaterials.length} of {materials.length}</p>
          </div>
          <div className="teacher-materials__filters">
            <label>
              <span className="teacher-materials__visually-hidden">Search materials by title or description</span>
              <input
                type="search"
                placeholder="Search materials..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="teacher-materials__visually-hidden">Filter materials by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {teacherDashboardData.classes.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span className="teacher-materials__visually-hidden">Filter materials by subject</span>
              <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
                <option value="All subjects">All subjects</option>
                {subjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
              </select>
            </label>
            <label>
              <span className="teacher-materials__visually-hidden">Filter materials by type</span>
              <select value={typeFilter} onChange={(event) => setTypeFilter(event.target.value)}>
                <option value="All types">All types</option>
                {types.map((type) => <option key={type} value={type}>{type}</option>)}
              </select>
            </label>
            <label>
              <span className="teacher-materials__visually-hidden">Filter materials by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Published">Published</option>
                <option value="Draft">Draft</option>
              </select>
            </label>
          </div>
        </div>

        <div className="teacher-materials__list" aria-live="polite">
          {filteredMaterials.length > 0 ? filteredMaterials.map((material) => (
            <article className="teacher-materials__card" key={material.id}>
              <div className="teacher-materials__card-heading">
                <div>
                  <h3>
                    <Link to={`/teacher/materials/${material.id}`}>{material.title}</Link>
                  </h3>
                  <p className="teacher-materials__subject">{material.subject}</p>
                </div>
                <span className={`teacher-materials__status teacher-materials__status--${material.status.toLowerCase()}`}>
                  {material.status}
                </span>
              </div>
              <p className="teacher-materials__preview">{material.description}</p>
              <dl className="teacher-materials__metadata">
                <div>
                  <dt>Class</dt>
                  <dd><Link to={`/teacher/classes/${material.classId}`}>{material.className}</Link></dd>
                </div>
                <div>
                  <dt>Type</dt>
                  <dd>{material.type}</dd>
                </div>
                <div>
                  <dt>Date</dt>
                  <dd><time>{material.date}</time></dd>
                </div>
              </dl>
              <Link className="teacher-materials__details-link" to={`/teacher/materials/${material.id}`}>
                View details
              </Link>
            </article>
          )) : (
            <p className="teacher-materials__empty">No materials match your filters.</p>
          )}
        </div>
      </section>
    </div>
  )
}

export default TeacherMaterials
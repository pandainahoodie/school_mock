import { useState } from "react"
import { Link } from "react-router-dom"
import {
  studentSubjects,
  teacherClassDetails,
  teacherDashboardData,
} from "../../Data/mockData"
import MockActionModal from "../components/MockActionModal"
import "./AdminSubjects.css"

const classRecords = teacherDashboardData.classes
const subjects = studentSubjects.map((subject) => {
  const assignedClasses = classRecords.filter((classItem) => classItem.subject === subject.name)
  const students = assignedClasses.flatMap((classItem) => teacherClassDetails[classItem.id]?.students ?? [])

  return {
    ...subject,
    teachers: [subject.teacher],
    classes: assignedClasses,
    students: [...new Set(students.map((student) => student.id))],
    status: "Active",
  }
})
const teachers = [...new Set(subjects.flatMap((subject) => subject.teachers))]
const totalEnrolledStudents = new Set(subjects.flatMap((subject) => subject.students)).size

function AdminSubjects() {
  const [search, setSearch] = useState("")
  const [teacherFilter, setTeacherFilter] = useState("All teachers")
  const [classFilter, setClassFilter] = useState("All classes")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const [activeModal, setActiveModal] = useState(false)
  const normalizedSearch = search.trim().toLowerCase()
  const filteredSubjects = subjects.filter((subject) => {
    const matchesSearch = [
      subject.name,
      ...subject.teachers,
      ...subject.classes.map((classItem) => classItem.name),
    ].some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesTeacher = teacherFilter === "All teachers" || subject.teachers.includes(teacherFilter)
    const matchesClass = classFilter === "All classes" || subject.classes.some((classItem) => classItem.id === classFilter)
    const matchesStatus = statusFilter === "All statuses" || subject.status === statusFilter

    return matchesSearch && matchesTeacher && matchesClass && matchesStatus
  })
  const summary = [
    { label: "Total Subjects", value: subjects.length },
    { label: "Active Subjects", value: subjects.filter((subject) => subject.status === "Active").length },
    { label: "Inactive Subjects", value: subjects.filter((subject) => subject.status === "Inactive").length },
    { label: "Enrolled Students", value: totalEnrolledStudents },
  ]

  const modalFields = [
    { name: "subjectName", label: "Subject name", type: "text", placeholder: "e.g. Art History", required: true },
    { name: "teacher", label: "Teacher", type: "select", options: teachers, value: teachers[0] ?? "" },
    { name: "description", label: "Description", type: "textarea", placeholder: "Overview of this course.", required: true },
    { name: "status", label: "Status", type: "select", options: ["Active", "Inactive"], value: "Active" },
  ]

  return (
    <div className="admin-subjects">
      <header className="admin-subjects__heading">
        <div>
          <h1>Subjects</h1>
          <p>View the school's subjects and their assigned classes and teachers.</p>
        </div>
        <button className="admin-subjects__add-button" type="button" onClick={() => setActiveModal(true)}>
          Add Subject
        </button>
      </header>

      <section className="admin-subjects__summary" aria-label="Subject summary">
        {summary.map(({ label, value }) => (
          <article className="admin-subjects__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-subjects__section" aria-labelledby="admin-subject-list-title">
        <div className="admin-subjects__toolbar">
          <div>
            <h2 id="admin-subject-list-title">School Subjects</h2>
            <p>Showing {filteredSubjects.length} of {subjects.length}</p>
          </div>
          <div className="admin-subjects__filters">
            <label>
              <span className="admin-subjects__visually-hidden">Search subjects, teachers, or classes</span>
              <input
                type="search"
                placeholder="Search subjects..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="admin-subjects__visually-hidden">Filter subjects by teacher</span>
              <select value={teacherFilter} onChange={(event) => setTeacherFilter(event.target.value)}>
                <option value="All teachers">All teachers</option>
                {teachers.map((teacher) => <option key={teacher} value={teacher}>{teacher}</option>)}
              </select>
            </label>
            <label>
              <span className="admin-subjects__visually-hidden">Filter subjects by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {classRecords.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span className="admin-subjects__visually-hidden">Filter subjects by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </label>
          </div>
        </div>

        <div className="admin-subjects__table-wrap">
          <table className="admin-subjects__table">
            <thead>
              <tr>
                <th scope="col">Subject</th>
                <th scope="col">Teacher(s)</th>
                <th scope="col">Class(es)</th>
                <th scope="col">Students</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredSubjects.length > 0 ? filteredSubjects.map((subject) => (
                <tr key={subject.id}>
                  <th scope="row" data-label="Subject">{subject.name}</th>
                  <td data-label="Teacher(s)">{subject.teachers.join(", ")}</td>
                  <td data-label="Class(es)">
                    {subject.classes.length > 0 ? subject.classes.map((classItem) => (
                      <Link className="admin-subjects__class-link" key={classItem.id} to={`/admin/classes/${classItem.id}`}>
                        {classItem.name}
                      </Link>
                    )) : "Not assigned"}
                  </td>
                  <td data-label="Students">{subject.students.length}</td>
                  <td data-label="Status">
                    <span className={`admin-subjects__status admin-subjects__status--${subject.status.toLowerCase()}`}>
                      {subject.status}
                    </span>
                  </td>
                  <td data-label="Action">
                    <Link className="admin-subjects__view-link" to={`/admin/subjects/${subject.id}`}>
                      View Subject
                    </Link>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="admin-subjects__empty" colSpan="6">No subjects match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <MockActionModal
        isOpen={activeModal}
        title="Add Subject"
        description="Create a new academic subject for the school catalog."
        submitLabel="Save Subject"
        fields={modalFields}
        onClose={() => setActiveModal(false)}
        onSubmit={() => setActiveModal(false)}
      />
    </div>
  )
}

export default AdminSubjects
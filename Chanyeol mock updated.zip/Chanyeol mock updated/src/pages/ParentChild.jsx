import { Link } from "react-router-dom"
import {
  studentAttendanceRecords,
  studentGrades,
  studentLearningActivities,
  studentLearningProgress,
  studentQuizzes,
  studentSubjects,
  teacherClassDetails,
  teacherDashboardData,
} from "../../Data/mockData"
import "./ParentChild.css"

const STUDENT_ID = "STU-1042"
const rosterEntry = Object.entries(teacherClassDetails)
  .flatMap(([classId, classDetails]) => classDetails.students.map((student) => ({ ...student, classId })))
  .find((student) => student.id === STUDENT_ID)
const classItem = teacherDashboardData.classes.find((item) => item.id === rosterEntry?.classId)
const attendanceCounts = {
  Present: studentAttendanceRecords.filter((record) => record.status === "Present").length,
  Late: studentAttendanceRecords.filter((record) => record.status === "Late").length,
  Absent: studentAttendanceRecords.filter((record) => record.status === "Absent").length,
}
const attendanceRate = studentAttendanceRecords.length > 0
  ? ((attendanceCounts.Present + attendanceCounts.Late) / studentAttendanceRecords.length) * 100
  : 0
const overallGrade = studentGrades.length > 0
  ? studentGrades.reduce((total, grade) => total + grade.percentage, 0) / studentGrades.length
  : 0
const completedLessons = studentLearningProgress.reduce((total, item) => total + item.completedLessons, 0)
const totalLessons = studentLearningProgress.reduce((total, item) => total + item.totalLessons, 0)
const overallProgress = totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0
const progressBySubject = Object.fromEntries(studentLearningProgress.map((item) => [item.subjectId, item]))
const gradesBySubject = Object.fromEntries(studentGrades.map((item) => [item.subjectId, item]))
const quizById = Object.fromEntries(studentQuizzes.map((quiz) => [quiz.id, quiz]))

function formatDate(date) {
  return new Date(`${date}T12:00:00Z`).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  })
}

function ParentChild({ assignments, quizHistory }) {
  const childAssignments = [...assignments].sort((left, right) => Date.parse(left.dueDate) - Date.parse(right.dueDate))
  const quizAttempts = Object.values(quizHistory ?? {})
    .flatMap((attempts) => attempts)
    .map((attempt) => ({ ...attempt, quiz: quizById[attempt.quizId] }))
    .filter((attempt) => attempt.quiz && Number.isFinite(attempt.percentage))
    .sort((left, right) => Date.parse(right.completedAt) - Date.parse(left.completedAt))
  const quizActivity = [
    ...quizAttempts.map((attempt) => ({
      id: attempt.id,
      title: attempt.quiz.title,
      subject: attempt.quiz.subject,
      date: attempt.completedAt?.slice(0, 10),
      detail: `${attempt.score} / ${attempt.totalQuestions} · ${attempt.percentage}% · Attempt ${attempt.attemptNumber}`,
    })),
    ...studentLearningActivities
      .filter((activity) => activity.type === "Quiz")
      .map((activity) => ({
        id: activity.id,
        title: activity.title,
        subject: activity.subject,
        date: activity.date,
        detail: "Completed",
      })),
  ].sort((left, right) => right.date.localeCompare(left.date)).slice(0, 4)
  const summary = [
    { label: "Overall Grade", value: `${overallGrade.toFixed(1)}%` },
    { label: "Attendance Rate", value: `${attendanceRate.toFixed(1)}%` },
    { label: "Overall Progress", value: `${overallProgress.toFixed(1)}%` },
    { label: "Subjects", value: studentSubjects.length },
  ]

  return (
    <div className="parent-child">
      <header className="parent-child__heading">
        <div>
          <h1>My Child</h1>
          <p>Review {rosterEntry?.name ?? "your child's"} current academic information.</p>
        </div>
        <Link className="parent-child__back-link" to="/parent">Back to Parent Dashboard</Link>
      </header>

      <section className="parent-child__profile" aria-label="Child profile">
        <div className="parent-child__profile-heading">
          <div>
            <span>Student</span>
            <h2>{rosterEntry?.name ?? "Student record unavailable"}</h2>
          </div>
          <span className="parent-child__student-id">{rosterEntry?.id ?? "No student ID"}</span>
        </div>
        <dl className="parent-child__profile-details">
          <div><dt>Class</dt><dd>{classItem?.name ?? "Not assigned"}</dd></div>
          <div><dt>Overall Grade</dt><dd>{overallGrade.toFixed(1)}%</dd></div>
          <div><dt>Attendance Rate</dt><dd>{attendanceRate.toFixed(1)}%</dd></div>
          <div><dt>Overall Progress</dt><dd>{overallProgress.toFixed(1)}%</dd></div>
        </dl>
      </section>

      <section className="parent-child__summary" aria-label="Academic overview">
        {summary.map(({ label, value }) => (
          <article className="parent-child__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="parent-child__section" aria-labelledby="parent-child-subjects-title">
        <div className="parent-child__section-heading">
          <h2 id="parent-child-subjects-title">Subjects</h2>
        </div>
        <div className="parent-child__subject-grid">
          {studentSubjects.map((subject) => {
            const grade = gradesBySubject[subject.id]
            const progress = progressBySubject[subject.id]

            return (
              <article className="parent-child__subject-card" key={subject.id}>
                <div className="parent-child__subject-heading">
                  <h3>{subject.name}</h3>
                  <strong>{grade ? `${grade.percentage}%` : "—"}</strong>
                </div>
                <span>{subject.teacher}</span>
                <div className="parent-child__subject-meta">
                  <span>Progress <strong>{progress ? `${progress.progress}%` : "—"}</strong></span>
                  <span>{subject.schedule}</span>
                </div>
              </article>
            )
          })}
        </div>
      </section>

      <div className="parent-child__columns">
        <section className="parent-child__section" aria-labelledby="parent-child-academics-title">
          <div className="parent-child__section-heading">
            <h2 id="parent-child-academics-title">Academic Overview</h2>
          </div>
          <div className="parent-child__overview-card">
            <article><span>Overall Average</span><strong>{overallGrade.toFixed(1)}%</strong></article>
            <article>
              <span>Highest Subject Grade</span>
              <strong>{studentGrades.length ? `${[...studentGrades].sort((left, right) => right.percentage - left.percentage)[0].subject} · ${Math.max(...studentGrades.map((grade) => grade.percentage))}%` : "—"}</strong>
            </article>
            <article>
              <span>Lowest Subject Grade</span>
              <strong>{studentGrades.length ? `${[...studentGrades].sort((left, right) => left.percentage - right.percentage)[0].subject} · ${Math.min(...studentGrades.map((grade) => grade.percentage))}%` : "—"}</strong>
            </article>
            <article><span>Overall Progress</span><strong>{overallProgress.toFixed(1)}%</strong></article>
            <article><span>Attendance Rate</span><strong>{attendanceRate.toFixed(1)}%</strong></article>
          </div>
        </section>

        <section className="parent-child__section" aria-labelledby="parent-child-attendance-title">
          <div className="parent-child__section-heading">
            <h2 id="parent-child-attendance-title">Attendance Overview</h2>
          </div>
          <div className="parent-child__overview-card parent-child__attendance-card">
            {Object.entries(attendanceCounts).map(([status, count]) => (
              <article key={status}>
                <span>{status}</span>
                <strong>{count}</strong>
              </article>
            ))}
            <article><span>Attendance Rate</span><strong>{attendanceRate.toFixed(1)}%</strong></article>
          </div>
        </section>
      </div>

      <div className="parent-child__columns">
        <section className="parent-child__section" aria-labelledby="parent-child-assignments-title">
          <div className="parent-child__section-heading">
            <h2 id="parent-child-assignments-title">Recent Assignments</h2>
          </div>
          <div className="parent-child__records">
            {childAssignments.slice(0, 4).map((assignment) => (
              <article className="parent-child__record" key={assignment.id}>
                <div>
                  <h3>{assignment.title}</h3>
                  <span>{assignment.subject}</span>
                </div>
                <div className="parent-child__record-meta">
                  <time>Due {assignment.dueDate}</time>
                  <span>{assignment.status}</span>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="parent-child__section" aria-labelledby="parent-child-quizzes-title">
          <div className="parent-child__section-heading">
            <h2 id="parent-child-quizzes-title">Recent Quiz Activity & Results</h2>
          </div>
          <div className="parent-child__records">
            {quizActivity.length > 0 ? quizActivity.map((activity) => (
              <article className="parent-child__record" key={activity.id}>
                <div>
                  <h3>{activity.title}</h3>
                  <span>{activity.subject}</span>
                </div>
                <div className="parent-child__record-meta">
                  {activity.date && <time>{formatDate(activity.date)}</time>}
                  <span>{activity.detail}</span>
                </div>
              </article>
            )) : <p className="parent-child__empty">No recent quiz activity.</p>}
          </div>
        </section>
      </div>

      <section className="parent-child__section" aria-labelledby="parent-child-navigation-title">
        <div className="parent-child__section-heading">
          <h2 id="parent-child-navigation-title">Quick Navigation</h2>
        </div>
        <div className="parent-child__actions">
          {[
            { label: "View Grades", to: "/parent/grades" },
            { label: "View Attendance", to: "/parent/attendance" },
            { label: "View Assignments", to: "/parent/assignments" },
            { label: "View Quiz Results", to: "/parent/quiz-results" },
            { label: "View Progress", to: "/parent/progress" },
            { label: "View Announcements", to: "/parent/announcements" },
          ].map(({ label, to }) => (
            <Link className="parent-child__action" to={to} key={to}>
              {label}
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}

export default ParentChild
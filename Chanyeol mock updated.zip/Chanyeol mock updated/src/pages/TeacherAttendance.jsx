import { useState } from "react"
import {
  teacherAttendanceRecords,
  teacherClassDetails,
  teacherDashboardData,
} from "../../Data/mockData"
import "./TeacherAttendance.css"

const classById = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
)
const studentByClassAndId = Object.fromEntries(
  Object.entries(teacherClassDetails).flatMap(([classId, details]) =>
    details.students.map((student) => [`${classId}:${student.id}`, student]),
  ),
)
const attendanceRows = teacherAttendanceRecords.flatMap((record) => {
  const classItem = classById[record.classId]
  const student = studentByClassAndId[`${record.classId}:${record.studentId}`]

  return classItem && student ? [{ ...record, className: classItem.name, subject: classItem.subject, studentName: student.name }] : []
})
const latestAttendanceDate = attendanceRows.reduce(
  (latest, record) => record.date > latest ? record.date : latest,
  "",
)

function TeacherAttendance() {
  const [classFilter, setClassFilter] = useState("All classes")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [dateFilter, setDateFilter] = useState(latestAttendanceDate)
  const filteredRows = attendanceRows.filter((record) => (
    (classFilter === "All classes" || record.classId === classFilter) &&
    (subjectFilter === "All subjects" || record.subject === subjectFilter) &&
    (!dateFilter || record.date === dateFilter)
  ))
  const presentCount = filteredRows.filter((record) => record.status === "Present").length
  const lateCount = filteredRows.filter((record) => record.status === "Late").length
  const absentCount = filteredRows.filter((record) => record.status === "Absent").length
  const attendanceRate = filteredRows.length > 0
    ? ((presentCount + lateCount) / filteredRows.length) * 100
    : 0
  const totalStudents = new Set(filteredRows.map((record) => record.studentId)).size
  const summary = [
    { label: "Total Students", value: totalStudents },
    { label: "Present", value: presentCount },
    { label: "Late", value: lateCount },
    { label: "Absent", value: absentCount },
    { label: "Attendance Rate", value: `${attendanceRate.toFixed(1)}%` },
  ]
  const subjects = [...new Set(teacherDashboardData.classes.map((classItem) => classItem.subject))]

  return (
    <div className="teacher-attendance">
      <header className="teacher-attendance__heading">
        <h1>Attendance</h1>
        <p>Review daily attendance across your classes.</p>
      </header>

      <section className="teacher-attendance__summary" aria-label="Attendance summary">
        {summary.map(({ label, value }) => (
          <article className="teacher-attendance__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="teacher-attendance__section" aria-labelledby="teacher-attendance-title">
        <div className="teacher-attendance__toolbar">
          <div>
            <h2 id="teacher-attendance-title">Daily Attendance</h2>
            <p>{filteredRows.length} attendance records</p>
          </div>
          <div className="teacher-attendance__filters">
            <label>
              <span className="teacher-attendance__visually-hidden">Filter by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {teacherDashboardData.classes.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span className="teacher-attendance__visually-hidden">Filter by subject</span>
              <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
                <option value="All subjects">All subjects</option>
                {subjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
              </select>
            </label>
            <label>
              <span className="teacher-attendance__visually-hidden">Filter by date</span>
              <input
                type="date"
                value={dateFilter}
                onChange={(event) => setDateFilter(event.target.value)}
              />
            </label>
          </div>
        </div>

        <div className="teacher-attendance__table-wrap">
          <table className="teacher-attendance__table">
            <thead>
              <tr>
                <th scope="col">Student</th>
                <th scope="col">Student ID</th>
                <th scope="col">Class</th>
                <th scope="col">Subject</th>
                <th scope="col">Attendance Status</th>
                <th scope="col">Date</th>
              </tr>
            </thead>
            <tbody>
              {filteredRows.length > 0 ? filteredRows.map((record) => (
                <tr key={`${record.studentId}-${record.classId}-${record.date}`}>
                  <th scope="row" data-label="Student">{record.studentName}</th>
                  <td data-label="Student ID">{record.studentId}</td>
                  <td data-label="Class">{record.className}</td>
                  <td data-label="Subject">{record.subject}</td>
                  <td data-label="Attendance Status">
                    <span className={`teacher-attendance__status teacher-attendance__status--${record.status.toLowerCase()}`}>
                      {record.status}
                    </span>
                  </td>
                  <td data-label="Date">{record.date}</td>
                </tr>
              )) : (
                <tr>
                  <td className="teacher-attendance__empty" colSpan="6">No attendance records match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

export default TeacherAttendance
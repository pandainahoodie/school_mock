import { Link } from "react-router-dom"
import { studentQuizzes } from "../../Data/mockData"
import "./ParentQuizResults.css"

function formatDate(date) {
  if (!date) {
    return "—"
  }

  return new Date(date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  })
}

function ParentQuizResults({ quizHistory }) {
  const quizzesWithAttempts = studentQuizzes.map((quiz) => ({
    quiz,
    attempts: [...(quizHistory?.[quiz.id] ?? [])]
      .sort((left, right) => Date.parse(right.completedAt) - Date.parse(left.completedAt)),
  }))
  const attempts = quizzesWithAttempts.flatMap(({ quiz, attempts: quizAttempts }) => (
    quizAttempts.map((attempt) => ({ ...attempt, quiz }))
  ))
  const averageScore = attempts.length > 0
    ? attempts.reduce((total, attempt) => total + attempt.percentage, 0) / attempts.length
    : 0
  const rows = quizzesWithAttempts.flatMap(({ quiz, attempts: quizAttempts }) => (
    quizAttempts.length > 0
      ? quizAttempts.map((attempt) => ({ ...attempt, quiz, resultStatus: "Completed" }))
      : [{ id: `no-result-${quiz.id}`, quiz, resultStatus: "No attempts" }]
  )).sort((left, right) => {
    if (!left.completedAt) return 1
    if (!right.completedAt) return -1
    return Date.parse(right.completedAt) - Date.parse(left.completedAt)
  })
  const summary = [
    { label: "Completed Attempts", value: attempts.length },
    { label: "Quizzes With Results", value: new Set(attempts.map((attempt) => attempt.quizId)).size },
    { label: "Average Quiz Score", value: attempts.length ? `${averageScore.toFixed(1)}%` : "—" },
  ]

  return (
    <div className="parent-academic parent-quiz-results">
      <header className="parent-academic__heading">
        <div>
          <h1>Quiz Results</h1>
          <p>Review Chanyeol's completed quiz results and available attempt history.</p>
        </div>
        <Link className="parent-academic__back-link" to="/parent">Parent Dashboard</Link>
      </header>

      <section className="parent-academic__summary" aria-label="Quiz summary">
        {summary.map(({ label, value }) => (
          <article className="parent-academic__summary-card" key={label}>
            <span>{label}</span><strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="parent-academic__section" aria-labelledby="parent-quiz-attempts-title">
        <div className="parent-academic__section-heading">
          <h2 id="parent-quiz-attempts-title">Quiz Attempts</h2>
          <span>Read-only</span>
        </div>
        <div className="parent-academic__table-wrap">
          <table className="parent-academic__table">
            <thead><tr><th>Quiz</th><th>Subject</th><th>Score</th><th>Percentage</th><th>Date</th><th>Attempt</th><th>Result</th></tr></thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <th scope="row" data-label="Quiz">{row.quiz.title}</th>
                  <td data-label="Subject">{row.quiz.subject}</td>
                  <td data-label="Score">{row.completedAt ? `${row.score} / ${row.totalQuestions}` : "—"}</td>
                  <td data-label="Percentage">{row.completedAt ? `${row.percentage}%` : "—"}</td>
                  <td data-label="Date">{row.completedAt ? formatDate(row.completedAt) : "—"}</td>
                  <td data-label="Attempt">{row.attemptNumber ?? "—"}</td>
                  <td data-label="Result">
                    <span className={`parent-academic__status parent-academic__status--${row.completedAt ? "completed" : "not-started"}`}>
                      {row.resultStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

export default ParentQuizResults
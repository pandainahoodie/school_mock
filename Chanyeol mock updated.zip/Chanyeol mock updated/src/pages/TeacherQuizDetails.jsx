import { useNavigate, useParams } from "react-router-dom"
import { teacherDashboardData, teacherQuizzes } from "../../Data/mockData"
import "./TeacherQuizDetails.css"

function TeacherQuizDetails() {
  const { quizId } = useParams()
  const navigate = useNavigate()
  const quiz = teacherQuizzes.find((item) => item.id === quizId)
  const classItem = quiz
    ? teacherDashboardData.classes.find((item) => item.id === quiz.classId)
    : null

  if (!quiz || !classItem) {
    return (
      <div className="teacher-quiz-details">
        <section className="teacher-quiz-details__not-found">
          <h1>Quiz not found</h1>
          <button type="button" onClick={() => navigate("/teacher/quizzes")}>
            Back to Quizzes
          </button>
        </section>
      </div>
    )
  }

  const questionCount = quiz.questions?.length ?? quiz.questionCount ?? 0
  const canViewResults = quiz.attemptsUsed > 0 && quiz.status === "Published"

  return (
    <div className="teacher-quiz-details">
      <button
        className="teacher-quiz-details__back-button"
        type="button"
        onClick={() => navigate("/teacher/quizzes")}
      >
        Back to Quizzes
      </button>

      <header className="teacher-quiz-details__heading">
        <div>
          <p className="teacher-quiz-details__eyebrow">{classItem.name} · {quiz.subject}</p>
          <h1>{quiz.title}</h1>
        </div>
        <span className={`teacher-quiz-details__status teacher-quiz-details__status--${quiz.status.toLowerCase()}`}>
          {quiz.status}
        </span>
      </header>

      <section className="teacher-quiz-details__overview" aria-label="Quiz overview">
        <p className="teacher-quiz-details__description">{quiz.description}</p>
        <dl>
          <div><dt>Class</dt><dd>{classItem.name}</dd></div>
          <div><dt>Subject</dt><dd>{quiz.subject}</dd></div>
          <div><dt>Questions</dt><dd>{questionCount}</dd></div>
          <div><dt>Time Limit</dt><dd>{quiz.timeLimit} minutes</dd></div>
          <div><dt>Maximum Attempts</dt><dd>{quiz.maxAttempts}</dd></div>
          <div><dt>Status</dt><dd>{quiz.status}</dd></div>
        </dl>
      </section>

      {quiz.questions?.length > 0 && (
        <section className="teacher-quiz-details__section" aria-labelledby="teacher-quiz-questions-title">
          <div className="teacher-quiz-details__section-heading">
            <h2 id="teacher-quiz-questions-title">Questions</h2>
            <span>{quiz.questions.length} questions</span>
          </div>
          <ol className="teacher-quiz-details__questions">
            {quiz.questions.map((question, index) => (
              <li className="teacher-quiz-details__question" key={question.id}>
                <div className="teacher-quiz-details__question-heading">
                  <strong>Question {index + 1}</strong>
                  <span>{question.choices.length} choices · {question.points ?? 1} {question.points === 1 || question.points === undefined ? "point" : "points"}</span>
                </div>
                <p>{question.question}</p>
              </li>
            ))}
          </ol>
        </section>
      )}

      <div className="teacher-quiz-details__results-action">
        {canViewResults ? (
          <button type="button" disabled title="Quiz results are not available yet">
            View Results
          </button>
        ) : (
          <span>{quiz.status === "Draft" ? "Results will be available after publishing." : "No completed attempts yet."}</span>
        )}
      </div>
    </div>
  )
}

export default TeacherQuizDetails

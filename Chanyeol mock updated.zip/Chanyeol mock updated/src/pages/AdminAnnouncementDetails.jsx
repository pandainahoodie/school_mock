import { Link, useNavigate, useParams } from "react-router-dom"
import { adminTeacherRecords, teacherDashboardData } from "../../Data/mockData"
import "./AdminAnnouncements.css"

function AdminAnnouncementDetails() {
  const { announcementId } = useParams()
  const navigate = useNavigate()
  const announcement = teacherDashboardData.recentAnnouncements
    .find((item) => item.id === announcementId)
  const classItem = teacherDashboardData.classes
    .find((item) => item.name === announcement?.targetClass)
  const author = teacherDashboardData.teacherName
  const authorRecord = adminTeacherRecords.find((teacher) => teacher.name === author)

  if (!announcement) {
    return (
      <div className="admin-announcement-details">
        <section className="admin-announcement-details__not-found">
          <h1>Announcement not found</h1>
          <button type="button" onClick={() => navigate("/admin/announcements")}>
            Back to Announcements
          </button>
        </section>
      </div>
    )
  }

  return (
    <div className="admin-announcement-details">
      <button
        className="admin-announcement-details__back-button"
        type="button"
        onClick={() => navigate("/admin/announcements")}
      >
        Back to Announcements
      </button>

      <header className="admin-announcement-details__heading">
        <div>
          <p className="admin-announcement-details__eyebrow">
            {classItem?.name ?? announcement.targetClass}
            {classItem ? ` · ${classItem.subject}` : ""}
          </p>
          <h1>{announcement.title}</h1>
        </div>
        <span className={`admin-announcements__status admin-announcements__status--${announcement.status.toLowerCase()}`}>
          {announcement.status}
        </span>
      </header>

      <dl className="admin-announcement-details__metadata">
        <div>
          <dt>Author</dt>
          <dd>{authorRecord ? <Link to={`/admin/teachers/${authorRecord.teacherId}`}>{author}</Link> : author}</dd>
        </div>
        <div>
          <dt>Date</dt>
          <dd><time>{announcement.date}</time></dd>
        </div>
        <div>
          <dt>Target Class / Audience</dt>
          <dd>{classItem ? <Link to={`/admin/classes/${classItem.id}`}>{announcement.targetClass}</Link> : announcement.targetClass}</dd>
        </div>
      </dl>

      <article className="admin-announcement-details__content">
        <h2>Announcement</h2>
        <p>{announcement.content}</p>
      </article>
    </div>
  )
}

export default AdminAnnouncementDetails
import { Link, useNavigate, useParams } from "react-router-dom"
import {
  adminTeacherRecords,
  teacherAssignmentDetails,
  teacherAttendanceRecords,
  teacherClassDetails,
  teacherDashboardData,
  teacherScheduleRecords,
} from "../../Data/mockData"
import "./AdminTeachers.css"

const classById = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
)
const assignmentById = Object.fromEntries(
  teacherDashboardData.pendingGrading.map((assignment) => [assignment.id, assignment]),
)

function formatTime(time) {
  const [hours, minutes] = time.split(":").map(Number)

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "UTC",
  }).format(new Date(Date.UTC(2026, 0, 1, hours, minutes)))
}

function AdminTeacherDetails() {
  const { teacherId } = useParams()
  const navigate = useNavigate()
  const teacher = adminTeacherRecords.find((item) => item.teacherId === teacherId)

  if (!teacher) {
    return (
      <div className="admin-teacher-details">
        <section className="admin-teacher-details__not-found">
          <h1>Teacher not found</h1>
          <button type="button" onClick={() => navigate("/admin/teachers")}>
            Back to Teachers
          </button>
        </section>
      </div>
    )
  }

  const assignedClasses = teacher.classIds.map((classId) => classById[classId]).filter(Boolean)
  const studentCount = assignedClasses.reduce((total, classItem) => total + classItem.students, 0)
  const upcomingClasses = teacherScheduleRecords
    .filter((record) => teacher.classIds.includes(record.classId) && record.status === "Upcoming")
    .map((record) => ({ ...record, classItem: classById[record.classId] }))
    .filter((record) => record.classItem)
    .sort((left, right) => left.date.localeCompare(right.date) || left.startTime.localeCompare(right.startTime))
  const recentActivity = assignedClasses.flatMap((classItem) => {
    const classDetails = teacherClassDetails[classItem.id]
    const quizActivity = (classDetails?.quizActivity ?? []).map((activity) => ({
      id: activity.id,
      type: "Quiz activity",
      description: activity.description,
      date: activity.timeAgo,
    }))
    const assignments = (classDetails?.assignments ?? []).map((assignment) => ({
      id: assignment.id,
      type: "Assignment",
      description: `${assignment.name} · ${assignment.status}`,
      date: assignment.dueDate,
    }))
    const announcements = teacherDashboardData.recentAnnouncements
      .filter((announcement) => announcement.targetClass === classItem.name)
      .map((announcement) => ({
        id: announcement.id,
        type: "Announcement",
        description: announcement.title,
        date: announcement.date,
      }))

    return [...quizActivity, ...assignments, ...announcements]
  }).slice(0, 6)
  const latestAttendance = teacherAttendanceRecords
    .filter((record) => teacher.classIds.includes(record.classId))
    .sort((left, right) => right.date.localeCompare(left.date))
  const recentGrading = Object.entries(teacherAssignmentDetails)
    .filter(([assignmentId]) => teacher.classIds.some((classId) => assignmentById[assignmentId]?.className === classById[classId]?.name))
    .reduce((total, [, details]) => total + (details.gradedSubmissions ?? 0), 0)

  return (
    <div className="admin-teacher-details">
      <button
        className="admin-teacher-details__back-button"
        type="button"
        onClick={() => navigate("/admin/teachers")}
      >
        Back to Teachers
      </button>

      <header className="admin-teacher-details__heading">
        <div>
          <p className="admin-teacher-details__eyebrow">Teaching Staff</p>
          <h1>{teacher.name}</h1>
          <p>{teacher.teacherId}</p>
        </div>
        <span className={`admin-teachers__status admin-teachers__status--${teacher.status.toLowerCase()}`}>
          {teacher.status}
        </span>
      </header>

      <section className="admin-teacher-details__summary" aria-label="Teacher overview">
        <article>
          <span>Assigned Subjects</span>
          <strong>{teacher.subjects.length}</strong>
        </article>
        <article>
          <span>Assigned Classes</span>
          <strong>{assignedClasses.length}</strong>
        </article>
        <article>
          <span>Students</span>
          <strong>{studentCount}</strong>
        </article>
        <article>
          <span>Upcoming Classes</span>
          <strong>{upcomingClasses.length}</strong>
        </article>
      </section>

      <section className="admin-teacher-details__section" aria-labelledby="teacher-subjects-title">
        <div className="admin-teacher-details__section-heading">
          <h2 id="teacher-subjects-title">Assigned Subjects</h2>
        </div>
        <ul className="admin-teacher-details__subject-list">
          {teacher.subjects.map((subject) => <li key={subject}>{subject}</li>)}
        </ul>
      </section>

      <section className="admin-teacher-details__section" aria-labelledby="teacher-classes-title">
        <div className="admin-teacher-details__section-heading">
          <h2 id="teacher-classes-title">Assigned Classes</h2>
        </div>
        {assignedClasses.length > 0 ? (
          <div className="admin-teacher-details__class-grid">
            {assignedClasses.map((classItem) => (
              <article className="admin-teacher-details__class-card" key={classItem.id}>
                <div>
                  <h3>{classItem.name}</h3>
                  <span>{classItem.subject} · {classItem.students} students</span>
                </div>
                <div className="admin-teacher-details__class-links">
                  <Link to={`/teacher/classes/${classItem.id}`}>Class Details</Link>
                  <Link to={`/teacher/classes/${classItem.id}/students`}>Student Roster</Link>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <p className="admin-teacher-details__empty">No class records are assigned to this teacher yet.</p>
        )}
      </section>

      <section className="admin-teacher-details__section" aria-labelledby="teacher-schedule-title">
        <div className="admin-teacher-details__section-heading">
          <h2 id="teacher-schedule-title">Upcoming Schedule</h2>
          <Link to="/teacher/schedule">Open Schedule</Link>
        </div>
        {upcomingClasses.length > 0 ? (
          <div className="admin-teacher-details__records">
            {upcomingClasses.slice(0, 4).map((record) => (
              <article className="admin-teacher-details__record" key={record.id}>
                <time>{record.date} · {formatTime(record.startTime)}</time>
                <span>{record.classItem.subject} · {record.classItem.name}</span>
                <span>{record.classItem.room}</span>
              </article>
            ))}
          </div>
        ) : (
          <p className="admin-teacher-details__empty">No upcoming classes are scheduled.</p>
        )}
      </section>

      <div className="admin-teacher-details__lower-grid">
        <section className="admin-teacher-details__section" aria-labelledby="teacher-activity-title">
          <div className="admin-teacher-details__section-heading">
            <h2 id="teacher-activity-title">Recent Teaching Activity</h2>
          </div>
          {recentActivity.length > 0 ? (
            <div className="admin-teacher-details__records">
              {recentActivity.map((activity) => (
                <article className="admin-teacher-details__record" key={activity.id}>
                  <div>
                    <span className="admin-teacher-details__record-type">{activity.type}</span>
                    <p>{activity.description}</p>
                  </div>
                  <time>{activity.date}</time>
                </article>
              ))}
            </div>
          ) : (
            <p className="admin-teacher-details__empty">No recent activity is available.</p>
          )}
        </section>

        <section className="admin-teacher-details__section" aria-labelledby="teacher-attendance-title">
          <div className="admin-teacher-details__section-heading">
            <h2 id="teacher-attendance-title">Recent Class Attendance</h2>
          </div>
          <div className="admin-teacher-details__records">
            {latestAttendance.slice(0, 5).map((record, index) => (
              <article className="admin-teacher-details__record" key={`${record.studentId}-${record.classId}-${record.date}-${index}`}>
                <span>{classById[record.classId]?.name ?? "Class"} · {record.status}</span>
                <time>{record.date}</time>
              </article>
            ))}
          </div>
          <span className="admin-teacher-details__supporting-note">{recentGrading} graded submissions in assigned classes</span>
        </section>
      </div>
    </div>
  )
}

export default AdminTeacherDetails
import {
  teacherClassDetails,
  teacherDashboardData,
} from "../../Data/mockData"

export const ADMIN_STUDENTS_STORAGE_KEY = "parkChanyeolSchool_students"
export const adminStudentClasses = teacherDashboardData.classes

const classById = Object.fromEntries(
  adminStudentClasses.map((classItem) => [classItem.id, classItem]),
)

export const initialAdminStudents = Object.entries(teacherClassDetails).flatMap(([classId, details]) => {
  const classItem = classById[classId]

  return classItem ? details.students.map((student) => ({
    ...student,
    id: student.id,
    studentId: student.id,
    classId,
    className: classItem.name,
    legacyIds: [],
  })) : []
})

export function readAdminStudents() {
  try {
    const storedStudents = window.localStorage.getItem(ADMIN_STUDENTS_STORAGE_KEY)

    if (storedStudents === null) {
      return initialAdminStudents
    }

    const parsedStudents = JSON.parse(storedStudents)
    if (!Array.isArray(parsedStudents)) {
      return initialAdminStudents
    }

    return parsedStudents.flatMap((student) => {
      if (!student || typeof student !== "object") {
        return []
      }

      const studentId = typeof student.studentId === "string"
        ? student.studentId.trim()
        : typeof student.id === "string" ? student.id.trim() : ""
      const name = typeof student.name === "string" ? student.name.trim() : ""

      if (!studentId || !name) {
        return []
      }

      const classItem = classById[student.classId] ?? adminStudentClasses.find(
        (item) => item.name === student.className,
      )

      return [{
        ...student,
        id: studentId,
        studentId,
        name,
        classId: classItem?.id ?? "",
        className: classItem?.name ?? student.className ?? "",
        legacyIds: Array.isArray(student.legacyIds)
          ? student.legacyIds.filter((legacyId) => typeof legacyId === "string")
          : [],
      }]
    })
  } catch {
    return initialAdminStudents
  }
}

export function saveAdminStudents(students) {
  try {
    window.localStorage.setItem(ADMIN_STUDENTS_STORAGE_KEY, JSON.stringify(students))
    return true
  } catch {
    return false
  }
}
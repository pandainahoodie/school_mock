import { Link, useNavigate, useParams } from "react-router-dom"
import { teacherDashboardData, teacherLearningMaterials } from "../../Data/mockData"
import "./TeacherMaterials.css"

function TeacherMaterialDetails() {
  const { materialId } = useParams()
  const navigate = useNavigate()
  const material = teacherLearningMaterials.find((item) => item.id === materialId)
  const classItem = teacherDashboardData.classes
    .find((item) => item.id === material?.classId)

  if (!material || !classItem) {
    return (
      <div className="teacher-material-details">
        <section className="teacher-material-details__not-found">
          <h1>Material not found</h1>
          <button type="button" onClick={() => navigate("/teacher/materials")}>
            Back to Learning Materials
          </button>
        </section>
      </div>
    )
  }

  return (
    <div className="teacher-material-details">
      <button
        className="teacher-material-details__back-button"
        type="button"
        onClick={() => navigate("/teacher/materials")}
      >
        Back to Learning Materials
      </button>

      <header className="teacher-material-details__heading">
        <div>
          <p className="teacher-material-details__eyebrow">{classItem.subject} · {material.type}</p>
          <h1>{material.title}</h1>
        </div>
        <span className={`teacher-materials__status teacher-materials__status--${material.status.toLowerCase()}`}>
          {material.status}
        </span>
      </header>

      <dl className="teacher-material-details__metadata">
        <div>
          <dt>Subject</dt>
          <dd>{classItem.subject}</dd>
        </div>
        <div>
          <dt>Class</dt>
          <dd><Link to={`/teacher/classes/${classItem.id}`}>{classItem.name}</Link></dd>
        </div>
        <div>
          <dt>Type</dt>
          <dd>{material.type}</dd>
        </div>
        <div>
          <dt>Date</dt>
          <dd><time>{material.date}</time></dd>
        </div>
      </dl>

      <article className="teacher-material-details__content">
        <h2>Description</h2>
        <p>{material.description}</p>
      </article>
    </div>
  )
}

export default TeacherMaterialDetails
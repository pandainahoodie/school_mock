import { Link } from "react-router-dom"
import {
  studentLearningActivities,
  studentLearningAchievements,
  studentLearningProgress,
  studentProgressStats,
} from "../../Data/mockData"
import "./ParentProgress.css"

function formatDate(date) {
  return new Date(`${date}T12:00:00Z`).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  })
}

function ParentProgress() {
  const overallProgress = studentLearningProgress.length > 0
    ? studentLearningProgress.reduce((total, subject) => total + subject.progress, 0) / studentLearningProgress.length
    : 0
  const activities = [...studentLearningActivities].sort((left, right) => right.date.localeCompare(left.date))
  const summary = [
    { label: "Overall Progress", value: `${overallProgress.toFixed(0)}%` },
    { label: "Assignments Completed", value: `${studentProgressStats.assignmentsCompleted} / ${studentProgressStats.totalAssignments}` },
    { label: "Quizzes Completed", value: `${studentProgressStats.quizzesCompleted} / ${studentProgressStats.totalQuizzes}` },
    { label: "Quiz Average", value: `${studentProgressStats.quizAverage}%` },
  ]

  return (
    <div className="parent-academic parent-progress">
      <header className="parent-academic__heading">
        <div>
          <h1>Learning Progress</h1>
          <p>Follow Chanyeol's lesson completion and recent learning activity.</p>
        </div>
        <Link className="parent-academic__back-link" to="/parent">Parent Dashboard</Link>
      </header>

      <section className="parent-academic__summary" aria-label="Learning progress summary">
        {summary.map(({ label, value }) => (
          <article className="parent-academic__summary-card" key={label}>
            <span>{label}</span><strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="parent-academic__section" aria-labelledby="parent-subject-progress-title">
        <div className="parent-academic__section-heading">
          <h2 id="parent-subject-progress-title">Subject Progress</h2>
        </div>
        <div className="parent-academic__card-grid">
          {studentLearningProgress.map((subject) => (
            <article className="parent-academic__card parent-progress__subject-card" key={subject.subjectId}>
              <div className="parent-academic__card-heading">
                <h3>{subject.subject}</h3><strong>{subject.progress}%</strong>
              </div>
              <div className="parent-academic__progress-track" role="progressbar" aria-label={`${subject.subject} progress`} aria-valuemin="0" aria-valuemax="100" aria-valuenow={subject.progress}>
                <span style={{ width: `${subject.progress}%` }} />
              </div>
              <p>{subject.completedLessons} / {subject.totalLessons} lessons completed</p>
            </article>
          ))}
        </div>
      </section>

      <div className="parent-progress__lower-grid">
        <section className="parent-academic__section" aria-labelledby="parent-learning-activity-title">
          <div className="parent-academic__section-heading">
            <h2 id="parent-learning-activity-title">Recent Learning Activity</h2>
          </div>
          <ol className="parent-progress__activity-list">
            {activities.map((activity) => (
              <li key={activity.id}>
                <time>{formatDate(activity.date)}</time>
                <div><strong>{activity.title}</strong><span>{activity.subject}</span></div>
                <span>{activity.type}</span>
              </li>
            ))}
          </ol>
        </section>

        <section className="parent-academic__section" aria-labelledby="parent-achievements-title">
          <div className="parent-academic__section-heading">
            <h2 id="parent-achievements-title">Achievements</h2>
          </div>
          <div className="parent-progress__achievements">
            {studentLearningAchievements.map((achievement) => (
              <article key={achievement.title}>
                <span>Earned</span>
                <h3>{achievement.title}</h3>
                <p>{achievement.description}</p>
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}

export default ParentProgress
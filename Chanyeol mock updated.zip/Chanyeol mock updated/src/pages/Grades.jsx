import { studentGrades } from "../../Data/mockData"
import "./Grades.css"

function Grades() {
  const overallAverage = studentGrades.length > 0
    ? studentGrades.reduce((sum, subject) => sum + subject.percentage, 0) / studentGrades.length
    : 0

  return (
    <div className="grades-page">
      <div className="grades-page__heading">
        <h1>Grades</h1>
        <p>Review your current performance and assessment results by subject.</p>
      </div>

      <section className="grades-page__summary" aria-label="Overall grade summary">
        <div>
          <h2>Overall Average</h2>
          <p>{overallAverage.toFixed(1)}%</p>
        </div>
        <span>Across {studentGrades.length} subjects</span>
      </section>

      <section className="grades-page__grid" aria-label="Subject grades">
        {studentGrades.map((subject) => (
          <article className="grades-page__card" key={subject.subjectId}>
            <header className="grades-page__card-heading">
              <div>
                <h2>{subject.subject}</h2>
                <p>{subject.teacher}</p>
              </div>
              <span className="grades-page__letter-grade">{subject.letterGrade}</span>
            </header>

            <div className="grades-page__grade-value">
              <span>Current grade</span>
              <strong>{subject.percentage}%</strong>
            </div>
            <div
              className="grades-page__progress-track"
              role="progressbar"
              aria-label={`${subject.subject} grade`}
              aria-valuemin="0"
              aria-valuemax="100"
              aria-valuenow={subject.percentage}
            >
              <span style={{ width: `${subject.percentage}%` }} />
            </div>

            <section className="grades-page__assessments" aria-label={`${subject.subject} assessment breakdown`}>
              <h3>Assessment Breakdown</h3>
              <ul>
                {subject.assessments.map((assessment) => {
                  const assessmentPercentage = assessment.total > 0
                    ? Math.round((assessment.score / assessment.total) * 100)
                    : 0

                  return (
                    <li key={assessment.name}>
                      <span>{assessment.name}</span>
                      <span className="grades-page__assessment-score">
                        {assessment.score} / {assessment.total}
                        <small>{assessmentPercentage}%</small>
                      </span>
                    </li>
                  )
                })}
              </ul>
            </section>
          </article>
        ))}
      </section>
    </div>
  )
}

export default Grades

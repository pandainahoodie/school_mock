import { useNavigate } from "react-router-dom"
import { teacherDashboardData } from "../../Data/mockData"
import "./TeacherClasses.css"

function TeacherClasses() {
  const navigate = useNavigate()
  const classes = teacherDashboardData.classes
  const totalStudents = classes.reduce((total, classItem) => total + classItem.students, 0)

  return (
    <div className="teacher-classes">
      <div className="teacher-classes__heading">
        <h1>My Classes</h1>
        <p>View and manage the classes assigned to you.</p>
      </div>

      <section className="teacher-classes__summary" aria-label="Class summary">
        <article className="teacher-classes__summary-card">
          <span>Total Classes</span>
          <strong>{classes.length}</strong>
        </article>
        <article className="teacher-classes__summary-card">
          <span>Total Students</span>
          <strong>{totalStudents}</strong>
        </article>
      </section>

      <section className="teacher-classes__grid" aria-label="Assigned classes">
        {classes.map((classItem) => (
          <article className="teacher-classes__card" key={classItem.id}>
            <div className="teacher-classes__card-heading">
              <div>
                <h2>{classItem.name}</h2>
                <span>{classItem.subject}</span>
              </div>
              <span className="teacher-classes__student-badge">{classItem.students} students</span>
            </div>

            <dl className="teacher-classes__details">
              <div>
                <dt>Schedule</dt>
                <dd>{classItem.schedule}</dd>
              </div>
              <div>
                <dt>Room</dt>
                <dd>{classItem.room}</dd>
              </div>
            </dl>

            <button
              className="teacher-classes__view-button"
              type="button"
              onClick={() => navigate(`/teacher/classes/${classItem.id}`)}
            >
              View Class
            </button>
          </article>
        ))}
      </section>
    </div>
  )
}

export default TeacherClasses

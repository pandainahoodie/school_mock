import { useNavigate, useParams } from "react-router-dom"
import { teacherDashboardData } from "../../Data/mockData"
import "./TeacherAnnouncements.css"

function TeacherAnnouncementDetails() {
  const { announcementId } = useParams()
  const navigate = useNavigate()
  const announcement = teacherDashboardData.recentAnnouncements
    .find((item) => item.id === announcementId)
  const classItem = teacherDashboardData.classes
    .find((item) => item.name === announcement?.targetClass)

  if (!announcement) {
    return (
      <div className="teacher-announcement-details">
        <section className="teacher-announcement-details__not-found">
          <h1>Announcement not found</h1>
          <button type="button" onClick={() => navigate("/teacher/announcements")}>
            Back to Announcements
          </button>
        </section>
      </div>
    )
  }

  return (
    <div className="teacher-announcement-details">
      <button
        className="teacher-announcement-details__back-button"
        type="button"
        onClick={() => navigate("/teacher/announcements")}
      >
        Back to Announcements
      </button>

      <header className="teacher-announcement-details__heading">
        <div>
          <p className="teacher-announcement-details__eyebrow">
            {classItem?.name ?? announcement.targetClass}
            {classItem ? ` · ${classItem.subject}` : ""}
          </p>
          <h1>{announcement.title}</h1>
        </div>
        <span className={`teacher-announcements__status teacher-announcements__status--${announcement.status.toLowerCase()}`}>
          {announcement.status}
        </span>
      </header>

      <dl className="teacher-announcement-details__metadata">
        <div>
          <dt>Author</dt>
          <dd>{teacherDashboardData.teacherName}</dd>
        </div>
        <div>
          <dt>Date</dt>
          <dd>{announcement.date}</dd>
        </div>
        <div>
          <dt>Target Class</dt>
          <dd>{announcement.targetClass}</dd>
        </div>
      </dl>

      <article className="teacher-announcement-details__content">
        <h2>Announcement</h2>
        <p>{announcement.content}</p>
      </article>
    </div>
  )
}

export default TeacherAnnouncementDetails
import { useState } from "react"
import { Link } from "react-router-dom"
import { adminTeacherRecords } from "../../Data/mockData"
import MockActionModal from "../components/MockActionModal"
import "./AdminTeachers.css"

const teachers = adminTeacherRecords
const subjects = [...new Set(teachers.flatMap((teacher) => teacher.subjects))]
const assignedClassCount = new Set(teachers.flatMap((teacher) => teacher.classIds)).size

function AdminTeachers() {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [activeModal, setActiveModal] = useState(false)
  const normalizedSearch = search.trim().toLowerCase()
  const filteredTeachers = teachers.filter((teacher) => {
    const matchesSearch = [teacher.name, teacher.teacherId]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesStatus = statusFilter === "All statuses" || teacher.status === statusFilter
    const matchesSubject = subjectFilter === "All subjects" || teacher.subjects.includes(subjectFilter)

    return matchesSearch && matchesStatus && matchesSubject
  })
  const summary = [
    { label: "Total Teachers", value: teachers.length },
    { label: "Active Teachers", value: teachers.filter((teacher) => teacher.status === "Active").length },
    { label: "Inactive Teachers", value: teachers.filter((teacher) => teacher.status === "Inactive").length },
    { label: "Assigned Classes", value: assignedClassCount },
  ]

  const modalFields = [
    { name: "teacherName", label: "Teacher name", type: "text", placeholder: "e.g. Min Ji Park", required: true },
    { name: "teacherId", label: "Teacher ID", type: "text", placeholder: "TCH-XXXX", required: true },
    { name: "subject", label: "Primary subject", type: "select", options: subjects, value: subjects[0] ?? "" },
    { name: "status", label: "Status", type: "select", options: ["Active", "Inactive"], value: "Active" },
  ]

  return (
    <div className="admin-teachers">
      <header className="admin-teachers__heading">
        <div>
          <h1>Teachers</h1>
          <p>View the school's teaching staff and their class assignments.</p>
        </div>
        <button className="admin-teachers__add-button" type="button" onClick={() => setActiveModal(true)}>
          Add Teacher
        </button>
      </header>

      <section className="admin-teachers__summary" aria-label="Teacher summary">
        {summary.map(({ label, value }) => (
          <article className="admin-teachers__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-teachers__section" aria-labelledby="admin-teacher-list-title">
        <div className="admin-teachers__toolbar">
          <div>
            <h2 id="admin-teacher-list-title">Teaching Staff</h2>
            <p>Showing {filteredTeachers.length} of {teachers.length}</p>
          </div>
          <div className="admin-teachers__filters">
            <label>
              <span className="admin-teachers__visually-hidden">Search teachers by name or ID</span>
              <input
                type="search"
                placeholder="Search teachers..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="admin-teachers__visually-hidden">Filter teachers by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </label>
            <label>
              <span className="admin-teachers__visually-hidden">Filter teachers by subject</span>
              <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
                <option value="All subjects">All subjects</option>
                {subjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
              </select>
            </label>
          </div>
        </div>

        <div className="admin-teachers__table-wrap">
          <table className="admin-teachers__table">
            <thead>
              <tr>
                <th scope="col">Teacher Name</th>
                <th scope="col">Teacher ID</th>
                <th scope="col">Subjects</th>
                <th scope="col">Classes</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredTeachers.length > 0 ? filteredTeachers.map((teacher) => (
                <tr key={teacher.id}>
                  <th scope="row" data-label="Teacher Name">{teacher.name}</th>
                  <td data-label="Teacher ID">{teacher.teacherId}</td>
                  <td data-label="Subjects">{teacher.subjects.join(", ")}</td>
                  <td data-label="Classes">{teacher.classIds.length}</td>
                  <td data-label="Status">
                    <span className={`admin-teachers__status admin-teachers__status--${teacher.status.toLowerCase()}`}>
                      {teacher.status}
                    </span>
                  </td>
                  <td data-label="Action">
                    <Link className="admin-teachers__view-link" to={`/admin/teachers/${teacher.teacherId}`}>
                      View Teacher
                    </Link>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="admin-teachers__empty" colSpan="6">No teachers match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <MockActionModal
        isOpen={activeModal}
        title="Add Teacher"
        description="Add a teacher record to the mock school management system."
        submitLabel="Save Teacher"
        fields={modalFields}
        onClose={() => setActiveModal(false)}
        onSubmit={() => setActiveModal(false)}
      />
    </div>
  )
}

export default AdminTeachers
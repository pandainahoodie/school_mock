import { Link } from "react-router-dom"
import { studentGrades, studentLearningProgress } from "../../Data/mockData"
import "./ParentGrades.css"

const PASSING_THRESHOLD = 85
const progressBySubject = Object.fromEntries(studentLearningProgress.map((item) => [item.subjectId, item]))

function ParentGrades() {
  const overallAverage = studentGrades.length > 0
    ? studentGrades.reduce((total, subject) => total + subject.percentage, 0) / studentGrades.length
    : 0
  const assessmentCount = studentGrades.reduce((total, subject) => total + subject.assessments.length, 0)
  const summaries = [
    { label: "Overall Grade", value: `${overallAverage.toFixed(1)}%` },
    { label: "Subjects", value: studentGrades.length },
    { label: "Assessments", value: assessmentCount },
  ]

  return (
    <div className="parent-academic parent-grades">
      <header className="parent-academic__heading">
        <div>
          <h1>Grades</h1>
          <p>Review Chanyeol's current grades and assessment results.</p>
        </div>
        <Link className="parent-academic__back-link" to="/parent">Parent Dashboard</Link>
      </header>

      <section className="parent-academic__summary" aria-label="Grade summary">
        {summaries.map(({ label, value }) => (
          <article className="parent-academic__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="parent-academic__section" aria-labelledby="parent-subject-grades-title">
        <div className="parent-academic__section-heading">
          <h2 id="parent-subject-grades-title">Subject Grades</h2>
        </div>
        <div className="parent-grades__subject-grid">
          {studentGrades.map((subject) => {
            const progress = progressBySubject[subject.subjectId]
            const status = subject.percentage >= PASSING_THRESHOLD ? "Passing" : "Needs Attention"

            return (
              <article className="parent-grades__subject-card" key={subject.subjectId}>
                <header>
                  <div>
                    <h3>{subject.subject}</h3>
                    <span>{subject.teacher}</span>
                  </div>
                  <span className={`parent-academic__status parent-academic__status--${status === "Passing" ? "passing" : "attention"}`}>
                    {status}
                  </span>
                </header>
                <div className="parent-grades__grade-value">
                  <strong>{subject.percentage}%</strong>
                  <span>{subject.letterGrade}</span>
                </div>
                {progress && (
                  <div className="parent-academic__progress-row">
                    <span>Subject progress</span><strong>{progress.progress}%</strong>
                    <div className="parent-academic__progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow={progress.progress} aria-label={`${subject.subject} progress`}>
                      <span style={{ width: `${progress.progress}%` }} />
                    </div>
                  </div>
                )}
                <ul className="parent-grades__assessments">
                  {subject.assessments.map((assessment) => {
                    const percentage = assessment.total > 0 ? (assessment.score / assessment.total) * 100 : 0
                    const assessmentStatus = percentage >= PASSING_THRESHOLD ? "Passing" : "Needs Attention"

                    return (
                      <li key={assessment.name}>
                        <span>{assessment.name}</span>
                        <span>{assessment.score} / {assessment.total} · {percentage.toFixed(0)}%</span>
                        <span className={`parent-academic__status parent-academic__status--${assessmentStatus === "Passing" ? "passing" : "attention"}`}>
                          {assessmentStatus}
                        </span>
                      </li>
                    )
                  })}
                </ul>
              </article>
            )
          })}
        </div>
      </section>
    </div>
  )
}

export default ParentGrades
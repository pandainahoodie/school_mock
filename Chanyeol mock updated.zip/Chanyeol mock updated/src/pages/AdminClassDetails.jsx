import { Link, useNavigate, useParams } from "react-router-dom"
import {
  adminTeacherRecords,
  studentSubjects,
  teacherClassDetails,
  teacherDashboardData,
  teacherScheduleRecords,
} from "../../Data/mockData"
import "./AdminClasses.css"

const subjectByName = Object.fromEntries(studentSubjects.map((subject) => [subject.name, subject]))
const classById = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
)

function formatTime(time) {
  const [hours, minutes] = time.split(":").map(Number)

  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "UTC",
  }).format(new Date(Date.UTC(2026, 0, 1, hours, minutes)))
}

function AdminClassDetails() {
  const { classId } = useParams()
  const navigate = useNavigate()
  const classItem = classById[classId]

  if (!classItem) {
    return (
      <div className="admin-class-details">
        <section className="admin-class-details__not-found">
          <h1>Class not found</h1>
          <button type="button" onClick={() => navigate("/admin/classes")}>
            Back to Classes
          </button>
        </section>
      </div>
    )
  }

  const subjectRecord = subjectByName[classItem.subject]
  const assignedTeacher = adminTeacherRecords.find((teacher) => teacher.classIds.includes(classItem.id))
  const teacherName = subjectRecord?.teacher ?? assignedTeacher?.name ?? "Unassigned"
  const roster = teacherClassDetails[classItem.id]?.students ?? []
  const schedule = teacherScheduleRecords
    .filter((record) => record.classId === classItem.id)
    .sort((left, right) => left.date.localeCompare(right.date) || left.startTime.localeCompare(right.startTime))
  const classDetails = teacherClassDetails[classItem.id]

  return (
    <div className="admin-class-details">
      <button
        className="admin-class-details__back-button"
        type="button"
        onClick={() => navigate("/admin/classes")}
      >
        Back to Classes
      </button>

      <header className="admin-class-details__heading">
        <div>
          <p className="admin-class-details__eyebrow">Class Record · {classItem.subject}</p>
          <h1>{classItem.name}</h1>
        </div>
        <span className={`admin-classes__status admin-classes__status--${(classItem.status ?? "Active").toLowerCase()}`}>
          {classItem.status ?? "Active"}
        </span>
      </header>

      <section className="admin-class-details__summary" aria-label="Class overview">
        <article>
          <span>Subject</span>
          <strong>{classItem.subject}</strong>
        </article>
        <article>
          <span>Teacher</span>
          <strong>{teacherName}</strong>
        </article>
        <article>
          <span>Room</span>
          <strong>{classItem.room}</strong>
        </article>
        <article>
          <span>Students</span>
          <strong>{classItem.students}</strong>
        </article>
        <article>
          <span>Schedule</span>
          <strong>{classItem.schedule}</strong>
        </article>
      </section>

      <section className="admin-class-details__section" aria-labelledby="admin-class-links-title">
        <div className="admin-class-details__section-heading">
          <h2 id="admin-class-links-title">Related Views</h2>
        </div>
        <div className="admin-class-details__links">
          <Link to={`/teacher/classes/${classItem.id}`}>Open Class Details</Link>
          <Link to={`/teacher/classes/${classItem.id}/students`}>Open Student Roster</Link>
          <Link to="/teacher/schedule">Open Schedule</Link>
        </div>
      </section>

      <div className="admin-class-details__columns">
        <section className="admin-class-details__section" aria-labelledby="admin-class-roster-title">
          <div className="admin-class-details__section-heading">
            <h2 id="admin-class-roster-title">Student Roster</h2>
            <Link to={`/teacher/classes/${classItem.id}/students`}>View Full Roster</Link>
          </div>
          <div className="admin-class-details__records">
            {roster.length > 0 ? roster.map((student) => (
              <article className="admin-class-details__record" key={student.id}>
                <div>
                  <h3>{student.name}</h3>
                  <span>{student.id} · {student.attendance}% attendance · {student.grade}</span>
                </div>
                <Link to={`/admin/students/${student.id}`}>View Student</Link>
              </article>
            )) : (
              <p className="admin-class-details__empty">No student roster records available.</p>
            )}
          </div>
          {roster.length < classItem.students && (
            <p className="admin-class-details__note">Showing {roster.length} roster records of {classItem.students} enrolled students.</p>
          )}
        </section>

        <section className="admin-class-details__section" aria-labelledby="admin-class-schedule-title">
          <div className="admin-class-details__section-heading">
            <h2 id="admin-class-schedule-title">Schedule</h2>
            <Link to="/teacher/schedule">View Schedule</Link>
          </div>
          <div className="admin-class-details__records">
            {schedule.length > 0 ? schedule.map((record) => (
              <article className="admin-class-details__schedule-row" key={record.id}>
                <time>{record.date} · {formatTime(record.startTime)}–{formatTime(record.endTime)}</time>
                <span className={`admin-class-details__schedule-status admin-class-details__schedule-status--${record.status.toLowerCase()}`}>
                  {record.status}
                </span>
              </article>
            )) : <p className="admin-class-details__empty">No schedule records available.</p>}
          </div>
        </section>
      </div>

      <div className="admin-class-details__columns">
        <section className="admin-class-details__section" aria-labelledby="admin-class-assignments-title">
          <div className="admin-class-details__section-heading">
            <h2 id="admin-class-assignments-title">Recent Assignments</h2>
          </div>
          <div className="admin-class-details__records">
            {(classDetails?.assignments ?? []).map((assignment) => (
              <article className="admin-class-details__record" key={assignment.id}>
                <div>
                  <h3>{assignment.name}</h3>
                  <span>{assignment.type} · Due {assignment.dueDate}</span>
                </div>
                <span>{assignment.status}</span>
              </article>
            ))}
          </div>
        </section>

        <section className="admin-class-details__section" aria-labelledby="admin-class-activity-title">
          <div className="admin-class-details__section-heading">
            <h2 id="admin-class-activity-title">Recent Quiz Activity</h2>
          </div>
          <div className="admin-class-details__records">
            {(classDetails?.quizActivity ?? []).map((activity) => (
              <article className="admin-class-details__activity-row" key={activity.id}>
                <p>{activity.description}</p>
                <time>{activity.timeAgo}</time>
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}

export default AdminClassDetails
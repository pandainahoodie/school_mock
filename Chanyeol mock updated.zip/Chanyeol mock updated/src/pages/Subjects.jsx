import { studentSubjects } from "../../Data/mockData"
import { useNavigate } from "react-router-dom"
import "./Subjects.css"

function Subjects() {
  const navigate = useNavigate()

  return (
    <div className="subjects-page">
      <div className="subjects-page__heading">
        <h1>My Subjects</h1>
        <p>View your classes, schedules, and learning progress.</p>
      </div>

      <section className="subjects-page__grid" aria-label="Your subjects">
        {studentSubjects.map(({ id, name, teacher, schedule, room, progress }) => (
          <article className="subjects-page__card" key={id}>
            <h2>{name}</h2>
            <dl className="subjects-page__details">
              <div>
                <dt>Teacher</dt>
                <dd>{teacher}</dd>
              </div>
              <div>
                <dt>Schedule</dt>
                <dd>{schedule}</dd>
              </div>
              <div>
                <dt>Room</dt>
                <dd>{room}</dd>
              </div>
            </dl>
            <div className="subjects-page__progress-label">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <div
              className="subjects-page__progress-track"
              role="progressbar"
              aria-label={`${name} progress`}
              aria-valuemin="0"
              aria-valuemax="100"
              aria-valuenow={progress}
            >
              <span style={{ width: `${progress}%` }} />
            </div>
            <button
              className="subjects-page__view-button"
              type="button"
              onClick={() => navigate(`/subjects/${id}`)}
            >
              View Subject
            </button>
          </article>
        ))}
      </section>
    </div>
  )
}

export default Subjects

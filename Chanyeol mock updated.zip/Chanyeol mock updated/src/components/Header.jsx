import "./Header.css"

function Header() {
  return (
    <header className="app-header">
      <h1 className="app-header__title">Dashboard</h1>

      <form className="app-header__search" role="search">
        <input type="search" placeholder="Search..." aria-label="Search" />
      </form>

      <button className="app-header__notifications" type="button" aria-label="Notifications">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
        </svg>
      </button>

      <div className="app-header__profile">
        <div className="app-header__avatar" aria-hidden="true">CP</div>
        <div className="app-header__user-details">
          <span className="app-header__user-name">Chanyeol Park</span>
          <span className="app-header__user-role">Student</span>
        </div>
      </div>
    </header>
  )
}

export default Header

import "./Sidebar.css"
import { NavLink } from "react-router-dom"

const navigationByRole = {
  Student: ["Dashboard", "My Subjects", "Quizzes", "Assignments", "Grades", "Attendance", "Progress", "Schedule"],
  Teacher: ["Dashboard", "My Classes", "Quizzes", "Assignments", "Attendance", "Grades", "Announcements", "Schedule", "Learning Materials"],
  Admin: ["Dashboard", "Students", "Teachers", "Classes", "Subjects", "Schedules", "Attendance", "Grades", "Announcements"],
  Parent: ["Dashboard", "My Child", "Grades", "Attendance", "Assignments", "Quiz Results", "Progress", "Announcements"],
}

function Sidebar({ role }) {
  const navigationItems = navigationByRole[role] ?? navigationByRole.Student
  const routesByItem = {
    Dashboard: role === "Teacher" ? "/teacher" : role === "Admin" ? "/admin" : role === "Parent" ? "/parent" : "/",
    ...(role === "Parent" ? { "My Child": "/parent/child" } : {}),
    ...(role === "Parent" ? { Grades: "/parent/grades" } : {}),
    ...(role === "Parent" ? { Attendance: "/parent/attendance" } : {}),
    ...(role === "Teacher" ? { "My Classes": "/teacher/classes" } : {}),
    ...(role === "Admin" ? { Students: "/admin/students" } : {}),
    ...(role === "Admin" ? { Teachers: "/admin/teachers" } : {}),
    ...(role === "Admin" ? { Classes: "/admin/classes" } : {}),
    ...(role === "Admin" ? { Subjects: "/admin/subjects" } : {}),
    ...(role === "Admin" ? { Schedules: "/admin/schedules" } : {}),
    ...(role === "Admin" ? { Attendance: "/admin/attendance" } : {}),
    ...(role === "Admin" ? { Grades: "/admin/grades" } : {}),
    ...(role === "Admin" ? { Announcements: "/admin/announcements" } : {}),
    Assignments: role === "Teacher" ? "/teacher/assignments" : role === "Student" ? "/assignments" : role === "Parent" ? "/parent/assignments" : undefined,
    "My Subjects": "/subjects",
    Quizzes: role === "Teacher" ? "/teacher/quizzes" : "/quizzes",
    ...(role === "Teacher" ? { Grades: "/teacher/grades" } : {}),
    ...(role === "Teacher" ? { Attendance: "/teacher/attendance" } : {}),
    ...(role === "Teacher" ? { Announcements: "/teacher/announcements" } : {}),
    ...(role === "Teacher" ? { Schedule: "/teacher/schedule" } : {}),
    ...(role === "Teacher" ? { "Learning Materials": "/teacher/materials" } : {}),
    ...(role === "Parent" ? { "Quiz Results": "/parent/quiz-results" } : {}),
    ...(role === "Parent" ? { Progress: "/parent/progress" } : {}),
    ...(role === "Parent" ? { Announcements: "/parent/announcements" } : {}),
    ...(role === "Student" ? { Grades: "/grades" } : {}),
    ...(role === "Student" ? { Attendance: "/attendance" } : {}),
    ...(role === "Student" ? { Progress: "/progress" } : {}),
  }

  return (
    <aside className="sidebar">
      <h2 className="sidebar__school-name">Park Chanyeol School</h2>

      <nav aria-label="Main navigation">
        <ul className="sidebar__navigation">
          {navigationItems.map((item) => (
            <li key={item}>
              {routesByItem[item] ? (
                <NavLink to={routesByItem[item]} end={item === "Dashboard"}>
                  {item}
                </NavLink>
              ) : (
                <span>{item}</span>
              )}
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  )
}

export default Sidebar

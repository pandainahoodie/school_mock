const roles = ["Student", "Teacher", "Admin", "Parent"]

function RoleSwitcher({ role, onRoleChange }) {
  return (
    <div>
      <label htmlFor="role-select">Select role</label>
      <select
        id="role-select"
        value={role}
        onChange={(event) => onRoleChange(event.target.value)}
      >
        {roles.map((availableRole) => (
          <option key={availableRole} value={availableRole}>
            {availableRole}
          </option>
        ))}
      </select>
      <p>Current role: {role}</p>
    </div>
  )
}

export default RoleSwitcher

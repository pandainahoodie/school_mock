import { useRef, useState } from "react"
import { Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom"
import Sidebar from "./components/Sidebar"
import Header from "./components/Header"
import RoleSwitcher from "./components/RoleSwitcher"
import StudentDashboard from "./pages/StudentDashboard"
import Assignments from "./pages/Assignments"
import AssignmentDetails from "./pages/AssignmentDetails"
import Subjects from "./pages/Subjects"
import SubjectDetails from "./pages/SubjectDetails"
import Quizzes from "./pages/Quizzes"
import QuizAttempt from "./pages/QuizAttempt"
import Grades from "./pages/Grades"
import Attendance from "./pages/Attendance"
import Progress from "./pages/Progress"
import TeacherDashboard from "./pages/TeacherDashboard"
import TeacherClasses from "./pages/TeacherClasses"
import TeacherClassDetails from "./pages/TeacherClassDetails"
import TeacherStudentRoster from "./pages/TeacherStudentRoster"
import TeacherAssignments from "./pages/TeacherAssignments"
import TeacherAssignmentDetails from "./pages/TeacherAssignmentDetails"
import TeacherQuizzes from "./pages/TeacherQuizzes"
import TeacherQuizDetails from "./pages/TeacherQuizDetails"
import TeacherGrades from "./pages/TeacherGrades"
import TeacherAttendance from "./pages/TeacherAttendance"
import TeacherAnnouncements from "./pages/TeacherAnnouncements"
import TeacherAnnouncementDetails from "./pages/TeacherAnnouncementDetails"
import TeacherSchedule from "./pages/TeacherSchedule"
import TeacherMaterials from "./pages/TeacherMaterials"
import TeacherMaterialDetails from "./pages/TeacherMaterialDetails"
import AdminDashboard from "./pages/AdminDashboard"
import AdminStudents from "./pages/AdminStudents"
import AdminStudentDetails from "./pages/AdminStudentDetails"
import AdminTeachers from "./pages/AdminTeachers"
import AdminTeacherDetails from "./pages/AdminTeacherDetails"
import AdminClasses from "./pages/AdminClasses"
import AdminClassDetails from "./pages/AdminClassDetails"
import AdminSubjects from "./pages/AdminSubjects"
import AdminSubjectDetails from "./pages/AdminSubjectDetails"
import AdminSchedules from "./pages/AdminSchedules"
import AdminScheduleDetails from "./pages/AdminScheduleDetails"
import AdminAttendance from "./pages/AdminAttendance"
import AdminGrades from "./pages/AdminGrades"
import AdminAnnouncements from "./pages/AdminAnnouncements"
import AdminAnnouncementDetails from "./pages/AdminAnnouncementDetails"
import ParentDashboard from "./pages/ParentDashboard"
import ParentChild from "./pages/ParentChild"
import ParentGrades from "./pages/ParentGrades"
import ParentAttendance from "./pages/ParentAttendance"
import ParentAssignments from "./pages/ParentAssignments"
import ParentQuizResults from "./pages/ParentQuizResults"
import ParentProgress from "./pages/ParentProgress"
import ParentAnnouncements from "./pages/ParentAnnouncements"
import { initialAssignments, studentQuizzes } from "../Data/mockData"

function getQuizHistoryStorageKey(quizId) {
  return `quizHistory_${quizId}`
}

function readQuizHistory() {
  return Object.fromEntries(studentQuizzes.map((quiz) => {
    try {
      const savedHistory = JSON.parse(
        localStorage.getItem(getQuizHistoryStorageKey(quiz.id)) ?? "[]",
      )
      const history = Array.isArray(savedHistory)
        ? savedHistory.filter((record) =>
          record.quizId === quiz.id &&
          typeof record.id === "string" &&
          Array.isArray(record.questionReview),
        )
        : []

      return [quiz.id, history.sort((left, right) =>
        (right.attemptNumber ?? 0) - (left.attemptNumber ?? 0) ||
        Date.parse(right.completedAt) - Date.parse(left.completedAt),
      )]
    } catch {
      return [quiz.id, []]
    }
  }))
}

function getRoleFromPath(pathname) {
  if (pathname.startsWith("/admin")) {
    return "Admin"
  }

  if (pathname.startsWith("/parent")) {
    return "Parent"
  }

  if (pathname.startsWith("/teacher")) {
    return "Teacher"
  }

  return "Student"
}

function App() {
  const location = useLocation()
  const navigate = useNavigate()
  const role = getRoleFromPath(location.pathname)
  const isGradesPage = location.pathname === "/grades"
  const isAttendancePage = location.pathname === "/attendance"
  const isProgressPage = location.pathname === "/progress"
  const isAdminPage = location.pathname === "/admin"
  const isTeacherPage = location.pathname.startsWith("/teacher")
  const [assignments, setAssignments] = useState(initialAssignments)
  const [completedQuizAttempts, setCompletedQuizAttempts] = useState(() =>
    Object.fromEntries(studentQuizzes.map((quiz) => [quiz.id, quiz.attemptsUsed])),
  )
  const [quizHistory, setQuizHistory] = useState(readQuizHistory)
  const quizHistoryRef = useRef(quizHistory)

  function handleRoleChange(nextRole) {
    const destinationByRole = {
      Student: "/",
      Teacher: "/teacher",
      Admin: "/admin",
      Parent: "/parent",
    }

    navigate(destinationByRole[nextRole] ?? "/")
  }

  function handleSubmitAssignment(assignmentId) {
    setAssignments((currentAssignments) =>
      currentAssignments.map((assignment) =>
        assignment.id === assignmentId
          ? { ...assignment, status: "Submitted" }
          : assignment,
      ),
    )
  }

  function handleCompleteQuiz(quizId, attemptId, result) {
    const quiz = studentQuizzes.find((item) => item.id === quizId)
    if (!quiz || !attemptId) {
      return null
    }

    const currentHistory = quizHistoryRef.current[quizId] ?? []
    const existingRecord = currentHistory.find((record) => record.id === attemptId)
    if (existingRecord) {
      return existingRecord
    }

    const latestAttemptNumber = currentHistory.reduce(
      (latest, record) => Math.max(latest, record.attemptNumber ?? 0),
      0,
    )
    const attemptNumber = Math.max(
      completedQuizAttempts[quizId] ?? quiz.attemptsUsed,
      quiz.attemptsUsed + currentHistory.length,
      latestAttemptNumber,
    ) + 1
    const record = {
      ...result,
      id: attemptId,
      quizId,
      attemptNumber,
      score: result.correctAnswers,
      completedAt: new Date().toISOString(),
    }
    const updatedHistory = [record, ...currentHistory].sort((left, right) =>
      (right.attemptNumber ?? 0) - (left.attemptNumber ?? 0) ||
      Date.parse(right.completedAt) - Date.parse(left.completedAt),
    )
    const updatedHistoryByQuiz = {
      ...quizHistoryRef.current,
      [quizId]: updatedHistory,
    }

    quizHistoryRef.current = updatedHistoryByQuiz
    setQuizHistory(updatedHistoryByQuiz)
    try {
      localStorage.setItem(getQuizHistoryStorageKey(quizId), JSON.stringify(updatedHistory))
    } catch {
      // Keep the result available in this app session if storage is unavailable.
    }
    setCompletedQuizAttempts((currentAttempts) => ({
      ...currentAttempts,
      [quizId]: (currentAttempts[quizId] ?? 0) + 1,
    }))
    return record
  }

  return (
    <div className="app-layout">
      <Sidebar role={role} />
      <main className={`app-main app-main--with-header${isGradesPage || isAttendancePage || isProgressPage || isAdminPage || isTeacherPage ? " app-main--compact-header" : ""}`}>
        <Header />
        <section className="dashboard-content">
          <RoleSwitcher role={role} onRoleChange={handleRoleChange} />
          <Routes>
            <Route
              path="/"
              element={role === "Student" ? <StudentDashboard /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher"
              element={role === "Teacher" ? <TeacherDashboard /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/parent"
              element={role === "Parent" ? <ParentDashboard assignments={assignments} /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/parent/child"
              element={role === "Parent" ? <ParentChild assignments={assignments} quizHistory={quizHistory} /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/parent/grades"
              element={role === "Parent" ? <ParentGrades /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/parent/attendance"
              element={role === "Parent" ? <ParentAttendance /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/parent/assignments"
              element={role === "Parent" ? <ParentAssignments assignments={assignments} /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/parent/quiz-results"
              element={role === "Parent" ? <ParentQuizResults quizHistory={quizHistory} /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/parent/progress"
              element={role === "Parent" ? <ParentProgress /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/parent/announcements"
              element={role === "Parent" ? <ParentAnnouncements /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin"
              element={role === "Admin" ? <AdminDashboard /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/students/:studentId"
              element={role === "Admin" ? <AdminStudentDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/students"
              element={role === "Admin" ? <AdminStudents /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/teachers/:teacherId"
              element={role === "Admin" ? <AdminTeacherDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/teachers"
              element={role === "Admin" ? <AdminTeachers /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/classes/:classId"
              element={role === "Admin" ? <AdminClassDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/classes"
              element={role === "Admin" ? <AdminClasses /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/subjects/:subjectId"
              element={role === "Admin" ? <AdminSubjectDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/subjects"
              element={role === "Admin" ? <AdminSubjects /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/schedules/:scheduleId"
              element={role === "Admin" ? <AdminScheduleDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/schedules"
              element={role === "Admin" ? <AdminSchedules /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/attendance"
              element={role === "Admin" ? <AdminAttendance /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/grades"
              element={role === "Admin" ? <AdminGrades /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/announcements/:announcementId"
              element={role === "Admin" ? <AdminAnnouncementDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/admin/announcements"
              element={role === "Admin" ? <AdminAnnouncements /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/classes"
              element={role === "Teacher" ? <TeacherClasses /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/assignments"
              element={role === "Teacher" ? <TeacherAssignments /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/assignments/:assignmentId"
              element={role === "Teacher" ? <TeacherAssignmentDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/quizzes"
              element={role === "Teacher" ? <TeacherQuizzes /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/quizzes/:quizId"
              element={role === "Teacher" ? <TeacherQuizDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/grades"
              element={role === "Teacher" ? <TeacherGrades /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/attendance"
              element={role === "Teacher" ? <TeacherAttendance /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/announcements/:announcementId"
              element={role === "Teacher" ? <TeacherAnnouncementDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/announcements"
              element={role === "Teacher" ? <TeacherAnnouncements /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/schedule"
              element={role === "Teacher" || role === "Admin" ? <TeacherSchedule /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/materials/:materialId"
              element={role === "Teacher" ? <TeacherMaterialDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/materials"
              element={role === "Teacher" ? <TeacherMaterials /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/classes/:classId"
              element={role === "Teacher" || role === "Admin" ? <TeacherClassDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/teacher/classes/:classId/students"
              element={role === "Teacher" || role === "Admin" ? <TeacherStudentRoster /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/assignments"
              element={role === "Student" ? <Assignments assignments={assignments} /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/grades"
              element={role === "Student" ? <Grades /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/attendance"
              element={role === "Student" ? <Attendance /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/progress"
              element={role === "Student" ? <Progress /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/subjects"
              element={role === "Student" ? <Subjects /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/subjects/:subjectId"
              element={role === "Student" ? <SubjectDetails /> : <h2>Dashboard</h2>}
            />
            <Route
              path="/quizzes"
              element={role === "Student" ? (
                <Quizzes completedAttempts={completedQuizAttempts} quizHistory={quizHistory} />
              ) : (
                <h2>Dashboard</h2>
              )}
            />
            <Route
              path="/quizzes/:quizId"
              element={role === "Student" ? (
                <QuizAttempt
                  key={`${location.pathname}${location.search}`}
                  completedAttempts={completedQuizAttempts}
                  quizHistory={quizHistory}
                  onComplete={handleCompleteQuiz}
                />
              ) : (
                <h2>Dashboard</h2>
              )}
            />
            <Route
              path="/assignments/:assignmentId"
              element={role === "Student" ? (
                <AssignmentDetails
                  assignments={assignments}
                  onSubmit={handleSubmitAssignment}
                />
              ) : (
                <h2>Dashboard</h2>
              )}
            />
            <Route path="*" element={<Navigate to={role === "Admin" ? "/admin" : role === "Teacher" ? "/teacher" : role === "Parent" ? "/parent" : "/" } replace />} />
          </Routes>
        </section>
      </main>
    </div>
  )
}

export default App
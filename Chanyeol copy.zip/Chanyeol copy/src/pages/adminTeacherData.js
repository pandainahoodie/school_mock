import {
  adminTeacherRecords,
  studentSubjects,
  teacherDashboardData,
} from "../../Data/mockData"

export const ADMIN_TEACHERS_STORAGE_KEY = "parkChanyeolSchool_teachers"
export const adminTeacherSubjects = [...new Set(studentSubjects.map((subject) => subject.name))]
export const adminTeacherClasses = teacherDashboardData.classes

const classIds = new Set(adminTeacherClasses.map((classItem) => classItem.id))

export const initialAdminTeachers = adminTeacherRecords.map((teacher) => ({
  ...teacher,
  subjects: [...teacher.subjects],
  classIds: [...teacher.classIds],
  legacyIds: [],
}))

export function getTeacherClassIdsForSubject(subject) {
  return adminTeacherClasses
    .filter((classItem) => classItem.subject === subject)
    .map((classItem) => classItem.id)
}

export function readAdminTeachers() {
  try {
    const storedTeachers = window.localStorage.getItem(ADMIN_TEACHERS_STORAGE_KEY)

    if (storedTeachers === null) {
      return initialAdminTeachers
    }

    const parsedTeachers = JSON.parse(storedTeachers)
    if (!Array.isArray(parsedTeachers)) {
      return initialAdminTeachers
    }

    return parsedTeachers.flatMap((teacher) => {
      if (!teacher || typeof teacher !== "object") {
        return []
      }

      const teacherId = typeof teacher.teacherId === "string" ? teacher.teacherId.trim() : ""
      const name = typeof teacher.name === "string" ? teacher.name.trim() : ""

      if (!teacherId || !name) {
        return []
      }

      return [{
        ...teacher,
        id: typeof teacher.id === "string" ? teacher.id : teacherId.toLowerCase(),
        teacherId,
        name,
        status: typeof teacher.status === "string" ? teacher.status : "Active",
        subjects: Array.isArray(teacher.subjects)
          ? [...new Set(teacher.subjects.filter((subject) => typeof subject === "string"))]
          : [],
        classIds: Array.isArray(teacher.classIds)
          ? [...new Set(teacher.classIds.filter((classId) => classIds.has(classId)))]
          : [],
        legacyIds: Array.isArray(teacher.legacyIds)
          ? [...new Set(teacher.legacyIds.filter((legacyId) => typeof legacyId === "string"))]
          : [],
      }]
    })
  } catch {
    return initialAdminTeachers
  }
}

export function saveAdminTeachers(teachers) {
  try {
    window.localStorage.setItem(ADMIN_TEACHERS_STORAGE_KEY, JSON.stringify(teachers))
    return true
  } catch {
    return false
  }
}
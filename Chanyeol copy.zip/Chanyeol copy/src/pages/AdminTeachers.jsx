import { useEffect, useRef, useState } from "react"
import { Link } from "react-router-dom"
import {
  adminTeacherSubjects,
  getTeacherClassIdsForSubject,
  readAdminTeachers,
  saveAdminTeachers,
} from "./adminTeacherData"
import MockActionModal from "../components/MockActionModal"
import "./AdminTeachers.css"

function AdminTeachers() {
  const [teachers, setTeachers] = useState(readAdminTeachers)
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const [subjectFilter, setSubjectFilter] = useState("All subjects")
  const [activeTeacherModal, setActiveTeacherModal] = useState(null)
  const [teacherToDelete, setTeacherToDelete] = useState(null)
  const [feedback, setFeedback] = useState("")
  const feedbackTimer = useRef(null)
  const normalizedSearch = search.trim().toLowerCase()
  const filteredTeachers = teachers.filter((teacher) => {
    const matchesSearch = [teacher.name, teacher.teacherId]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesStatus = statusFilter === "All statuses" || teacher.status === statusFilter
    const matchesSubject = subjectFilter === "All subjects" || teacher.subjects.includes(subjectFilter)

    return matchesSearch && matchesStatus && matchesSubject
  })
  const summary = [
    { label: "Total Teachers", value: teachers.length },
    { label: "Active Teachers", value: teachers.filter((teacher) => teacher.status === "Active").length },
    { label: "Inactive Teachers", value: teachers.filter((teacher) => teacher.status === "Inactive").length },
    { label: "Assigned Classes", value: new Set(teachers.flatMap((teacher) => teacher.classIds)).size },
  ]

  const modalFields = [
    {
      name: "name",
      label: "Teacher Name",
      type: "text",
      placeholder: "e.g. Min Ji Park",
      value: activeTeacherModal?.teacher?.name ?? "",
      required: true,
    },
    {
      name: "teacherId",
      label: "Teacher ID",
      type: "text",
      placeholder: "TCH-XXXX",
      value: activeTeacherModal?.teacher?.teacherId ?? "",
      required: true,
    },
    {
      name: "subject",
      label: "Subject",
      type: "select",
      options: adminTeacherSubjects,
      value: activeTeacherModal?.teacher?.subjects[0] ?? adminTeacherSubjects[0] ?? "",
      required: true,
    },
    {
      name: "status",
      label: "Status",
      type: "select",
      options: ["Active", "Inactive"],
      value: activeTeacherModal?.teacher?.status ?? "Active",
      required: true,
    },
  ]

  useEffect(() => () => window.clearTimeout(feedbackTimer.current), [])

  useEffect(() => {
    if (!teacherToDelete) {
      return undefined
    }

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setTeacherToDelete(null)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [teacherToDelete])

  function showFeedback(message) {
    window.clearTimeout(feedbackTimer.current)
    setFeedback(message)
    feedbackTimer.current = window.setTimeout(() => setFeedback(""), 3500)
  }

  function commitTeachers(updatedTeachers) {
    setTeachers(updatedTeachers)
    saveAdminTeachers(updatedTeachers)
  }

  function validateTeacher(values) {
    const enteredId = values.teacherId.trim().toLowerCase()
    const editingTeacher = activeTeacherModal?.teacher
    const duplicate = teachers.some((teacher) => {
      if (teacher.teacherId.toLowerCase() === enteredId) {
        return teacher.teacherId !== editingTeacher?.teacherId
      }

      return teacher.legacyIds.some((legacyId) => (
        legacyId.toLowerCase() === enteredId && teacher.teacherId !== editingTeacher?.teacherId
      ))
    })

    return duplicate ? { teacherId: "This Teacher ID is already in use." } : {}
  }

  function handleSaveTeacher(values) {
    const teacherId = values.teacherId.trim()
    const name = values.name.trim()
    const subject = values.subject

    if (activeTeacherModal.mode === "edit") {
      const originalTeacher = activeTeacherModal.teacher
      const idChanged = teacherId !== originalTeacher.teacherId
      const sameSubject = subject === originalTeacher.subjects[0]
      const legacyIds = [...originalTeacher.legacyIds]

      if (idChanged && !legacyIds.includes(originalTeacher.teacherId)) {
        legacyIds.push(originalTeacher.teacherId)
      }

      const updatedTeacher = {
        ...originalTeacher,
        id: originalTeacher.id,
        teacherId,
        name,
        status: values.status,
        subjects: sameSubject ? originalTeacher.subjects : [subject],
        classIds: sameSubject
          ? originalTeacher.classIds
          : getTeacherClassIdsForSubject(subject),
        legacyIds: legacyIds.filter((legacyId) => legacyId !== teacherId),
      }

      commitTeachers(teachers.map((teacher) => (
        teacher.teacherId === originalTeacher.teacherId ? updatedTeacher : teacher
      )))
      setActiveTeacherModal(null)
      showFeedback("Teacher updated successfully.")
      return
    }

    commitTeachers([
      ...teachers,
      {
        id: teacherId.toLowerCase(),
        teacherId,
        name,
        status: values.status,
        subjects: [subject],
        classIds: getTeacherClassIdsForSubject(subject),
        legacyIds: [],
      },
    ])
    setActiveTeacherModal(null)
    showFeedback("Teacher added successfully.")
  }

  function handleDeleteTeacher() {
    if (!teacherToDelete) {
      return
    }

    commitTeachers(teachers.filter((teacher) => teacher.teacherId !== teacherToDelete.teacherId))
    setTeacherToDelete(null)
    showFeedback("Teacher deleted successfully.")
  }

  return (
    <div className="admin-teachers">
      <header className="admin-teachers__heading">
        <div>
          <h1>Teachers</h1>
          <p>View the school's teaching staff and their class assignments.</p>
        </div>
        <button className="admin-teachers__add-button" type="button" onClick={() => setActiveTeacherModal({ mode: "add" })}>
          Add Teacher
        </button>
      </header>

      <section className="admin-teachers__summary" aria-label="Teacher summary">
        {summary.map(({ label, value }) => (
          <article className="admin-teachers__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-teachers__section" aria-labelledby="admin-teacher-list-title">
        <div className="admin-teachers__toolbar">
          <div>
            <h2 id="admin-teacher-list-title">Teaching Staff</h2>
            <p>Showing {filteredTeachers.length} of {teachers.length}</p>
          </div>
          <div className="admin-teachers__filters">
            <label>
              <span className="admin-teachers__visually-hidden">Search teachers by name or ID</span>
              <input
                type="search"
                placeholder="Search teachers..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="admin-teachers__visually-hidden">Filter teachers by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </label>
            <label>
              <span className="admin-teachers__visually-hidden">Filter teachers by subject</span>
              <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)}>
                <option value="All subjects">All subjects</option>
                {adminTeacherSubjects.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
              </select>
            </label>
          </div>
        </div>

        <div className="admin-teachers__table-wrap">
          <table className="admin-teachers__table">
            <thead>
              <tr>
                <th scope="col">Teacher Name</th>
                <th scope="col">Teacher ID</th>
                <th scope="col">Subjects</th>
                <th scope="col">Classes</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredTeachers.length > 0 ? filteredTeachers.map((teacher) => (
                <tr key={teacher.id}>
                  <th scope="row" data-label="Teacher Name">{teacher.name}</th>
                  <td data-label="Teacher ID">{teacher.teacherId}</td>
                  <td data-label="Subjects">{teacher.subjects.join(", ") || "Not assigned"}</td>
                  <td data-label="Classes">{teacher.classIds.length}</td>
                  <td data-label="Status">
                    <span className={`admin-teachers__status admin-teachers__status--${teacher.status.toLowerCase()}`}>
                      {teacher.status}
                    </span>
                  </td>
                  <td data-label="Action">
                    <div className="admin-teachers__row-actions">
                      <Link className="admin-teachers__view-link" to={`/admin/teachers/${teacher.teacherId}`}>
                        View
                      </Link>
                      <button
                        className="admin-teachers__row-action"
                        type="button"
                        onClick={() => setActiveTeacherModal({ mode: "edit", teacher })}
                      >
                        Edit
                      </button>
                      <button
                        className="admin-teachers__row-action admin-teachers__row-action--delete"
                        type="button"
                        onClick={() => setTeacherToDelete(teacher)}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="admin-teachers__empty" colSpan="6">No teachers match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {activeTeacherModal ? (
        <MockActionModal
          key={`${activeTeacherModal.mode}-${activeTeacherModal.teacher?.teacherId ?? "new"}`}
          isOpen
          title={activeTeacherModal.mode === "edit" ? "Edit Teacher" : "Add Teacher"}
          description={activeTeacherModal.mode === "edit"
            ? "Update this teacher record."
            : "Add a teacher record to the mock school management system."}
          submitLabel={activeTeacherModal.mode === "edit" ? "Save Changes" : "Add Teacher"}
          fields={modalFields}
          validate={validateTeacher}
          onClose={() => setActiveTeacherModal(null)}
          onSubmit={handleSaveTeacher}
        />
      ) : null}

      {teacherToDelete ? (
        <div className="admin-teachers__confirm-backdrop" onClick={() => setTeacherToDelete(null)}>
          <section
            className="admin-teachers__confirm-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="delete-teacher-title"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              className="admin-teachers__confirm-close"
              type="button"
              aria-label="Close confirmation"
              onClick={() => setTeacherToDelete(null)}
            >
              ×
            </button>
            <h2 id="delete-teacher-title">Delete this teacher?</h2>
            <p>Delete <strong>{teacherToDelete.name}</strong> from the teacher list?</p>
            <div className="admin-teachers__confirm-actions">
              <button type="button" onClick={() => setTeacherToDelete(null)}>Cancel</button>
              <button type="button" className="admin-teachers__confirm-delete" onClick={handleDeleteTeacher}>
                Delete
              </button>
            </div>
          </section>
        </div>
      ) : null}

      {feedback ? (
        <div className="admin-teachers__toast" role="status" aria-live="polite">
          {feedback}
        </div>
      ) : null}
    </div>
  )
}

export default AdminTeachers
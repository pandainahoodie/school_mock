import { useEffect, useState } from "react"
import "./MockActionModal.css"

function getInitialFormState(fields) {
  return Object.fromEntries(fields.map((field) => {
    const initialValue = field.value ?? (field.type === "checkbox" ? false : "")

    return [field.name, initialValue]
  }))
}

function MockActionModal({
  isOpen,
  title,
  description,
  fields,
  submitLabel = "Save",
  onClose,
  onSubmit,
}) {
  const [formState, setFormState] = useState(() => getInitialFormState(fields))
  const [errors, setErrors] = useState({})

  useEffect(() => {
    if (!isOpen) {
      return undefined
    }

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        onClose()
      }
    }

    window.addEventListener("keydown", handleKeyDown)

    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [fields, isOpen, onClose])

  if (!isOpen) {
    return null
  }

  function handleChange(event) {
    const { name, type, checked, value } = event.target

    setFormState((currentState) => ({
      ...currentState,
      [name]: type === "checkbox" ? checked : value,
    }))
  }

  function handleSubmit(event) {
    event.preventDefault()

    const nextErrors = {}

    fields.forEach((field) => {
      const rawValue = formState[field.name]
      const value = typeof rawValue === "string" ? rawValue.trim() : rawValue

      if (field.required && (value === "" || value === null || value === undefined || value === false)) {
        nextErrors[field.name] = `${field.label} is required.`
      }
    })

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors)
      return
    }

    onSubmit(formState)
  }

  return (
    <div className="mock-action-modal__backdrop" onClick={onClose}>
      <div
        className="mock-action-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="mock-action-modal-title"
        onClick={(event) => event.stopPropagation()}
      >
        <button
          type="button"
          className="mock-action-modal__close"
          onClick={onClose}
          aria-label="Close form"
        >
          ×
        </button>

        <header className="mock-action-modal__header">
          <h2 id="mock-action-modal-title">{title}</h2>
          {description ? <p>{description}</p> : null}
        </header>

        <form className="mock-action-modal__form" onSubmit={handleSubmit}>
          <div className="mock-action-modal__grid">
            {fields.map((field) => {
              const hasError = Boolean(errors[field.name])
              const commonProps = {
                id: field.name,
                name: field.name,
                value: formState[field.name] ?? "",
                onChange: handleChange,
                placeholder: field.placeholder,
                required: field.required,
                className: `mock-action-modal__field ${field.type === "textarea" ? "mock-action-modal__field--textarea" : ""}`,
              }

              return (
                <label className="mock-action-modal__field-group" htmlFor={field.name} key={field.name}>
                  <span>{field.label}</span>

                  {field.type === "textarea" ? (
                    <textarea {...commonProps} rows={4} />
                  ) : field.type === "select" ? (
                    <select {...commonProps}>
                      {field.options.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input {...commonProps} type={field.type ?? "text"} />
                  )}

                  {hasError ? (
                    <small className="mock-action-modal__error">{errors[field.name]}</small>
                  ) : null}
                </label>
              )
            })}
          </div>

          <div className="mock-action-modal__actions">
            <button type="button" className="mock-action-modal__secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="mock-action-modal__primary">
              {submitLabel}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default MockActionModal
import { useState } from "react"
import { Link } from "react-router-dom"
import { teacherClassDetails, teacherDashboardData } from "../../Data/mockData"
import MockActionModal from "../components/MockActionModal"
import "./AdminStudents.css"

const classById = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
)
const students = Object.entries(teacherClassDetails).flatMap(([classId, details]) => {
  const classItem = classById[classId]

  return classItem ? details.students.map((student) => ({
    ...student,
    studentId: student.id,
    classId,
    className: classItem.name,
  })) : []
})

function AdminStudents() {
  const [search, setSearch] = useState("")
  const [classFilter, setClassFilter] = useState("All classes")
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const [activeModal, setActiveModal] = useState(false)
  const normalizedSearch = search.trim().toLowerCase()
  const filteredStudents = students.filter((student) => {
    const matchesSearch = [student.name, student.studentId]
      .some((value) => value.toLowerCase().includes(normalizedSearch))
    const matchesClass = classFilter === "All classes" || student.classId === classFilter
    const matchesStatus = statusFilter === "All statuses" || student.status === statusFilter

    return matchesSearch && matchesClass && matchesStatus
  })
  const summary = [
    { label: "Total Students", value: students.length },
    { label: "Active Students", value: students.filter((student) => student.status === "Active").length },
    { label: "Inactive Students", value: students.filter((student) => student.status === "Inactive").length },
    { label: "Classes", value: new Set(students.map((student) => student.classId)).size },
  ]

  const modalFields = [
    { name: "studentName", label: "Student name", type: "text", placeholder: "e.g. Yuna Lee", required: true },
    { name: "studentId", label: "Student ID", type: "text", placeholder: "STU-XXXX", required: true },
    { name: "className", label: "Class", type: "select", options: teacherDashboardData.classes.map((classItem) => classItem.name), value: teacherDashboardData.classes[0]?.name ?? "" },
    { name: "status", label: "Status", type: "select", options: ["Active", "Inactive"], value: "Active" },
  ]

  return (
    <div className="admin-students">
      <header className="admin-students__heading">
        <div>
          <h1>Students</h1>
          <p>View and manage enrolled students across the school.</p>
        </div>
        <button className="admin-students__add-button" type="button" onClick={() => setActiveModal(true)}>
          Add Student
        </button>
      </header>

      <section className="admin-students__summary" aria-label="Student summary">
        {summary.map(({ label, value }) => (
          <article className="admin-students__summary-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </article>
        ))}
      </section>

      <section className="admin-students__section" aria-labelledby="admin-student-list-title">
        <div className="admin-students__toolbar">
          <div>
            <h2 id="admin-student-list-title">Enrolled Students</h2>
            <p>Showing {filteredStudents.length} of {students.length}</p>
          </div>
          <div className="admin-students__filters">
            <label>
              <span className="admin-students__visually-hidden">Search by student name or ID</span>
              <input
                type="search"
                placeholder="Search students..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label>
              <span className="admin-students__visually-hidden">Filter students by class</span>
              <select value={classFilter} onChange={(event) => setClassFilter(event.target.value)}>
                <option value="All classes">All classes</option>
                {teacherDashboardData.classes.map((classItem) => (
                  <option key={classItem.id} value={classItem.id}>{classItem.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span className="admin-students__visually-hidden">Filter students by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                <option value="All statuses">All statuses</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </label>
          </div>
        </div>

        <div className="admin-students__table-wrap">
          <table className="admin-students__table">
            <thead>
              <tr>
                <th scope="col">Student Name</th>
                <th scope="col">Student ID</th>
                <th scope="col">Class</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.length > 0 ? filteredStudents.map((student) => (
                <tr key={student.studentId}>
                  <th scope="row" data-label="Student Name">{student.name}</th>
                  <td data-label="Student ID">{student.studentId}</td>
                  <td data-label="Class">{student.className}</td>
                  <td data-label="Status">
                    <span className={`admin-students__status admin-students__status--${student.status.toLowerCase()}`}>
                      {student.status}
                    </span>
                  </td>
                  <td data-label="Action">
                    <Link className="admin-students__view-link" to={`/admin/students/${student.studentId}`}>
                      View Student
                    </Link>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td className="admin-students__empty" colSpan="5">No students match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <MockActionModal
        isOpen={activeModal}
        title="Add Student"
        description="Create a new student record for the mock school roster."
        submitLabel="Save Student"
        fields={modalFields}
        onClose={() => setActiveModal(false)}
        onSubmit={() => setActiveModal(false)}
      />
    </div>
  )
}

export default AdminStudents
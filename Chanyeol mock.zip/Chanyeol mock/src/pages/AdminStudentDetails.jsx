import { Link, useNavigate, useParams } from "react-router-dom"
import {
  teacherAttendanceRecords,
  teacherClassDetails,
  teacherDashboardData,
  teacherScheduleRecords,
} from "../../Data/mockData"
import "./AdminStudents.css"

const gradePercentages = {
  A: 95,
  "A-": 91,
  "B+": 88,
  B: 82,
  "B-": 79,
  "C+": 76,
  C: 72,
  "C-": 69,
  D: 65,
  F: 50,
}

const classById = Object.fromEntries(
  teacherDashboardData.classes.map((classItem) => [classItem.id, classItem]),
)
const students = Object.entries(teacherClassDetails).flatMap(([classId, details]) =>
  details.students.map((student) => ({ ...student, classId })),
)

function AdminStudentDetails() {
  const { studentId } = useParams()
  const navigate = useNavigate()
  const student = students.find((item) => item.id === studentId)
  const classItem = classById[student?.classId]
  const classDetails = teacherClassDetails[student?.classId]

  if (!student || !classItem || !classDetails) {
    return (
      <div className="admin-student-details">
        <section className="admin-student-details__not-found">
          <h1>Student not found</h1>
          <button type="button" onClick={() => navigate("/admin/students")}>
            Back to Students
          </button>
        </section>
      </div>
    )
  }

  const attendanceHistory = teacherAttendanceRecords
    .filter((record) => record.studentId === student.id)
    .sort((left, right) => right.date.localeCompare(left.date))
  const assignments = classDetails.assignments.slice(0, 3)
  const gradePercentage = gradePercentages[student.grade] ?? 0
  const nextClass = teacherScheduleRecords
    .filter((record) => record.classId === student.classId && record.status === "Upcoming")
    .sort((left, right) => left.date.localeCompare(right.date) || left.startTime.localeCompare(right.startTime))[0]

  return (
    <div className="admin-student-details">
      <button
        className="admin-student-details__back-button"
        type="button"
        onClick={() => navigate("/admin/students")}
      >
        Back to Students
      </button>

      <header className="admin-student-details__heading">
        <div>
          <p className="admin-student-details__eyebrow">Student Record · {classItem.name}</p>
          <h1>{student.name}</h1>
          <p>{student.id}</p>
        </div>
        <span className={`admin-students__status admin-students__status--${student.status.toLowerCase()}`}>
          {student.status}
        </span>
      </header>

      <section className="admin-student-details__summary" aria-label="Student overview">
        <article>
          <span>Class</span>
          <strong><Link to={`/teacher/classes/${classItem.id}`}>{classItem.name}</Link></strong>
        </article>
        <article>
          <span>Attendance</span>
          <strong>{student.attendance}%</strong>
        </article>
        <article>
          <span>Overall Grade</span>
          <strong>{gradePercentage}% ({student.grade})</strong>
        </article>
        <article>
          <span>Next Class</span>
          <strong>{nextClass ? `${nextClass.date} · ${nextClass.startTime}` : "Not scheduled"}</strong>
        </article>
      </section>

      <div className="admin-student-details__sections">
        <section className="admin-student-details__section" aria-labelledby="student-attendance-title">
          <div className="admin-student-details__section-heading">
            <h2 id="student-attendance-title">Recent Attendance</h2>
          </div>
          <div className="admin-student-details__records">
            {attendanceHistory.length > 0 ? attendanceHistory.map((record) => (
              <article className="admin-student-details__record" key={`${record.classId}-${record.date}`}>
                <time>{record.date}</time>
                <span className={`admin-student-details__attendance admin-student-details__attendance--${record.status.toLowerCase()}`}>
                  {record.status}
                </span>
              </article>
            )) : <p className="admin-student-details__empty">No attendance records available.</p>}
          </div>
        </section>

        <section className="admin-student-details__section" aria-labelledby="student-assignments-title">
          <div className="admin-student-details__section-heading">
            <h2 id="student-assignments-title">Class Assignments</h2>
          </div>
          <div className="admin-student-details__records">
            {assignments.map((assignment) => (
              <article className="admin-student-details__assignment" key={assignment.id}>
                <div>
                  <h3>{assignment.name}</h3>
                  <span>{assignment.type} · Due {assignment.dueDate}</span>
                </div>
                <span>{assignment.status}</span>
              </article>
            ))}
          </div>
        </section>
      </div>

      <section className="admin-student-details__section" aria-labelledby="student-activity-title">
        <div className="admin-student-details__section-heading">
          <h2 id="student-activity-title">Class Quiz Activity</h2>
        </div>
        <div className="admin-student-details__records">
          {classDetails.quizActivity.map((activity) => (
            <article className="admin-student-details__record" key={activity.id}>
              <span>{activity.description}</span>
              <time>{activity.timeAgo}</time>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}

export default AdminStudentDetails